"""Beta filter: only alert stocks whose beta vs SPY is in a range you pick."""
from engine.plugin_api import Param, Rule


class BetaFilter(Rule):
    id = "beta_filter"
    name = "Beta vs SPY in a range"
    group = "Market"
    description = ("Beta = how much the stock tends to move when SPY moves, from the last year of daily returns. "
                   "1.0 moves with the market, 1.5 moves ~1.5× as much (both ways), 0.5 half as much. Set a limit to 0 to skip it.")
    needs = ["bars"]
    default_enabled = False
    params = [
        Param("min_beta", "Beta at least", 0.0, unit="(0 = no minimum)", min=0, max=5, step=0.1),
        Param("max_beta", "Beta at most", 2.0, unit="(0 = no maximum)", min=0, max=5, step=0.1),
    ]

    def check(self, ctx, p):
        from engine import beta
        bars = ctx.get("bars")
        spy = ctx.other("SPY").get("bars")
        if bars is None or spy is None or not len(bars) or not len(spy):
            return True, "beta: no SPY data, not checked"
        s = bars["close"]
        m = spy["close"].reindex(s.index)
        b = beta.from_prices(s.values, m.values)
        if b is None:
            return True, "beta: under 6 months of history, not checked"
        ctx.set("beta", round(b, 2))
        lo, hi = float(p["min_beta"] or 0), float(p["max_beta"] or 0)
        bad = []
        if lo and b < lo:
            bad.append(f"beta {b:.2f} under {lo:.1f}")
        if hi and b > hi:
            bad.append(f"beta {b:.2f} over {hi:.1f}")
        return (not bad), ("; ".join(bad) if bad else f"beta {b:.2f} ({beta.describe(b)})")
