"""Debt filter: skip stocks carrying too much debt for their size or their sales."""
from engine.plugin_api import Param, Rule

FIN_SECTORS = ("Financials", "Real estate")      # banks, insurers, REITs: debt is their business model
NO_DATA = ["Let it through (often means no debt)", "Block it"]


def debt_ratios(debt, cash, mcap, rev_ttm, net=False):
    """(debt % of market cap, debt % of yearly revenue) - either can be None."""
    if debt is None:
        return None, None
    d = debt - (cash or 0.0) if net else debt
    d = max(0.0, d) if net else d
    pm = d / mcap * 100 if mcap else None
    pr = d / rev_ttm * 100 if rev_ttm and rev_ttm > 0 else None
    return pm, pr


class DebtFilter(Rule):
    id = "debt_filter"
    name = "Debt: not too much for its size and sales"
    group = "Fundamentals"
    description = ("Total debt (long-term + current, from the latest SEC filing) as a % of market cap, as a % of the "
                   "last 12 months' revenue, and debt-to-equity (debt ÷ shareholders' equity). Set any to 0 to skip it.")
    needs = ["debt_total", "revenue_ttm", "market_cap"]
    default_enabled = False
    params = [
        Param("max_mcap", "Debt at most", 50.0, unit="% of market cap (0 = don't check)", min=0, max=1000, step=5),
        Param("max_rev", "Debt at most", 150.0, unit="% of yearly revenue (0 = don't check)", min=0, max=2000, step=10),
        Param("max_de", "Debt-to-equity at most", 1.5, unit="× equity (0 = don't check)", min=0, max=50, step=0.1),
        Param("neg_equity", "Block negative shareholders' equity", True, kind="bool"),
        Param("net", "Subtract cash (use net debt)", False, kind="bool"),
        Param("skip_fin", "Don't apply to banks, insurers and REITs", True, kind="bool"),
        Param("no_data", "If the company reports no debt", NO_DATA[0], kind="choice", choices=NO_DATA),
    ]

    def check(self, ctx, p):
        if p["skip_fin"]:
            try:
                from engine import sector_filter as sf
                sec = sf.sector_of(ctx.engine, ctx.ticker, ctx)
            except Exception:
                sec = None
            if sec in FIN_SECTORS:
                return True, f"{sec}: debt check skipped"
        debt = ctx.get("debt_total")
        if debt is None:
            return p["no_data"] == NO_DATA[0], "no debt reported in SEC filings"
        cash = ctx.get("cash_total") if p["net"] else None
        pm, pr = debt_ratios(debt, cash, ctx.get("market_cap"), ctx.get("revenue_ttm"), p["net"])
        ctx.set("debt_pct_mcap", pm)
        ctx.set("debt_pct_rev", pr)
        eq = ctx.get("equity_total")
        d_used = max(0.0, debt - (cash or 0.0)) if p["net"] else debt
        de = d_used / eq if eq and eq > 0 else None
        ctx.set("debt_to_equity", de)
        bad = []
        if eq is not None and eq <= 0 and p["neg_equity"]:
            bad.append("negative shareholders' equity")
        if p["max_de"] and de is not None and de > p["max_de"]:
            bad.append(f"debt-to-equity {de:.2f} (max {p['max_de']:.2f})")
        if p["max_mcap"] and pm is not None and pm > p["max_mcap"]:
            bad.append(f"{pm:.0f}% of market cap (max {p['max_mcap']:.0f}%)")
        if p["max_rev"] and pr is not None and pr > p["max_rev"]:
            bad.append(f"{pr:.0f}% of revenue (max {p['max_rev']:.0f}%)")
        what = "net debt" if p["net"] else "debt"
        txt = f"{what} ${d_used / 1e9:,.2f}B = " + ", ".join(
            x for x in ((f"{pm:.0f}% of market cap" if pm is not None else None),
                        (f"{pr:.0f}% of revenue" if pr is not None else None),
                        (f"debt-to-equity {de:.2f}" if de is not None else None)) if x)
        return (not bad), ("; ".join(bad)) if bad else txt
