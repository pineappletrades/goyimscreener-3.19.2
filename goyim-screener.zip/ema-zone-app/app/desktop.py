"""Goyim Screener — desktop app entry point (Windows .exe).

The window is a local web page (ui/index.html) rendered by Windows' built-in Edge WebView2.
Every method on `Api` can be called from the page as `await window.pywebview.api.<name>(...)`.
"""
import os
import subprocess
import sys
import threading
import traceback
from datetime import datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

if "--selftest" in sys.argv and not os.environ.get("EMA_ZONE_HOME"):
    import tempfile  # keep the self-test's files out of the app folder

    os.environ["EMA_ZONE_HOME"] = tempfile.mkdtemp()

from engine import telegram_bot as tgbot_mod
from engine import backup as backup_mod
from engine import notify, paths, store  # noqa: E402
from engine.scanner import Engine  # noqa: E402
from engine.scheduler import AutoScanner  # noqa: E402
from engine import alerts as alerts_mod  # noqa: E402
from engine.screener import ScreenerBuilder  # noqa: E402

APP_VERSION = "3.19.0"
LOG_LINES = []


def log(msg):
    line = f"{datetime.now():%H:%M:%S}  {msg}"
    LOG_LINES.append(line)
    del LOG_LINES[:-500]
    try:
        paths.DATA_DIR.mkdir(parents=True, exist_ok=True)
        with open(paths.DATA_DIR / "app.log", "a", encoding="utf-8") as fh:
            fh.write(f"{datetime.now():%Y-%m-%d} {line}\n")
    except Exception:
        pass


def _mask(v):
    v = str(v or "")
    return "" if not v else ("•" * 8 + v[-4:] if len(v) > 6 else "•" * len(v))


class Api:
    def __init__(self):
        moved = paths.migrate_from_exe_folder()
        if moved:
            log(f"Moved your data from the app folder to {paths.HOME} (it now stays put across updates)")
        copied = paths.ensure_user_files()
        if copied:
            log(f"Set up {len(copied)} default files in {paths.HOME}")
        added = store.sync_default_profiles()
        if added:
            log(f"Added new strategies: {', '.join(added)}")
        self._engine = Engine(log=log)
        self._scan_lock = threading.Lock()
        self._auto = AutoScanner(self._daily_job, log=log, run_profile=self._scheduled_scan,
                                 busy=lambda: self._engine.status.get("running") or self._scan_lock.locked())
        self._auto.start()
        self._alerts = alerts_mod.AlertChecker(self._engine, log=log)
        self._screener = ScreenerBuilder(self._engine, log=log)
        self._research_cache = {}
        self._gamma_cache, self._gamma_verdict = {}, {}
        self._sbt_status, self._sbt_ds, self._sbt_stop = {"running": False}, {}, False
        self._val_status, self._val_cache, self._breadth = {"running": False}, None, (None, None)
        self._gs_status = {"running": False}
        self._alerts.extra_note = self._alert_note
        self._engine.gamma_loader = lambda t, lengths=None: self.get_gamma(t, "near", ema_lengths=lengths)
        from engine import book as book_mod
        self._book = book_mod.BookSampler(self._engine, self._book_targets, alerts_mod.market_open, log=log,
                                          enabled=lambda: store.settings().get("book_sampling", True))
        self._bot = tgbot_mod.TelegramBot(self, log=log)
        try:
            backup_mod.auto_backup()
        except Exception as e:
            log(f"Automatic backup failed: {e}")

    def _send_tg(self, text):
        if not self._engine.settings.get("telegram_enabled", True):
            return
        tg = store.secrets().get("telegram", {})
        try:
            notify.send(tg.get("bot_token"), tg.get("chat_id"), text)
        except Exception as e:
            log(f"Telegram not sent: {e}")

    def run_gamma_scan(self, tickers=None):
        from engine import gamma_scan as gs
        if not self._engine.providers_with("option_chain"):
            return {"ok": False, "error": "Gamma needs Public.com connected"}
        tickers = tickers or store.watchlist()
        res = gs.run(self, tickers, self._gs_status, log=log)
        store.save("gamma_scan.json", res)
        return {"ok": True, **res}

    def start_gamma_scan(self):
        if self._gs_status.get("running"):
            return {"ok": False, "error": "Already scanning"}
        self._gs_status.clear()
        self._gs_status.update(running=True)

        def run():
            try:
                self.run_gamma_scan()
            except Exception as ex:
                self._gs_status["error"] = str(ex)
            finally:
                self._gs_status["running"] = False
        threading.Thread(target=run, daemon=True).start()
        return {"ok": True}

    def gamma_scan_status(self):
        return {**self._gs_status, "result": store.load("gamma_scan.json", None) if not self._gs_status.get("running") else None}

    def list_sector_alerts(self):
        from engine import sector_alerts as sa
        return {"ok": True, "alerts": [dict(a, description=sa.describe(a)) for a in sa.load()]}

    def add_sector_alert(self, target, kind, value=None):
        from engine import sector_alerts as sa
        try:
            a = sa.add(target, kind, value)
            return {"ok": True, "alert": dict(a, description=sa.describe(a))}
        except Exception as ex:
            return {"ok": False, "error": str(ex)}

    def delete_sector_alert(self, index):
        from engine import sector_alerts as sa
        try:
            sa.remove(int(index))
            return {"ok": True}
        except Exception as ex:
            return {"ok": False, "error": str(ex)}

    def check_sector_alerts(self):
        from engine import sector_alerts as sa
        lst = sa.load()
        if not lst:
            return []
        val = self._valuation_snapshot()
        rows = []
        for grp in ("Sectors", "Macro", "Size & style"):
            r = self.get_rotation(grp)
            if r.get("ok"):
                rows += r["rows"]
        return sa.check(val, rows)

    def _after_scan_extras(self):
        """Daily extras after the close: sector/asset alerts, then the watchlist gamma scan."""
        from engine import gamma_scan as gs
        s = store.settings()
        try:
            msgs = self.check_sector_alerts()
            if msgs:
                self._send_tg("\n\n".join(msgs))
        except Exception as e:
            log(f"Sector alerts failed: {e}")
        if s.get("gamma_scan_daily", True) and self._engine.providers_with("option_chain") and store.watchlist():
            try:
                res = self.run_gamma_scan()
                if res.get("ok"):
                    self._send_tg(gs.message(res, detail=True))
            except Exception as e:
                log(f"Gamma scan failed: {e}")

    def _daily_job(self, send_telegram):
        """After the close: the strategy scan, then (optionally) refresh the screener's data."""
        try:
            backup_mod.auto_backup()
        except Exception as e:
            log(f"Automatic backup failed: {e}")
        self._run_scan(send_telegram)
        if send_telegram:
            self._after_scan_extras()
        s = store.settings()
        try:                                # sector valuation history: rebuilt weekly (it reads ~275 companies' filings)
            from engine import valuation as val_mod
            h = store.load(val_mod.HISTORY_FILE, None)
            if not h or datetime.now() - datetime.fromisoformat(h["built"]) > timedelta(days=7):
                if not self._val_status.get("running"):
                    self._val_status.update(running=True)
                    try:
                        val_mod.build_history(self._engine, self._val_status, log=log)
                    finally:
                        self._val_status["running"] = False
        except Exception as e:
            log(f"Valuation history refresh failed: {e}")
        if s.get("screener_auto", True) and not self._screener.status.get("running"):
            try:
                self._screener.build(float(s.get("screener_min_cap_b", 2)))
            except Exception as e:
                log(f"Screener refresh failed: {e}")

    # ---------- state ----------
    def get_state(self):
        e = self._engine
        secrets = store.secrets()
        providers = []
        enabled_map = e.settings.get("providers_enabled", {})
        active = {p.name: p for p in e.providers}
        for cls in e.registry.provider_classes:
            inst = active.get(cls.name)
            ready, msg = inst.ready() if inst else (False, "Turned off")
            providers.append({
                "name": cls.name, "description": cls.description, "supplies": list(cls.supplies),
                "needs": list(cls.needs), "enabled": enabled_map.get(cls.name, True),
                "ready": ready, "message": msg, "signup_url": cls.signup_url,
                "computed": not cls.key_fields and bool(cls.needs),
                "optional": bool(getattr(cls, "optional", False)),
                "keys": [dict(k.to_dict(), value=(_mask(secrets.get(cls.name, {}).get(k.id)) if k.secret
                                                  else secrets.get(cls.name, {}).get(k.id, "")),
                              is_set=bool(secrets.get(cls.name, {}).get(k.id))) for k in cls.key_fields],
            })
        rules = []
        for r in e.registry.rules:
            missing = e.missing_fields(r.needs)
            rules.append({"id": r.id, "name": r.name, "group": r.group, "description": r.description,
                          "needs": list(r.needs), "missing": missing, "default_enabled": r.default_enabled,
                          "missing_sources": e.sources_label(missing) if missing else "",
                          "params": [p.to_dict() for p in r.params]})
        g = e.registry.graders[0] if e.registry.graders else None
        pl = e.registry.planners[0] if e.registry.planners else None
        tg = secrets.get("telegram", {})
        return {
            "version": APP_VERSION,
            "home": str(paths.HOME),
            "settings": store.settings(),
            "telegram": {"bot_token": _mask(tg.get("bot_token")), "chat_id": tg.get("chat_id", ""),
                         "is_set": bool(tg.get("bot_token") and tg.get("chat_id"))},
            "profiles": store.profiles(),
            "watchlist": store.watchlist(),
            "providers": sorted(providers, key=lambda p: (p["optional"], p["computed"])),
            "rules": rules,
            "grader": {"name": g.name, "params": [p.to_dict() for p in g.params]} if g else None,
            "planner": {"name": pl.name, "params": [p.to_dict() for p in pl.params]} if pl else None,
            "plugin_errors": [{"file": f, "error": m} for f, m in e.registry.errors],
            "last_scan": store.load("last_scan.json", None),
            "auto_text": self._auto.next_run_text(),
            "capabilities": self._capabilities(),
            "screens": store.load("screens.json", []),
            "bar_watchlist": store.load("bar_watchlist.json", []),
        }

    def _capabilities(self):
        """Which features the connected data sources make available (others are greyed out)."""
        e = self._engine
        fields = ["bars", "bars_10y", "history", "valuation_history", "revenue_segments", "forward_pe",
                  "analyst_rating", "analyst_score", "peg_ratio", "next_earnings_date", "sector",
                  "sic_sector", "last_earnings_date", "pe_ratio"]
        caps = {f: e.field_available(f) for f in fields}
        for m in ("quotes", "earnings_calendar", "fundamentals_all", "company_info", "shares_outstanding_all",
                  "option_chain"):
            caps[m] = bool(e.providers_with(m))
        caps["sources"] = {f: e.sources_label([f]) for f in fields + ["earnings_calendar"]}
        caps["sources"]["earnings_calendar"] = "Finnhub or Alpha Vantage"
        caps["sources"]["quotes"] = "Public.com"
        caps["sources"]["option_chain"] = "Public.com"
        caps["sources"]["fundamentals_all"] = "SEC EDGAR"
        return caps

    # ---------- saving ----------
    def save_settings(self, settings):
        cur = store.settings()
        cur.update(settings or {})
        store.save("settings.json", cur)
        self._engine.reload()
        return {"ok": True}

    def save_provider_keys(self, provider_name, keys):
        s = store.load("secrets.json", {})
        group = s.setdefault(provider_name, {})
        for k, v in (keys or {}).items():
            if v is None or str(v).startswith("•"):
                continue        # unchanged masked value
            group[k] = str(v).strip()
        store.save("secrets.json", s)
        self._engine.reload()
        return {"ok": True}

    def save_telegram(self, bot_token, chat_id):
        return self.save_provider_keys("telegram", {"bot_token": bot_token, "chat_id": chat_id})

    def set_provider_enabled(self, name, enabled):
        s = store.settings()
        s.setdefault("providers_enabled", {})[name] = bool(enabled)
        store.save("settings.json", s)
        self._engine.reload()
        return {"ok": True}

    def set_sector_filter(self, mode, profile_id="investing"):
        """Turn the scan's sector filter on (leading / undervalued / ...) or off for one strategy."""
        from engine import sector_filter as sf
        k = sf.key(mode)
        profs = store.profiles()
        prof = next((x for x in profs if x.get("id") == profile_id), None) or (profs[0] if profs else None)
        if prof is None:
            return {"ok": False, "error": "No strategies"}
        rules = prof.setdefault("rules", {})
        if k == "off":
            rules["leading_sector"] = dict(rules.get("leading_sector") or {}, enabled=False)
        else:
            choice = dict(zip(["leading", "leading_improving", "not_lagging", "undervalued", "not_overvalued"], sf.RULE_CHOICES))[k]
            rules["leading_sector"] = {"enabled": True, "params": dict(((rules.get("leading_sector") or {}).get("params") or {}), allow=choice)}
        store.save("profiles.json", profs)
        self._engine.reload()
        return {"ok": True, "profile": prof.get("name", prof["id"]), "mode": k, "label": sf.label(k)}

    def get_sector_filter(self, profile_id="investing"):
        from engine import sector_filter as sf
        prof = next((x for x in store.profiles() if x.get("id") == profile_id), None) or {}
        r = (prof.get("rules") or {}).get("leading_sector") or {}
        k = sf.key((r.get("params") or {}).get("allow", "Leading only")) if r.get("enabled") else "off"
        return {"ok": True, "profile": prof.get("name", profile_id), "mode": k, "label": sf.label(k)}

    def save_profiles(self, profiles):
        ids = set()
        for p in profiles:
            if not p.get("id") or p["id"] in ids:
                return {"ok": False, "error": "Each strategy needs a unique id"}
            if int(p.get("fast", 0)) >= int(p.get("slow", 0)):
                return {"ok": False, "error": f"{p.get('name')}: fast MA must be shorter than slow MA"}
            ids.add(p["id"])
        store.save("profiles.json", profiles)
        st_ = store.settings()
        if st_.get("scan_slot"):                     # hand edits after loading a slot
            st_["scan_slot"]["edited"] = True
            store.save("settings.json", st_)
        return {"ok": True}

    def save_watchlist(self, tickers):
        return {"ok": True, "watchlist": store.save_watchlist(tickers)}

    # ---------- scanning ----------
    def _run_scan(self, send_telegram, tickers=None, profiles=None, slot=None):
        """slot: {"slot", "name", "universe"} when this is a test scan with a saved Strategy Test profile:
        it scans with that profile only, is saved separately (slot_scan.json) and doesn't replace today's scan."""
        if not self._scan_lock.acquire(blocking=False):
            return {"ok": False, "error": "A scan is already running"}
        try:
            self._engine.reload()
            out = self._engine.scan(tickers=tickers, record=tickers is None and profiles is None, profiles=profiles)
            if slot:
                out["slot_test"] = slot
            daily = tickers is None and profiles is None
            if daily and store.settings().get("valuation_in_scan", True):
                try:
                    out["valuation"] = self._valuation_snapshot(force=True)
                except Exception as ex:
                    log(f"Valuation skipped: {ex}")
            if daily and store.settings().get("rotation_in_scan", True):
                try:
                    from engine import rotation as rot
                    r = self.get_rotation("Sectors")
                    if r.get("ok"):
                        out["rotation"] = {"summary": r["summary"],
                                           "rows": [{"ticker": x["ticker"], "name": x["name"], "quadrant": x.get("quadrant"),
                                                     "rel_1m": x["rel"].get("1M")} for x in r["rows"] if not x.get("benchmark")]}
                except Exception as ex:
                    log(f"Rotation skipped: {ex}")
            if store.settings().get("sector_in_alerts", True):
                try:
                    self._label_sectors(out)
                except Exception as ex:
                    log(f"Sector labels skipped: {ex}")
            if store.settings().get("gamma_levels_in_scan", True):
                self._add_gamma_plans(out, log_it=daily)
            if store.settings().get("options_in_scan", True):
                try:
                    self._options_labels(out)
                except Exception as ex:
                    log(f"Options finder skipped: {ex}")
            if store.settings().get("macro_in_scan", True):
                try:
                    from engine import macro
                    out["macro"] = {k: v for k, v in macro.snapshot(self._engine).items() if k != "history"}
                except Exception as ex:
                    log(f"Macro skipped: {ex}")
            if store.settings().get("support_in_alerts", True):
                try:
                    self._support_labels(out, journal=profiles is None)
                except Exception as ex:
                    log(f"Support checks skipped: {ex}")
            if daily and ("valuation" in out or "rotation" in out or out.get("gamma_plans") or out.get("results")):
                store.save("last_scan.json", out)
            if slot:
                store.save("slot_scan.json", out)
            if daily or (slot and slot.get("scheduled")):
                try:
                    from engine import scan_journal
                    scan_journal.add(out, source="daily" if daily else f"scheduled:{slot.get('slot')}")
                except Exception as ex:
                    log(f"Alert journal skipped: {ex}")
            if send_telegram and self._engine.settings.get("telegram_enabled", True):
                tg = store.secrets().get("telegram", {})
                try:
                    notify.send(tg.get("bot_token"), tg.get("chat_id"), notify.build_message(out))
                    log("Telegram alert sent")
                except Exception as e:
                    log(f"Telegram not sent: {e}")
            return {"ok": True, "scan": out}
        except Exception as e:
            log(f"Scan failed: {e}\n{traceback.format_exc(limit=3)}")
            return {"ok": False, "error": str(e)}
        finally:
            self._scan_lock.release()

    def start_scan(self, send_telegram=False):
        if self._engine.status.get("running"):
            return {"ok": False, "error": "A scan is already running"}
        threading.Thread(target=self._run_scan, args=(bool(send_telegram),), daemon=True).start()
        return {"ok": True}

    def stop_scan(self):
        self._engine.stop()
        return {"ok": True}

    def scan_status(self):
        st = dict(self._engine.status)
        st["app_log"] = LOG_LINES[-60:]
        return st

    def check_ticker(self, ticker):
        t = str(ticker or "").strip().upper()
        if not t:
            return {"ok": False, "error": "Enter a ticker"}
        if self._engine.status.get("running"):
            return {"ok": False, "error": "Wait for the current scan to finish"}
        res = self._run_scan(False, tickers=[t])
        return res

    def get_detail(self, ticker, profile_id):
        try:
            return {"ok": True, **self._engine.detail(ticker, profile_id)}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def test_telegram(self):
        tg = store.secrets().get("telegram", {})
        try:
            notify.send(tg.get("bot_token"), tg.get("chat_id"), "✅ Goyim Screener is connected.")
            return {"ok": True}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def test_provider(self, name, ticker="AAPL"):
        """Fetch one ticker from one source, part by part, so you can see what your plan includes."""
        from engine.scanner import Context
        prov = next((p for p in self._engine.providers if p.name == name), None)
        if not prov:
            return {"ok": False, "error": "This source is off or didn't load"}
        prof = (store.profiles() or [{"id": "test", "fast": 150, "slow": 200}])[0]
        groups = list(prov.groups) or ["all"]
        works, fails, fields = [], [], []
        for g in groups:
            ctx = Context(self._engine, ticker, prof, {"values": {}, "fetched": set()})
            ctx.requested_group = g
            try:
                data = prov.fetch(ctx) or {}
                got = [k for k, v in data.items() if v is not None]
                (works if got else fails).append(g if got else f"{g} (no data for {ticker})")
                fields += got
            except Exception as e:
                fails.append(f"{g}: {e}")
        ok = bool(works)
        msg = (f"{name}: works for {', '.join(works)}" if ok else f"{name}: nothing worked")
        if fails:
            msg += ". Not available: " + "; ".join(fails)
        return {"ok": ok, "fields": fields, "message": msg, "error": None if ok else msg}

    # ---------- charts ----------
    def get_chart(self, ticker):
        from engine.scanner import Context
        t = str(ticker or "").strip().upper()
        if not t:
            return {"ok": False, "error": "Enter a ticker"}
        e = self._engine
        if not e.field_available("bars_10y"):
            return {"ok": False, "error": "Charts need a price source. Add your Public.com key on Data sources."}
        ctx = Context(e, t, {"id": "chart", "fast": 150, "slow": 200}, e.shared_cache(t))
        try:
            df = ctx.get("bars_10y")
        except Exception as ex:
            try:                                  # 10 years failed: show the 5-year daily chart instead
                df = ctx.get("bars")
            except Exception:
                return {"ok": False, "error": str(ex)}
        if df is None or not len(df):
            return {"ok": False, "error": f"No price data for {t}"}
        r = lambda col: [round(float(x), 4) for x in df[col]]
        quote = None
        try:
            quote = e.call_first("quotes", [t])[0].get(t)
        except Exception:
            pass
        return {"ok": True, "ticker": t, "t": [d.strftime("%Y-%m-%d") for d in df.index],
                "o": r("open"), "h": r("high"), "l": r("low"), "c": r("close"),
                "v": [int(x) for x in df["volume"]], "quote": quote,
                "weekly_until": df.attrs.get("weekly_until"), "older_bars": df.attrs.get("older_bars")}

    def save_chart_settings(self, cfg):
        s = store.settings()
        s["chart"] = cfg
        store.save("settings.json", s)
        return {"ok": True}

    # ---------- research / compare ----------
    def get_research(self, ticker, with_segments=True):
        from engine.scanner import Context
        t = str(ticker or "").strip().upper()
        if not t:
            return {"ok": False, "error": "Enter a ticker"}
        key = (t, datetime.now().date().isoformat(), bool(with_segments))
        if key in self._research_cache:
            return self._research_cache[key]
        e = self._engine
        ctx = Context(e, t, {"id": "research", "fast": 150, "slow": 200}, e.shared_cache(t))
        out = {"ok": True, "ticker": t, "errors": {}, "unavailable": {}}

        def grab(field, label):
            if not e.field_available(field):
                out["unavailable"][label] = e.sources_label(e.missing_fields([field]) or [field])
                return None
            try:
                return ctx.get(field)
            except Exception as ex:
                out["errors"][label] = str(ex)
                return None

        out["history"] = grab("history", "fundamentals")
        if not out["history"] and "fundamentals" not in out["unavailable"] and "fundamentals" not in out["errors"]:
            out["errors"]["fundamentals"] = f"No quarterly filings found for {t}"
        out["valuation"] = grab("valuation_history", "valuation")
        if with_segments:
            out["segments"] = grab("revenue_segments", "segments")
        out["sector"] = grab("sic_sector", "sector") if e.field_available("sic_sector") else None
        try:
            out["quote"] = e.call_first("quotes", [t])[0].get(t)
        except Exception:
            out["quote"] = None
        out["stats"] = self._research_stats(t, ctx, out)
        if out["history"] or out["valuation"]:
            self._research_cache[key] = out
        return out

    def _research_stats(self, t, ctx, r):
        """Company header + Statistics (TTM). Optional-source fields are filled only when connected."""
        from engine import stats as stats_mod
        e = self._engine
        extra = {}
        try:
            info, _ = e.call_first("company_info", t)
            extra.update({k: info.get(k) for k in ("name", "website", "exchange", "last_earnings_date")})
            extra["industry"] = info.get("sic_description")
            extra["sector"] = info.get("sic_sector")
        except Exception:
            pass
        for f in ("sector", "industry", "forward_pe", "next_earnings_date", "peg_ratio", "high_52w", "low_52w"):
            if not e.field_available(f) or (f in ("sector", "industry") and e.provider_for(f) is None):
                continue
            prov = e.provider_for(f)
            if f in ("sector", "industry") and prov is not None and prov.name == "SEC EDGAR":
                continue
            try:
                v = ctx.get(f)
                if v not in (None, ""):
                    extra[f] = v
            except Exception:
                pass
        bars = None
        if e.field_available("bars_10y"):
            try:
                bars = ctx.get("bars_10y")
            except Exception:
                bars = None
        try:
            return stats_mod.build(r, bars, extra)
        except Exception as ex:
            r.setdefault("errors", {})["statistics"] = str(ex)
            return None

    # ---------- valuation scores (-10 expensive ... +10 cheap vs own history) ----------
    def _breadth_history(self):
        from engine import strategy_bt as sbt
        from engine import valuation as val_mod
        today = datetime.now().date()
        if self._breadth[0] != today:
            ds = self._sbt_ds.get("all") or sbt.load_dataset("all", max_age_days=30)
            self._breadth = (today, val_mod.breadth_history(ds) if ds else None)
        return self._breadth[1]

    def _valuation_snapshot(self, force=False):
        import time as _t
        from engine import valuation as val_mod
        if not force and self._val_cache and _t.time() - self._val_cache[0] < 600:
            return self._val_cache[1]
        snap = val_mod.snapshot(self._engine, breadth_hist=self._breadth_history(), log=log)
        self._val_cache = (_t.time(), snap)
        return snap

    def get_valuation(self, refresh=False):
        from engine import valuation as val_mod
        if not self._engine.field_available("bars"):
            return {"ok": False, "needs": "Public.com", "error": "Valuation needs prices. Add your Public.com key on Data sources."}
        try:
            snap = self._valuation_snapshot(force=bool(refresh))
        except Exception as ex:
            return {"ok": False, "error": str(ex)}
        return {"ok": True, **snap, "status": dict(self._val_status),
                "has_history": bool(store.load(val_mod.HISTORY_FILE, None))}

    def build_valuation(self):
        from engine import valuation as val_mod
        if self._val_status.get("running"):
            return {"ok": False, "error": "Already building"}
        if not self._engine.providers_with("pit_fundamentals"):
            return {"ok": False, "error": "Needs SEC EDGAR connected"}
        self._val_status.clear()
        self._val_status.update(running=True, stage="Starting", done=0, total=0, error=None)

        def run():
            try:
                val_mod.build_history(self._engine, self._val_status, log=log)
                self._val_cache = None
                self._val_status.update(running=False, stage="Done")
            except Exception as ex:
                self._val_status.update(running=False, error=str(ex), stage="Failed")
        threading.Thread(target=run, daemon=True).start()
        return {"ok": True}

    def valuation_status(self):
        return dict(self._val_status)

    # ---------- strategy backtest (replay the Investing alert, stop-loss finder) ----------
    def strategy_bt_defaults(self):
        from engine import sector_filter as sf
        inv = next((x for x in store.profiles() if x.get("id") == "investing"), {})
        rules = inv.get("rules", {})
        rp = (rules.get("ma_touch", {}) or {}).get("params", {})
        on = lambda r: (rules.get(r, {}) or {}).get("enabled", False)
        dp_ = ((rules.get("debt_filter", {}) or {}).get("params", {}) or {})
        bp_ = ((rules.get("beta_filter", {}) or {}).get("params", {}) or {})
        xp_ = ((rules.get("not_extended", {}) or {}).get("params", {}) or {})
        ep_ = ((rules.get("no_earnings_soon", {}) or {}).get("params", {}) or {})
        rp_ = lambda rid: ((rules.get(rid, {}) or {}).get("params", {}) or {})
        lines = {"Fast MA only": "fast", "Slow MA only": "slow"}.get(rp.get("lines"), "both")
        return {"ma_type": inv.get("ma_type", "EMA"), "fast": inv.get("fast", 150), "slow": inv.get("slow", 200),
                "tolerance": rp.get("tolerance", 0.5), "above_days": rp.get("above_days", 15), "hold": rp.get("hold", True),
                "new_only": rp.get("new_only", True), "lines": lines,
                "min_cap_b": ((rules.get("min_market_cap", {}) or {}).get("params", {}) or {}).get("min_b", 5) if on("min_market_cap") else 0,
                "use_fcf": on("fcf_positive"), "use_rev": on("revenue_growth"), "use_eps": on("eps_up_yoy"),
                "rev_min_pct": ((rules.get("revenue_growth", {}) or {}).get("params", {}) or {}).get("min_pct", 0),
                "rev_quarters": ((rules.get("revenue_growth", {}) or {}).get("params", {}) or {}).get("quarters", 1),
                "eps_min_quarters": ((rules.get("eps_up_yoy", {}) or {}).get("params", {}) or {}).get("min_quarters", 1),
                "hold_days": 252, "slots": 10, "stop": {"type": "none"}, "take_profit": {"type": "none"}, "universe": "all",
                "require": [x for x, rid in (("light_pullback", "sup_light_pullback"), ("strong_close", "sup_strong_close"),
                                             ("absorption", "sup_absorption"), ("accumulation", "sup_accumulation"),
                                             ("respected", "sup_respected"), ("no_repeat", "no_repeat_failure")) if on(rid)],
                "macro_min": (((rules.get("macro_regime", {}) or {}).get("params", {}) or {}).get("min_score", -2.0)) if on("macro_regime") else None,
                "theme_max_risk": (((rules.get("theme_health", {}) or {}).get("params", {}) or {}).get("max_risk", 2)) if on("theme_health") else None,
                "use_speed": on("pullback_speed"), "speed_days": int(rp_("pullback_speed").get("days", 5)),
                "speed_max_drop": rp_("pullback_speed").get("max_drop", 10.0), "speed_max_gap": rp_("pullback_speed").get("max_gap", 0.0),
                "use_rel": on("rel_weakness"), "rel_days": int(rp_("rel_weakness").get("days", 20)),
                "rel_max_spy": rp_("rel_weakness").get("max_spy", 8.0), "rel_max_sec": rp_("rel_weakness").get("max_sector", 0.0),
                "use_touches": on("touch_number"), "touch_max": int(rp_("touch_number").get("max_touch", 2)),
                "use_slope": on("slow_rising"), "slope_days": int(rp_("slow_rising").get("lookback", 60)) if on("slow_rising") else 60,
                "slope_min": rp_("slow_rising").get("min_pct", 0.0) if on("slow_rising") else 2.0,
                "use_earn": on("no_earnings_soon"), "earn_before": int(round(float(ep_.get("min_days", 14)) * 5 / 7)) if on("no_earnings_soon") else 10,
                "earn_after": 0,
                "use_ext": on("not_extended"), "ext_max_spread": xp_.get("max_spread", 10.0), "ext_max_peak": xp_.get("max_peak", 0.0),
                "ext_days": int(xp_.get("days", 60)), "ext_beta": bool(xp_.get("beta_adjust", False)),
                "use_beta": on("beta_filter"), "beta_min": bp_.get("min_beta", 0.0), "beta_max": bp_.get("max_beta", 2.0),
                "use_debt": on("debt_filter"),
                "max_debt_mcap": dp_.get("max_mcap", 50.0), "max_debt_rev": dp_.get("max_rev", 150.0),
                "max_debt_equity": dp_.get("max_de", 1.5), "debt_block_neg_equity": dp_.get("neg_equity", True),
                "debt_net": dp_.get("net", False), "debt_skip_fin": dp_.get("skip_fin", True),
                "debt_no_data": "block" if str(dp_.get("no_data", "")).startswith("Block") else "allow",
                "sector_filter": sf.key(((rules.get("leading_sector", {}) or {}).get("params", {}) or {}).get("allow", "Leading only"))
                                 if on("leading_sector") else "off",
                "not_simulated": [r for r, v in rules.items() if (v or {}).get("enabled") and r not in
                                  ("ma_touch", "min_market_cap", "fcf_positive", "revenue_growth", "eps_up_yoy", "leading_sector",
                                   "sup_light_pullback", "sup_strong_close", "sup_absorption", "sup_accumulation", "sup_respected",
                                   "no_repeat_failure", "macro_regime", "theme_health", "debt_filter", "beta_filter", "not_extended", "no_earnings_soon",
                                   "pullback_speed", "rel_weakness", "touch_number", "slow_rising")]
                                 + (["touches from below (resistance tests are checked on the Backtest page, not bought here)"]
                                    if rp.get("side") and not str(rp.get("side")).startswith("From above") else [])}

    def start_strategy_bt(self, params=None, refresh=False):
        from engine import strategy_bt as sbt
        from engine import universe as uni
        st = self._sbt_status
        if st.get("running"):
            return {"ok": False, "error": "A backtest is already running"}
        e = self._engine
        if not e.field_available("bars") or not e.providers_with("pit_fundamentals"):
            return {"ok": False, "error": "Needs Public.com (prices) and SEC EDGAR (filings) connected"}
        p = dict(self.strategy_bt_defaults())
        p.update({k: v for k, v in (params or {}).items() if v is not None})
        mode = "watchlist" if p.get("universe") == "watchlist" else "all"
        source = "fmp" if p.get("data_source") == "fmp" else "public"
        years = int(p.get("years") or 10) if source == "fmp" else 5
        if p.get("use_earn") and not e.providers_with("daily_bars"):
            return {"ok": False, "error": "The earnings filter uses FMP earnings dates: add your FMP API key on Data sources"}
        if source == "fmp" and not e.providers_with("daily_bars"):
            return {"ok": False, "error": "FMP isn't connected: add your FMP API key on Data sources (or pick Public)"}
        key = (mode, source, years)
        self._sbt_stop = False
        st.clear()
        st.update(running=True, stage="Starting", done=0, total=0, error=None, started=datetime.now().isoformat(timespec="seconds"))

        def run():
            try:
                ds = None if refresh else (self._sbt_ds.get(key) or sbt.load_dataset(mode, source=source, years=years))
                if ds is not None and p.get("require") and not sbt.has_volume(ds):
                    log("Strategy Test: support filters need volume, downloading the data again")
                    ds = None                               # datasets from before v3.4 have no volume
                if ds is None:
                    if mode == "watchlist":
                        tickers = store.watchlist()
                    else:
                        st.update(stage="Building the stock list")
                        floor = max(1.0, float(p.get("min_cap_b") or 5) / 2.5)     # wider than the rule, so stocks that shrank since are still tested
                        tickers, _ = uni.build(e, floor, log=log)
                    ds = sbt.build_dataset(e, tickers, st, lambda: self._sbt_stop, log=log, mode=mode, source=source, years=years,
                                           delay=0.09 if source == "fmp" else 0.1)
                elif not sbt.has_sector_data(ds) or not sbt.has_macro_data(ds):   # older datasets: add the extra ETFs once
                    sbt.add_sector_data(e, ds, st, lambda: self._sbt_stop, log=log)
                if ds is not None and not sbt.has_debt(ds):         # datasets from before v3.7: add debt from SEC once
                    sbt.refresh_pit(e, ds, st, lambda: self._sbt_stop, log=log)
                if ds is not None and not sbt.has_earnings(ds) and (p.get("use_earn") or source == "fmp") \
                        and any(hasattr(x, "earnings_dates") for x in e.providers_with("daily_bars")):
                    try:                                            # earnings dates from FMP, once per dataset
                        sbt.add_earnings(e, ds, st, lambda: self._sbt_stop, log=log)
                    except Exception as ex:
                        if p.get("use_earn"):
                            raise
                        log(f"Earnings dates skipped: {ex}")
                self._sbt_ds[key] = ds
                if self._sbt_stop:
                    st.update(running=False, stage="Stopped")
                    return
                res = sbt.run(ds, p, st)
                res["mode"] = mode
                res["data_source"] = {"source": source, "years": years, "label": "FMP" if source == "fmp" else "Public.com"}
                store.save(sbt.ALERTS_FILE, res.pop("_all_days", None) or [])
                store.save(sbt.RESULT_FILE, res)
                st.update(running=False, stage="Done", done=st.get("total", 0))
            except Exception as ex:
                log(f"Strategy backtest failed: {ex}\n{traceback.format_exc(limit=4)}")
                st.update(running=False, error=str(ex), stage="Failed")
        threading.Thread(target=run, daemon=True).start()
        return {"ok": True}

    # ---------- saved parameter slots ----------
    def list_param_slots(self):
        from engine import slots
        rows = slots.load()
        active = store.settings().get("scan_slot")
        return {"ok": True, "slots": [None if r is None else dict(r, describe=slots.describe(r["params"])) for r in rows],
                "scan_slot": active}

    def save_param_slot(self, i, name=None, params=None, with_result=True):
        """Save settings into slot i (0-9). Without params: the last Strategy Test's settings."""
        from engine import slots
        from engine import strategy_bt as sbt
        res = store.load(sbt.RESULT_FILE, None) if with_result else None
        if not params:
            if not res:
                return {"ok": False, "error": "Run the Strategy Test first (or pass settings)"}
            params = dict(res.get("params") or {}, universe=res.get("mode"),
                          data_source=(res.get("data_source") or {}).get("source", "public"),
                          years=(res.get("data_source") or {}).get("years", 5))
        try:
            row = slots.save(int(i), name, params, res)
        except Exception as ex:
            return {"ok": False, "error": str(ex)}
        return {"ok": True, "slot": int(i), "saved": row}

    def clear_param_slot(self, i):
        from engine import slots
        slots.clear(int(i))
        s = store.settings()
        if (s.get("scan_slot") or {}).get("slot") == int(i):
            s["scan_slot"] = None
            store.save("settings.json", s)
        return {"ok": True}

    def slot_profile(self, i, universe="all"):
        """A scan profile built from saved slot i (0-9) on top of the Investing strategy. universe: all | watchlist."""
        from engine import slots
        rows = slots.load()
        row = rows[int(i)] if 0 <= int(i) < len(rows) else None
        if not row:
            return None, None, f"Profile {int(i) + 1} is empty: save one from the Strategy Test first"
        base = next((x for x in store.profiles() if x.get("id") == "investing"), None) or \
            {"id": "investing", "ma_type": "EMA", "fast": 150, "slow": 200, "rules": {}, "universe": {"source": "all", "min_market_cap_b": 5}}
        prof = slots.to_profile(dict(base), row["params"])
        prof["id"] = f"slot{int(i) + 1}"
        prof["name"] = f"Profile {int(i) + 1}: {row['name']}"
        u = dict(base.get("universe") or {"source": "all", "min_market_cap_b": 5})
        if universe == "watchlist":
            u = {"source": "watchlist"}
        else:
            u["source"] = "all"
            mc = float(row["params"].get("min_cap_b") or 0)
            if mc and mc < float(u.get("min_market_cap_b", 5)):
                u["min_market_cap_b"] = mc
        prof["universe"] = u
        return prof, row, None

    def default_profiles(self, universe="all"):
        """The daily scan's own strategies (as set on the Strategies page), for a quick test scan."""
        profs = [dict(x) for x in store.profiles() if x.get("enabled", True)]
        if universe == "watchlist":
            for x in profs:
                x["universe"] = {"source": "watchlist"}
        return profs

    def start_slot_scan(self, i, universe="watchlist", send_telegram=False):
        """Quick test: scan once with a saved Strategy Test profile, or i="default" for the daily scan's usual settings.
        Doesn't change today's scan or the daily settings."""
        if self._engine.status.get("running"):
            return {"ok": False, "error": "A scan is already running"}
        if str(i).lower() in ("default", "-1", "d"):
            profs = self.default_profiles(universe)
            if not profs:
                return {"ok": False, "error": "No strategies are turned on (Strategies page)"}
            act = store.settings().get("scan_slot") or {}
            info = {"slot": -1, "name": "Default (your daily scan settings)", "universe": universe,
                    "describe": ", ".join(x.get("name", x["id"]) for x in profs)
                    + (f" · Investing currently uses saved profile {act['slot'] + 1}: {act['name']}" if act.get("slot") is not None else "")}
            threading.Thread(target=self._run_scan, args=(bool(send_telegram),), kwargs={"profiles": profs, "slot": info}, daemon=True).start()
            return {"ok": True, "name": info["name"]}
        prof, row, err = self.slot_profile(i, universe)
        if err:
            return {"ok": False, "error": err}
        info = {"slot": int(i), "name": row["name"], "universe": universe, "describe": None}
        try:
            from engine import slots
            info["describe"] = slots.describe(row["params"])
        except Exception:
            pass
        threading.Thread(target=self._run_scan, args=(bool(send_telegram),), kwargs={"profiles": [prof], "slot": info}, daemon=True).start()
        return {"ok": True, "name": prof["name"]}

    # ---------- scheduled profile scans ----------
    def _scheduled_scan(self, it):
        """Run one scheduled scan (Default = the full daily scan, or a saved profile) and send it to Telegram if set."""
        uni = it.get("universe", "all")
        tg = bool(it.get("telegram", True))
        if str(it.get("slot")) == "default":
            if uni == "all":
                return self._run_scan(tg)                              # the real daily scan (saved as today's scan)
            profs = self.default_profiles("watchlist")
            return self._run_scan(tg, profiles=profs, slot={"slot": -1, "name": "Default (watchlist)", "universe": uni, "scheduled": True,
                                                            "describe": f"scheduled at {it.get('time')}"})
        prof, row, err = self.slot_profile(int(it["slot"]), uni)
        if err:
            log(f"Scheduled scan: {err}")
            return {"ok": False, "error": err}
        from engine import slots
        return self._run_scan(tg, profiles=[prof], slot={"slot": int(it["slot"]), "name": row["name"], "universe": uni, "scheduled": True,
                                                          "describe": f"scheduled at {it.get('time')} · " + slots.describe(row["params"])})

    def get_schedule(self):
        rows = store.settings().get("profile_schedule") or []
        return {"ok": True, "schedule": rows, "next": self._auto.next_profile_runs()}

    def save_schedule(self, rows):
        import uuid
        clean = []
        for x in rows or []:
            slot = "default" if str(x.get("slot")) in ("default", "-1", "") else int(x.get("slot"))
            t = str(x.get("time") or "13:20")[:5]
            clean.append({"id": x.get("id") or uuid.uuid4().hex[:8], "slot": slot, "time": t,
                          "universe": "watchlist" if x.get("universe") == "watchlist" else "all",
                          "telegram": bool(x.get("telegram", True)), "enabled": bool(x.get("enabled", True)),
                          "weekdays_only": bool(x.get("weekdays_only", True))})
        clean.sort(key=lambda z: z["time"])
        s = store.settings()
        s["profile_schedule"] = clean
        store.save("settings.json", s)
        return self.get_schedule()

    def run_schedule_now(self, sid):
        it = next((x for x in store.settings().get("profile_schedule") or [] if x.get("id") == sid), None)
        if not it:
            return {"ok": False, "error": "Not found"}
        if self._engine.status.get("running"):
            return {"ok": False, "error": "A scan is already running"}
        threading.Thread(target=self._scheduled_scan, args=(it,), daemon=True).start()
        return {"ok": True}

    def get_slot_scan(self):
        return {"ok": True, "scan": store.load("slot_scan.json", None)}

    def load_slot_into_scan(self, i, profile_id="investing"):
        """Copy a slot's entry rules and filters into a strategy so the daily scan uses them."""
        from engine import slots
        rows = slots.load()
        row = rows[int(i)] if 0 <= int(i) < len(rows) else None
        if not row:
            return {"ok": False, "error": f"Slot {int(i) + 1} is empty"}
        profs = store.profiles()
        k = next((n for n, x in enumerate(profs) if x.get("id") == profile_id), None)
        if k is None:
            return {"ok": False, "error": "No Investing strategy to load into"}
        profs[k] = slots.to_profile(profs[k], row["params"])
        store.save("profiles.json", profs)
        s = store.settings()
        s["scan_slot"] = {"slot": int(i), "name": row["name"], "profile": profile_id,
                          "loaded": datetime.now().isoformat(timespec="seconds")}
        store.save("settings.json", s)
        self._engine.reload()
        return {"ok": True, "slot": int(i), "name": row["name"], "profile": profs[k].get("name", profile_id)}

    # ---------- find best settings ----------
    def start_optimize(self, params=None, objective="cagr", min_trades=20):
        """Search stops, take profits, hold time and every filter on the first 70% of the period, check on the last 30%."""
        from engine import optimizer
        from engine import strategy_bt as sbt
        st = self.__dict__.setdefault("_opt_status", {"running": False})
        if st.get("running") or self._sbt_status.get("running"):
            return {"ok": False, "error": "A backtest is already running"}
        p = dict(self.strategy_bt_defaults())
        if not params:                                   # e.g. from Telegram: reuse the last Strategy Test's settings
            last = store.load(sbt.RESULT_FILE, None) or {}
            p.update({k: v for k, v in (last.get("params") or {}).items() if v is not None})
            p.update({"universe": last.get("mode", p.get("universe")),
                      "data_source": (last.get("data_source") or {}).get("source", "public"),
                      "years": (last.get("data_source") or {}).get("years", 5)})
        p.update({k: v for k, v in (params or {}).items() if v is not None})
        mode = "watchlist" if p.get("universe") == "watchlist" else "all"
        source = "fmp" if p.get("data_source") == "fmp" else "public"
        years = int(p.get("years") or 10) if source == "fmp" else 5
        ds = self._sbt_ds.get((mode, source, years)) or sbt.load_dataset(mode, source=source, years=years)
        if ds is None:
            return {"ok": False, "error": "Run the backtest once first (it downloads the data), then find the best settings"}
        self._opt_stop = False
        st.clear()
        st.update(running=True, stage="Starting", done=0, total=0, error=None)

        def run():
            try:
                res = optimizer.optimize(ds, p, st, objective=objective, min_trades=int(min_trades),
                                         should_stop=lambda: self._opt_stop)
                res["params"] = optimizer.to_params(res["best"])
                res["finished"] = datetime.now().isoformat(timespec="seconds")
                res["data_source"] = {"source": source, "years": years}
                store.save("strategy_bt_optimize.json", res)
                st.update(running=False, stage="Done")
            except Exception as ex:
                log(f"Find best settings failed: {ex}\n{traceback.format_exc(limit=4)}")
                st.update(running=False, error=str(ex), stage="Failed")
        threading.Thread(target=run, daemon=True).start()
        return {"ok": True}

    def optimize_status(self):
        return dict(self.__dict__.get("_opt_status", {"running": False}))

    def stop_optimize(self):
        self._opt_stop = True
        return {"ok": True}

    def get_optimize(self):
        return {"ok": True, "result": store.load("strategy_bt_optimize.json", None)}

    def strategy_bt_status(self):
        return dict(self._sbt_status)

    def stop_strategy_bt(self):
        self._sbt_stop = True
        return {"ok": True}

    def alerts_calendar(self, year=None, refresh=False):
        """Alert calendar for the daily scan: every setup the daily scan and scheduled profile scans alerted,
        with its P/L from the alert close to the latest price (and vs SPY over the same days)."""
        from engine import scan_journal
        from engine import strategy_bt as sbt
        from engine.scanner import Context
        rows = scan_journal.load()
        if not rows:
            return {"ok": False, "error": "No daily alerts recorded yet: every daily scan (and scheduled profile scan) adds its setups here from now on."}
        cache = self.__dict__.setdefault("_ajc", {})
        key = datetime.now().strftime("%Y-%m-%d %H") + f":{len(rows)}"          # re-price at most once an hour
        if refresh or cache.get("key") != key:
            tickers = sorted({r["ticker"] for r in rows})
            last = {}
            prov = self._engine.providers_with("quotes")
            if prov:
                try:
                    last = {t: q["last"] for t, q in prov[0].quotes(tickers + ["SPY"]).items() if q.get("last")}
                except Exception as ex:
                    log(f"Alert calendar quotes: {ex}")
            spy_closes, spy_last = {}, last.get("SPY")
            try:
                b = Context(self._engine, "SPY", {"id": "cal", "fast": 150, "slow": 200}, self._engine.shared_cache("SPY")).get("bars")
                spy_closes = {str(i.date()) if hasattr(i, "date") else str(i)[:10]: float(c) for i, c in zip(b.index, b["close"])}
                spy_last = spy_last or float(b["close"].iloc[-1])
            except Exception as ex:
                log(f"Alert calendar SPY: {ex}")
            for t in tickers:                                                   # no live quote: use the latest daily close
                if t not in last:
                    try:
                        bt = Context(self._engine, t, {"id": "cal", "fast": 150, "slow": 200}, self._engine.shared_cache(t)).get("bars")
                        last[t] = float(bt["close"].iloc[-1])
                    except Exception:
                        pass
            cache.update(key=key, days=scan_journal.graded_days(rows, last, spy_closes, spy_last),
                         priced=datetime.now().isoformat(timespec="minutes"))
        return {"ok": True, "partial": False, "live": True, "priced": cache.get("priced"),
                "params": {"fast": 150, "slow": 200}, **sbt.calendar(cache["days"], year)}

    def strategy_calendar(self, year=None):
        """Alert calendar for the Strategy Test: year / month summaries and one year's alerts by day."""
        from engine import strategy_bt as sbt
        days = store.load(sbt.ALERTS_FILE, None)
        partial = False
        if not days:
            days = (store.load(sbt.RESULT_FILE, None) or {}).get("alert_days") or []
            partial = bool(days)
        if not days:
            return {"ok": False, "error": "Run the Strategy Test first"}
        res = store.load(sbt.RESULT_FILE, None) or {}
        return {"ok": True, "partial": partial, "params": {"fast": (res.get("params") or {}).get("fast", 150),
                                                             "slow": (res.get("params") or {}).get("slow", 200)},
                **sbt.calendar(days, year)}

    def search_winners_losers(self, ticker=None, frm=None, to=None):
        """Best winners / worst losers of the last Strategy Test, for one ticker and/or an alert-date range."""
        from engine import strategy_bt as sbt
        days = store.load(sbt.ALERTS_FILE, None)
        partial = False
        if not days:
            days = (store.load(sbt.RESULT_FILE, None) or {}).get("alert_days") or []
            partial = bool(days)
        if not days:
            return {"ok": False, "error": "Run the Strategy Test first"}
        return {"ok": True, "extremes": sbt.search_winners_losers(days, ticker, frm, to), "partial": partial}

    def search_strategy_alerts(self, frm=None, to=None, ticker=None):
        """Every alert day of the last Strategy Test between two dates (and optionally one ticker)."""
        from engine import strategy_bt as sbt
        days = store.load(sbt.ALERTS_FILE, None)
        partial = False
        if not days:
            days = (store.load(sbt.RESULT_FILE, None) or {}).get("alert_days") or []
            partial = bool(days)
        if not days:
            return {"ok": False, "error": "Run the Strategy Test first"}
        out, summ = sbt.search_days(days, frm, to, ticker)
        return {"ok": True, "days": out, "summary": summ, "partial": partial, "range": [days[-1]["date"], days[0]["date"]]}

    def get_strategy_bt(self):
        from engine import strategy_bt as sbt
        return {"ok": True, "result": store.load(sbt.RESULT_FILE, None), "defaults": self.strategy_bt_defaults(),
                "fmp": bool(self._engine.providers_with("daily_bars")),
                "stops": sbt.STOP_GRID, "tps": sbt.TP_GRID, "status": dict(self._sbt_status)}

    # ---------- rotation heatmap ----------
    def get_rotation(self, group="Sectors", extra=None):
        """Sector / style / industry / macro rotation vs SPY, from daily bars (cached for the day)."""
        from engine import rotation as rot
        from engine.scanner import Context
        e = self._engine
        if not e.field_available("bars"):
            return {"ok": False, "needs": "Public.com", "error": "Rotation needs daily prices. Add your Public.com key on Data sources."}
        custom = store.settings().get("rotation_custom") or []
        groups = dict(rot.GROUPS)
        groups["My list"] = [(t, t) for t in custom] or [(t, t) for t in store.watchlist()[:25]]
        if group == "My list" and not groups["My list"]:
            return {"ok": False, "error": "My list is empty: type tickers above, or add some to your watchlist"}
        members = groups.get(group) or groups["Sectors"]
        names = dict(members)
        tickers = [t for t, _ in members]
        if "SPY" not in tickers:
            tickers = tickers + ["SPY"]
        bars, errors = {}, []
        for t in tickers:
            try:
                bars[t] = Context(e, t, {"id": "rotation", "fast": 150, "slow": 200}, e.shared_cache(t)).get("bars")
            except Exception as ex:
                errors.append(f"{t}: {ex}")
        if not bars:
            return {"ok": False, "error": "; ".join(errors[:2]) or "No prices"}
        rows = rot.analyse(bars, names)
        if group != "Size & style" and not any(t == "SPY" for t, _ in members):
            rows = [r for r in rows if r["ticker"] != "SPY"] + [r for r in rows if r["ticker"] == "SPY"]
            for r in rows:
                if r["ticker"] == "SPY":
                    r["benchmark"] = True
        return {"ok": True, "group": group, "groups": list(groups), "rows": rows, "summary": rot.summary(rows),
                "periods": [p for p, _ in rot.PERIODS], "errors": errors[:5],
                "as_of": datetime.now().isoformat(timespec="seconds")}

    def save_rotation_list(self, tickers):
        s = store.settings()
        s["rotation_custom"] = [str(t).strip().upper() for t in tickers or [] if str(t).strip()][:40]
        store.save("settings.json", s)
        return {"ok": True, "tickers": s["rotation_custom"]}

    # ---------- gamma (option chain from Public, read-only) ----------
    def get_gamma(self, ticker, mode="near", dates=None, ema_lengths=None):
        """Gamma exposure by strike, walls, flip, expirations, estimated flow and EMA confirmations."""
        import time as _t
        from datetime import date as _date, timedelta
        from engine import gamma as gamma_mod
        from engine.scanner import Context
        t = str(ticker or "").strip().upper()
        if not t:
            return {"ok": False, "error": "Enter a ticker"}
        e = self._engine
        provs = e.providers_with("option_chain")
        if not provs:
            return {"ok": False, "needs": "Public.com", "error": "Gamma needs option chains. Add your Public.com key on Data sources."}
        prov = provs[0]
        try:
            all_exps = prov.option_expirations(t)
        except Exception as ex:
            return {"ok": False, "error": f"No options found for {t}: {ex}"}
        today = _date.today()
        if dates:
            exps = [d for d in all_exps if d in set(dates)][:16]
        else:
            horizon = {"near": 45, "quarter": 100, "all": 400}.get(mode, 45)
            cap = {"near": 8, "quarter": 14, "all": 20}.get(mode, 8)
            exps = [d for d in all_exps if _date.fromisoformat(d) <= today + timedelta(days=horizon)][:cap] or all_exps[:3]
        key = (t, tuple(exps), tuple(ema_lengths or ()))
        hit = self._gamma_cache.get(key)
        if hit and _t.time() - hit[0] < 180:
            return hit[1]
        try:
            q, _ = e.call_first("quotes", [t])
            spot = (q.get(t) or {}).get("last")
        except Exception:
            spot = None
        lengths = sorted({int(x) for x in (ema_lengths or []) if 2 <= int(x) <= 400} | {9, 21, 50, 150, 200})
        ema_levels = {}
        try:
            bars = Context(e, t, {"id": "gamma", "fast": 150, "slow": 200}, e.shared_cache(t)).get("bars")
            from engine.alerts import completed_closes, live_ma
            closes = completed_closes(bars)
            spot = spot or float(bars["close"].iloc[-1])
            for n in lengths:
                v = live_ma(closes, spot, n, "EMA")
                if v:
                    ema_levels[f"EMA {n}"] = v
        except Exception:
            pass
        if not spot:
            return {"ok": False, "error": f"No price for {t}"}
        chains, errors = {}, []
        for d in exps:
            try:
                chains[d] = prov.option_chain(t, d)
            except Exception as ex:
                errors.append(f"{d}: {ex}")
            _t.sleep(0.15)
        if not chains:
            return {"ok": False, "error": "; ".join(errors[:2]) or "No option data"}
        res = gamma_mod.analyse(spot, chains, ema_levels=ema_levels)
        self._gamma_verdict[t] = res.pop("verdict_at")
        try:
            res["plan"] = gamma_mod.trade_levels(res, spot)
        except Exception as ex:
            log(f"Gamma plan {t}: {ex}")
        out = {"ok": True, "ticker": t, "all_expirations": all_exps, "used": sorted(chains), "mode": mode,
               "errors": errors[:5], "as_of": datetime.now().isoformat(timespec="seconds"), **res}
        self._gamma_cache[key] = (_t.time(), out)
        return out

    def _gamma_plan(self, ticker, entry=None):
        """Gamma-based take profit / stop loss for a long entry (None if options aren't available)."""
        from engine import gamma as gamma_mod
        if not self._engine.providers_with("option_chain"):
            return None
        g = self.get_gamma(ticker, "near")
        if not g.get("ok"):
            return None
        return gamma_mod.trade_levels(g, entry)

    def _add_gamma_plans(self, out, log_it=True, limit=15):
        """Attach a gamma TP/SL plan to each setup in a scan result, and record it for the forward test."""
        from engine import gamma_journal
        if not self._engine.providers_with("option_chain"):
            return
        n = 0
        for r in out.get("results", []):
            if r.get("status") != "setup" or n >= limit:
                continue
            n += 1
            try:
                pl = self._gamma_plan(r["ticker"], r.get("close"))
            except Exception as ex:
                log(f"Gamma plan {r['ticker']}: {ex}")
                continue
            if pl:
                r["gamma_plan"] = pl
                out["gamma_plans"] = True
                if log_it:
                    gamma_journal.add(r["ticker"], pl, "scan", day=(out.get("data_date") or "")[:10] or None)

    def gamma_plan(self, ticker, entry=None):
        t = str(ticker or "").strip().upper()
        if not t:
            return {"ok": False, "error": "Enter a ticker"}
        pl = self._gamma_plan(t, float(entry) if entry else None)
        return {"ok": bool(pl), "plan": pl, "error": None if pl else "No option data for " + t}

    def gamma_plan_results(self):
        """Forward test of every gamma plan sent so far: did the take profit or the stop hit first?"""
        from engine import gamma_journal
        from engine.scanner import Context
        e = self._engine
        if not e.field_available("bars"):
            return {"ok": False, "error": "Needs Public.com prices"}
        get = lambda t: Context(e, t, {"id": "gj", "fast": 150, "slow": 200}, e.shared_cache(t)).get("bars")
        return {"ok": True, **gamma_journal.evaluate(get)}

    # ---------- calls vs shares ----------
    def options_finder(self, ticker, max_exps=6):
        """Score the stock's real calls (Public chain) against the strategy's own track record -> calls or shares?"""
        import time as _t
        from datetime import date as _date, timedelta
        from engine import options as opt
        from engine import strategy_bt as sbt
        t = str(ticker or "").strip().upper()
        if not t:
            return {"ok": False, "error": "Enter a ticker"}
        e = self._engine
        provs = e.providers_with("option_chain")
        if not provs:
            return {"ok": False, "needs": "Public.com", "error": "Needs Public.com option chains"}
        cache = self.__dict__.setdefault("_opt_cache", {})
        hit = cache.get(t)
        if hit and _t.time() - hit[0] < 600:
            return hit[1]
        scen = opt.scenario_from_result(store.load(sbt.RESULT_FILE, None))
        prov = provs[0]
        try:
            exps = prov.option_expirations(t)
            q, _ = e.call_first("quotes", [t])
            spot = (q.get(t) or {}).get("last")
        except Exception as ex:
            return {"ok": False, "error": f"No options for {t}: {ex}"}
        if not spot:
            return {"ok": False, "error": f"No price for {t}"}
        today = _date.today()
        lo = today + timedelta(days=int(scen["days"] * 1.15 * 365 / 252))
        usable = [d for d in exps if lo <= _date.fromisoformat(d) <= today + timedelta(days=560)]
        if len(usable) > max_exps:                      # spread the picks across the range
            step = (len(usable) - 1) / (max_exps - 1)
            usable = [usable[round(i * step)] for i in range(max_exps)]
        chains = {}
        for d in usable:
            try:
                chains[d] = prov.option_chain(t, d)
            except Exception as ex:
                log(f"Options finder {t} {d}: {ex}")
            _t.sleep(0.15)
        if not chains:
            return {"ok": False, "error": f"No expirations for {t} far enough out ({scen['days']} trading days)"}
        f = opt.finder(float(spot), chains, scen)
        out = {"ok": True, "ticker": t, "expirations": sorted(chains), "as_of": datetime.now().isoformat(timespec="seconds"), **f}
        cache[t] = (_t.time(), out)
        return out

    def _options_labels(self, out, limit=10):
        from engine import options as opt
        if not self._engine.providers_with("option_chain"):
            return
        n = 0
        for r in out.get("results", []):
            if r.get("status") != "setup" or n >= limit:
                continue
            n += 1
            try:
                f = self.options_finder(r["ticker"])
                if f.get("ok"):
                    r["options"] = {k: f[k] for k in ("verdict", "why", "best", "steady", "shares", "scenario")}
            except Exception as ex:
                log(f"Options finder {r['ticker']}: {ex}")

    # ---------- support, order book, macro ----------
    def _book_targets(self):
        """Stocks worth watching the order book on: near a 150/200 EMA (last scan + screener), watchlist, alert tickers."""
        out = []
        last = store.load("last_scan.json", {}) or {}
        out += [r["ticker"] for r in last.get("results", []) if r.get("status") in ("setup", "approaching")]
        db = store.load("screener_db.json", None) or {}
        near = []
        for r in db.get("rows", []):
            p_ = r.get("price")
            for k in ("ema_150", "ema_200"):
                if p_ and r.get(k) and -1.0 <= (p_ / r[k] - 1) * 100 <= 4.0:
                    near.append((abs(p_ / r[k] - 1), r["ticker"]))
                    break
        out += [t for _, t in sorted(near)[:120]]
        out += store.watchlist()
        out += [a["ticker"] for a in self._alerts.alerts() if a.get("enabled", True) and a["kind"] in ("ma_touch", "ma_near")]
        return list(dict.fromkeys(out))[:200]

    def book_status(self, ticker=None):
        from engine import book
        st = {"ok": True, "enabled": store.settings().get("book_sampling", True), "market_open": alerts_mod.market_open(),
              "last_run": self._book.last_run, "last_count": self._book.last_count, "last_error": self._book.last_error,
              "watching": len(self._book_targets())}
        if ticker:
            t = str(ticker).strip().upper()
            st["ticker"] = t
            st["metrics"] = book.day_metrics(t)
            st["samples"] = (book.load_day() or {}).get(t, [])[-30:]
        return st

    def support_check(self, ticker, length=None, kind=None, side="above", live=True):
        """Every support signal for a stock right now, at the given EMA (default: whichever of 150/200 is closer)."""
        from engine import book, support
        from engine.scanner import Context
        t = str(ticker or "").strip().upper()
        if not t:
            return {"ok": False, "error": "Enter a ticker"}
        e = self._engine
        if not e.field_available("bars"):
            return {"ok": False, "error": "Needs Public.com prices"}
        inv = next((x for x in store.profiles() if x.get("id") == "investing"), {})
        kind = kind or inv.get("ma_type", "EMA")
        try:
            bars = Context(e, t, {"id": "support", "fast": 150, "slow": 200}, e.shared_cache(t)).get("bars")
        except Exception as ex:
            return {"ok": False, "error": str(ex)}
        c = bars["close"]
        ma = lambda n: float((c.rolling(n).mean() if kind == "SMA" else c.ewm(span=n, adjust=False).mean()).iloc[-1])
        if not length:
            f_, s_ = int(inv.get("fast", 150)), int(inv.get("slow", 200))
            low = float(bars["low"].iloc[-1])
            length = s_ if abs(low / ma(s_) - 1) < abs(low / ma(f_) - 1) else f_
        length = int(length)
        g = None
        if live and e.providers_with("option_chain"):
            try:
                g = self.get_gamma(t, "near", ema_lengths=[length])
            except Exception as ex:
                g = {"ok": False, "error": str(ex)}
        chk = support.check_today(bars, length, kind, side=side, gamma=g, book_metrics=book.day_metrics(t, ma(length)))
        chk["price"] = float(c.iloc[-1])
        chk["dist_pct"] = round((chk["price"] / chk["level"] - 1) * 100, 2)
        return {"ok": True, "ticker": t, **chk}

    def support_journal_results(self):
        from engine import support_journal
        from engine.scanner import Context
        e = self._engine
        if not e.field_available("bars"):
            return {"ok": False, "error": "Needs Public.com prices"}
        get = lambda t: Context(e, t, {"id": "sj", "fast": 150, "slow": 200}, e.shared_cache(t)).get("bars")
        return {"ok": True, **support_journal.evaluate(get)}

    def get_macro(self, refresh=False):
        from engine import macro
        if not self._engine.field_available("bars"):
            return {"ok": False, "error": "Needs Public.com prices"}
        try:
            if refresh:
                macro._CACHE.clear()
            return {"ok": True, **macro.snapshot(self._engine)}
        except Exception as ex:
            return {"ok": False, "error": str(ex)}

    def get_theme(self, ticker):
        from engine import macro
        t = str(ticker or "").strip().upper()
        try:
            etf, corr = macro.stock_theme(self._engine, t)
            snap = macro.snapshot(self._engine)
        except Exception as ex:
            return {"ok": False, "error": str(ex)}
        if not etf:
            return {"ok": False, "error": f"Couldn't match {t} to a theme ETF"}
        return {"ok": True, "ticker": t, "etf": etf, "corr": corr, "theme": snap["themes"].get(etf),
                "into": snap["into"], "out_of": snap["out_of"]}

    # every switchable scan check, for the Telegram /toggles command
    TOGGLE_GROUPS = ("Support", "Macro", "Market")

    def list_toggles(self, profile_id="investing"):
        prof = next((x for x in store.profiles() if x.get("id") == profile_id), None) or {}
        rows = []
        for r in self._engine.registry.rules:
            if r.group not in self.TOGGLE_GROUPS and r.id not in ("ma_touch", "debt_filter", "not_extended", "no_earnings_soon", "pullback_speed", "rel_weakness", "touch_number", "slow_rising"):
                continue
            cfg = (prof.get("rules") or {}).get(r.id) or {}
            rows.append({"id": r.id, "name": r.name, "group": r.group, "enabled": cfg.get("enabled", r.default_enabled)})
        order = {"Trend": 0, "Fundamentals": 1, "Support": 2, "Macro": 3, "Market": 4}
        live = lambda x: "(live)" in x["name"]
        rows.sort(key=lambda x: (order.get(x["group"], 9), live(x), x["name"]))
        return {"ok": True, "profile": prof.get("name", profile_id), "toggles": rows}

    def set_toggle(self, rule_id, on, profile_id="investing", params=None):
        profs = store.profiles()
        prof = next((x for x in profs if x.get("id") == profile_id), None)
        rule = self._engine.registry.rule(rule_id)
        if prof is None or rule is None:
            return {"ok": False, "error": f"No check called {rule_id}"}
        cfg = dict((prof.setdefault("rules", {}).get(rule_id)) or {})
        cfg["enabled"] = bool(on)
        if params:
            cfg["params"] = dict(cfg.get("params") or {}, **params)
        prof["rules"][rule_id] = cfg
        store.save("profiles.json", profs)
        self._engine.reload()
        return {"ok": True, "id": rule_id, "name": rule.name, "enabled": bool(on), "profile": prof.get("name", profile_id)}

    def _support_labels(self, out, limit=25, journal=True):
        """Support check + theme on every touch alert in a scan; saved for the live forward test."""
        from engine import book, macro, support, support_journal
        from engine.scanner import Context
        e = self._engine
        n = 0
        day = (out.get("data_date") or datetime.now().date().isoformat())[:10]
        for r in out.get("results", []):
            if r.get("status") != "setup" or n >= limit:
                continue
            n += 1
            try:
                prof = next((x for x in store.profiles() if x.get("id") == r.get("profile")), {}) or {}
                kind = prof.get("ma_type", "EMA")
                res_side = (r.get("touched_fast_r") or r.get("touched_slow_r")) and not (r.get("touched_fast") or r.get("touched_slow"))
                bars = Context(e, r["ticker"], {"id": "support", "fast": 150, "slow": 200}, e.shared_cache(r["ticker"])).get("bars")
                c = bars["close"]
                f_len, s_len = int(prof.get("fast", 150)), int(prof.get("slow", 200))
                if any(r.get(k) for k in ("touched_fast", "touched_slow", "touched_fast_r", "touched_slow_r")):
                    use_slow = r.get("touched_slow") or r.get("touched_slow_r")
                else:                                   # no touch flags (e.g. zone strategies): the line closest to today's low
                    ma_ = lambda n_: float((c.rolling(n_).mean() if kind == "SMA" else c.ewm(span=n_, adjust=False).mean()).iloc[-1])
                    low = float(bars["low"].iloc[-1])
                    use_slow = abs(low / ma_(s_len) - 1) < abs(low / ma_(f_len) - 1)
                length = s_len if use_slow else f_len
                lvl = float((c.rolling(length).mean() if kind == "SMA" else c.ewm(span=length, adjust=False).mean()).iloc[-1])
                g = self.get_gamma(r["ticker"], "near", ema_lengths=[length]) if e.providers_with("option_chain") else None
                chk = support.check_today(bars, length, kind, side="below" if res_side else "above", gamma=g,
                                          book_metrics=book.day_metrics(r["ticker"], lvl))
                r["support_check"] = chk
                if journal:
                    support_journal.add(r["ticker"], day, chk, side="below" if res_side else "above")
                etf, corr = macro.stock_theme(e, r["ticker"], bars)
                th = macro.snapshot(e)["themes"].get(etf) if etf else None
                if th:
                    r["theme"] = {"etf": etf, "corr": corr, **th}
            except Exception as ex:
                log(f"Support check {r['ticker']}: {ex}")

    def _sector_info(self, ticker):
        """Sector + today's rotation quadrant + valuation score for one stock (for alert labels)."""
        from engine import sector_filter as sf
        try:
            sec = sf.sector_of(self._engine, ticker)
        except Exception as ex:
            log(f"Sector lookup {ticker}: {ex}")
            sec = None
        if not sec:
            return {"sector": None}
        return sf.live(self._engine, sec)

    def _alert_note(self, alert, info):
        """Added under every alert message: the stock's sector (with rotation and valuation), then a gamma read for EMA alerts."""
        from engine import sector_filter as sf
        lines = []
        if store.settings().get("sector_in_alerts", True):
            si = self._sector_info(alert["ticker"])
            if not store.settings().get("telegram_detailed", False):      # short alerts: sector name only
                return f"{si.get('sector') or ''}" + (f" ({si['quadrant']})" if si.get("quadrant") else "") if si.get("sector") else ""
            lines.append("🏷 " + sf.tag(si))
        elif not store.settings().get("telegram_detailed", False):
            return ""
        if alert.get("kind") in ("ma_touch", "ma_near"):
            hl = self._level_note(alert, info)
            if hl:
                lines.append(hl)
            if store.settings().get("support_in_alerts", True) and alert.get("kind") == "ma_touch":
                try:
                    side = alert.get("direction") if alert.get("direction") in ("above", "below") else (info or {}).get("from") or "above"
                    sc = self.support_check(alert["ticker"], int(alert.get("length") or 0) or None, alert.get("ma_type", "EMA"), side=side, live=False)
                    if sc.get("ok"):
                        from engine import support
                        lines.append(support.summary_line(sc))
                except Exception as ex:
                    log(f"Support note {alert['ticker']}: {ex}")
            g = self._gamma_note(alert, info)
            if g:
                lines.append(g)
        return "\n".join(lines)

    def _level_note(self, alert, info):
        """'📊 EMA 200 as resistance (strong): turned price back 7 of 9 times...' for MA alerts (cached per day)."""
        from engine import backtest
        from engine.scanner import Context
        if not store.settings().get("level_history_in_alerts", True):
            return ""
        d = alert.get("direction", "either")
        side = d if d in ("above", "below") else (info or {}).get("from") or "above"
        key = (alert["ticker"], int(alert.get("length") or 0), alert.get("ma_type", "EMA"), side, datetime.now().date())
        cache = self.__dict__.setdefault("_level_cache", {})
        if key not in cache:
            e = self._engine
            bars = Context(e, alert["ticker"], {"id": "lvl", "fast": 150, "slow": 200}, e.shared_cache(alert["ticker"])).get("bars")
            cache[key] = backtest.level_line(backtest.level_history(bars, key[1], key[2], side=side))
        return cache[key]

    def _label_sectors(self, out, limit=60):
        """Sector, rotation quadrant and valuation score on every setup / approaching stock in a scan."""
        n = 0
        for r in out.get("results", []):
            if r.get("status") not in ("setup", "approaching") or n >= limit:
                continue
            n += 1
            si = self._sector_info(r["ticker"])
            r["sector"] = si.get("sector")
            if r.get("debt_pct_mcap") is None and r.get("debt_pct_rev") is None:
                try:
                    from engine.scanner import Context
                    cx = Context(self._engine, r["ticker"], {"id": "debt", "fast": 150, "slow": 200}, self._engine.shared_cache(r["ticker"]))
                    debt, mc, rv = cx.get("debt_total"), cx.get("market_cap"), cx.get("revenue_ttm")
                    if debt is not None:
                        r["debt_pct_mcap"] = debt / mc * 100 if mc else None
                        r["debt_pct_rev"] = debt / rv * 100 if rv and rv > 0 else None
                        eq_ = cx.get("equity_total")
                        r["debt_to_equity"] = debt / eq_ if eq_ and eq_ > 0 else None
                except Exception as ex:
                    log(f"Debt label {r['ticker']}: {ex}")
            if r.get("beta") is None:
                try:
                    from engine import beta as beta_
                    from engine.scanner import Context
                    cx = Context(self._engine, r["ticker"], {"id": "beta", "fast": 150, "slow": 200}, self._engine.shared_cache(r["ticker"]))
                    sb, mb = cx.get("bars"), cx.other("SPY").get("bars")
                    if sb is not None and mb is not None:
                        b_ = beta_.from_prices(sb["close"].values, mb["close"].reindex(sb.index).values)
                        r["beta"] = round(b_, 2) if b_ is not None else None
                except Exception as ex:
                    log(f"Beta label {r['ticker']}: {ex}")
            for k_src, k_dst in (("etf", "sector_etf"), ("quadrant", "sector_quadrant"), ("score", "sector_value"),
                                 ("value", "sector_value_label")):
                if si.get(k_src) is not None:
                    r[k_dst] = si[k_src]

    def _gamma_note(self, alert, info):
        """One-line gamma read added to EMA alerts (only if settings.gamma_in_alerts and Public options work)."""
        if not store.settings().get("gamma_in_alerts", True) or not self._engine.providers_with("option_chain"):
            return ""
        if alert.get("ma_type", "EMA") != "EMA":
            return ""
        n = int(alert.get("length") or 0)
        g = self.get_gamma(alert["ticker"], "near", ema_lengths=[n])
        if not g.get("ok"):
            return ""
        c = next((x for x in g["confirmations"] if x["name"] == f"EMA {n}"), None)
        bits = [f"Gamma: {'positive' if g['regime'] == 'positive' else 'negative'}"]
        if g.get("flip"):
            bits.append(f"flip ${g['flip']:,.0f}")
        if g.get("put_wall_below"):
            bits.append(f"put wall ${g['put_wall_below']:,.0f}")
        if g.get("call_wall_above"):
            bits.append(f"call wall ${g['call_wall_above']:,.0f}")
        line = "🧲 " + " · ".join(bits)
        if c:
            line += f"\n→ {c['label']} ({'; '.join(c['why'])})"
        if store.settings().get("gamma_levels_in_scan", True):
            from engine import gamma as gamma_mod, gamma_journal
            pl = gamma_mod.trade_levels(g, (info or {}).get("price") or g.get("spot"))
            if pl and (pl.get("tp") or pl.get("sl")):
                line += "\n" + gamma_mod.plan_line(pl)
                gamma_journal.add(alert["ticker"], pl, "alert")
        return line

    def gamma_check(self, ticker, price):
        """Will price likely reject at / move fast through `price`? Uses the last gamma loaded for the ticker."""
        t = str(ticker or "").strip().upper()
        fn = self._gamma_verdict.get(t)
        if fn is None:
            r = self.get_gamma(t)
            if not r.get("ok"):
                return r
            fn = self._gamma_verdict.get(t)
        try:
            return {"ok": True, **fn(float(price))}
        except Exception as ex:
            return {"ok": False, "error": str(ex)}

    # ---------- EMA finder ----------
    def find_emas(self, ticker, params=None):
        """Which EMA length this stock has respected most over ~5 years of daily prices."""
        from engine import ema_finder
        from engine.scanner import Context
        t = str(ticker or "").strip().upper()
        if not t:
            return {"ok": False, "error": "Enter a ticker"}
        e = self._engine
        if not e.field_available("bars"):
            return {"ok": False, "error": "The EMA finder needs daily prices. Add your Public.com key on Data sources."}
        p = {k: v for k, v in (params or {}).items() if v not in (None, "")}
        try:
            bars = Context(e, t, {"id": "finder", "fast": 150, "slow": 200}, e.shared_cache(t)).get("bars")
            res = ema_finder.run(bars, **{k: (v if k == "kind" else float(v)) for k, v in p.items()
                                          if k in ("min_len", "max_len", "step", "kind", "tolerance", "break_pct",
                                                   "bounce_pct", "lookahead", "cooldown", "min_tests")})
        except Exception as ex:
            return {"ok": False, "error": str(ex)}
        return {"ok": True, "ticker": t, **res}

    # ---------- backtest ----------
    def run_backtest(self, ticker, params=None):
        """Every 150/200 EMA pullback in the last ~5 years of daily prices and what happened next."""
        from engine import backtest as bt
        from engine.scanner import Context
        t = str(ticker or "").strip().upper()
        if not t:
            return {"ok": False, "error": "Enter a ticker"}
        e = self._engine
        if not e.field_available("bars"):
            return {"ok": False, "error": "Backtests need daily prices. Add your Public.com key on Data sources."}
        # the Investing strategy's own settings, overridden by anything passed in
        inv = next((x for x in store.profiles() if x.get("id") == "investing"), {})
        rp = (inv.get("rules", {}).get("ma_touch", {}) or {}).get("params", {})
        p = {"fast": inv.get("fast", 150), "slow": inv.get("slow", 200), "kind": inv.get("ma_type", "EMA"),
             "tolerance": rp.get("tolerance", 0.5), "above_days": rp.get("above_days", 15), "hold": rp.get("hold", True),
             "side": {"From below (rally into resistance)": "below", "Both": "both"}.get(rp.get("side"), "above")}
        p.update({k: v for k, v in (params or {}).items() if v is not None})
        try:
            bars = Context(e, t, {"id": "backtest", "fast": 150, "slow": 200}, e.shared_cache(t)).get("bars")
            res = bt.run(bars, fast=int(p.get("fast", 150)), slow=int(p.get("slow", 200)), kind=p.get("kind", "EMA"),
                         tolerance=float(p.get("tolerance", 0.5)), above_days=int(p.get("above_days", 15)),
                         hold=bool(p.get("hold", True)), cooldown=int(p.get("cooldown", 10)),
                         mode=p.get("mode", "touch"), side=p.get("side", "above") if p.get("side") in ("above", "below", "both") else "above",
                         require=p.get("require"))
        except Exception as ex:
            return {"ok": False, "error": str(ex)}
        return {"ok": True, "ticker": t, **res}

    def get_compare(self, tickers):
        from engine.scanner import Context
        e = self._engine
        res = []
        for t in [str(x).strip().upper() for x in (tickers or []) if str(x).strip()][:4]:
            r = dict(self.get_research(t, with_segments=False))
            try:
                if e.field_available("bars_10y"):
                    df = Context(e, t, {"id": "chart", "fast": 150, "slow": 200}, e.shared_cache(t)).get("bars_10y")
                    w = df["close"].resample("W-FRI").last().dropna() if df is not None else None
                    r["prices"] = {"t": [d.strftime("%Y-%m-%d") for d in w.index], "c": [round(float(x), 4) for x in w]}
            except Exception as ex:
                r.setdefault("errors", {})["prices"] = str(ex)
            res.append(r)
        return {"ok": True, "items": res}

    # ---------- screener ----------
    def build_screener(self, min_cap_b=None):
        if self._screener.status.get("running"):
            return {"ok": False, "error": "The screener data is already updating"}
        s = store.settings()
        cap = float(min_cap_b or s.get("screener_min_cap_b", 2))
        s["screener_min_cap_b"] = cap
        store.save("settings.json", s)

        def run():
            try:
                self._screener.build(cap)
            except Exception:
                pass
        threading.Thread(target=run, daemon=True).start()
        return {"ok": True}

    def stop_screener(self):
        self._screener.stop()
        return {"ok": True}

    def screener_status(self):
        return dict(self._screener.status)

    def get_screener_db(self):
        db = store.load("screener_db.json", None)
        if db:
            watch = set(store.watchlist())
            for r in db["rows"]:
                r["in_watchlist"] = r["ticker"] in watch
        return {"ok": True, "db": db}

    def sector_overlay(self):
        """Today's rotation quadrant and valuation score per sector (the Screener loads this in the background)."""
        from engine import rotation as rot, sector_filter as sf
        if not self._engine.field_available("bars"):
            return {"ok": False, "error": "Needs Public.com prices"}
        out = {}
        for sec, etf in rot.SECTOR_ETF.items():
            out[sec] = sf.live(self._engine, sec)
        return {"ok": True, "sectors": out}

    def screener_enrich(self, tickers, fields):
        """Fetch fields only optional sources have (forward P/E, analyst rating...) for a short list."""
        from engine.scanner import Context
        e = self._engine
        out, errors = {}, []
        cal = {}
        if "next_earnings_date" in fields and e.providers_with("earnings_calendar"):
            today = datetime.now().date()
            try:
                from datetime import timedelta
                events, _ = e.call_first("earnings_calendar", today.isoformat(),
                                         (today + timedelta(days=90)).isoformat())
                for ev in events:
                    cal.setdefault(ev["symbol"], ev["date"])
            except Exception as ex:
                errors.append(str(ex))
        for t in tickers[:150]:
            row = {}
            for f in fields:
                if f == "next_earnings_date" and cal is not None and e.providers_with("earnings_calendar"):
                    row[f] = cal.get(t)
                    continue
                if not e.field_available(f):
                    continue
                try:
                    row[f] = Context(e, t, {"id": "screener", "fast": 150, "slow": 200}, e.shared_cache(t)).get(f)
                except Exception as ex:
                    errors.append(f"{t}: {ex}")
            out[t] = row
        return {"ok": True, "values": out, "errors": errors[:10]}

    def save_screens(self, screens):
        store.save("screens.json", screens or [])
        return {"ok": True}

    # ---------- calendar ----------
    def get_calendar(self, start, end):
        e = self._engine
        watch = set(store.watchlist()) | set(store.load("bar_watchlist.json", []))
        info = store.load("company_info.json", {})
        past = {t: info[t].get("last_earnings_date") for t in watch if t in info}
        if not e.providers_with("earnings_calendar"):
            return {"ok": True, "available": False, "events": [], "past": past,
                    "needs": "Finnhub or Alpha Vantage"}
        try:
            events, src = e.call_first("earnings_calendar", start, end)
        except Exception as ex:
            return {"ok": False, "available": True, "error": str(ex), "events": [], "past": past}
        caps = {}
        db = store.load("screener_db.json", None)
        if db:
            caps = {r["ticker"]: r.get("market_cap") for r in db["rows"]}
        else:
            for name in ("universe_5B.json", "universe_2B.json", "universe_1B.json"):
                caps.update(store.load(name, {}).get("market_caps", {}))
        for ev in events:
            ev["watch"] = ev["symbol"] in watch
            cap = caps.get(ev["symbol"])
            ev["market_cap"] = cap
            ev["major"] = bool(cap and cap >= 10e9)
        return {"ok": True, "available": True, "source": src, "events": events, "past": past,
                "has_caps": bool(caps)}

    # ---------- alerts ----------
    def list_alerts(self):
        lst = self._alerts.alerts()
        info = store.load("company_info.json", {}) or {}           # cached sectors only: no network here
        sec = lambda t: (info.get(t) or {}).get("sic_sector")
        missing = [x["ticker"] for x in lst if x["ticker"] not in info]
        if missing:
            threading.Thread(target=self._cache_sectors, args=(missing[:20],), daemon=True).start()
        for a in lst:
            a["description"] = alerts_mod.describe(a)
            a["sector"] = sec(a["ticker"])
        hist = self._alerts.history()[:50]
        for h in hist:
            h["sector"] = sec(h["ticker"])
        return {"ok": True, "alerts": lst, "history": hist,
                "market_open": alerts_mod.market_open(), "last_check": self._alerts.last_check,
                "last_error": self._alerts.last_error, "quotes": self._engine.field_available("bars")}

    def _cache_sectors(self, tickers):
        from engine import sector_filter as sf
        for t in tickers:
            try:
                sf.sector_of(self._engine, t)
            except Exception:
                pass

    def save_alert(self, alert):
        try:
            return {"ok": True, "alert": self._alerts.save_alert(alert)}
        except Exception as ex:
            return {"ok": False, "error": str(ex)}

    def delete_alert(self, alert_id):
        self._alerts.delete_alert(alert_id)
        return {"ok": True}

    def check_alerts_now(self):
        try:
            fired = self._alerts.check_now()
            return {"ok": True, "fired": len(fired)}
        except Exception as ex:
            return {"ok": False, "error": str(ex)}

    # ---------- bottom watchlist bar ----------
    def get_bar(self):
        tickers = store.load("bar_watchlist.json", [])
        if not self._engine.field_available("bars"):
            return {"ok": True, "rows": [{"ticker": t} for t in tickers], "needs": "Public.com"}
        try:
            return {"ok": True, "rows": alerts_mod.bar_rows(self._engine, tickers)}
        except Exception as ex:
            return {"ok": False, "error": str(ex), "rows": [{"ticker": t} for t in tickers]}

    def save_bar(self, tickers):
        clean = []
        for t in tickers or []:
            t = str(t).strip().upper()
            if t and t not in clean:
                clean.append(t)
        store.save("bar_watchlist.json", clean)
        return {"ok": True, "tickers": clean}

    # ---------- your data: where it lives, backups ----------
    def data_info(self):
        return {"ok": True, "home": str(paths.HOME), "data": str(paths.DATA_DIR),
                "backups_folder": str(backup_mod._documents_dir()),
                "backups": backup_mod.list_backups()[:15],
                "alerts": len(self._alerts.alerts()), "watchlist": len(store.watchlist())}

    def backup_now(self, include_keys=True):
        try:
            path = backup_mod.backup_now(bool(include_keys))
            return {"ok": True, "path": str(path)}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def _dialog(self, kind):
        import webview
        win = webview.windows[0] if webview.windows else None
        if win is None:
            return None
        FD = getattr(webview, "FileDialog", None)
        if kind == "folder":
            mode = FD.FOLDER if FD else webview.FOLDER_DIALOG
            res = win.create_file_dialog(mode)
        else:
            mode = FD.OPEN if FD else webview.OPEN_DIALOG
            res = win.create_file_dialog(mode, directory=str(backup_mod._documents_dir()),
                                         file_types=("Goyim Screener backup (*.json)", "All files (*.*)"))
        if not res:
            return None
        return res[0] if isinstance(res, (list, tuple)) else res

    def restore_backup(self, path=None, keep_current_keys=True):
        try:
            path = path or self._dialog("file")
            if not path:
                return {"ok": False, "cancelled": True}
            out = backup_mod.restore(path, bool(keep_current_keys))
            self._engine.reload()
            return {"ok": True, **out}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def import_old_folder(self):
        try:
            folder = self._dialog("folder")
            if not folder:
                return {"ok": False, "cancelled": True}
            found = backup_mod.import_folder(folder)
            self._engine.reload()
            return {"ok": True, "files": found}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    # ---------- plugins / files ----------
    def reload_plugins(self):
        self._engine.reload()
        return self.get_state()

    def open_folder(self, which="home"):
        target = {"providers": paths.PROVIDERS_DIR, "rules": paths.RULES_DIR,
                  "data": paths.DATA_DIR}.get(which, paths.HOME)
        target.mkdir(parents=True, exist_ok=True)
        if sys.platform.startswith("win"):
            os.startfile(target)  # noqa
        elif sys.platform == "darwin":
            subprocess.Popen(["open", str(target)])
        else:
            subprocess.Popen(["xdg-open", str(target)])
        return {"ok": True}

    def open_url(self, url):
        import webbrowser
        if str(url).startswith("https://"):
            webbrowser.open(url)
        return {"ok": True}


def selftest():
    """Used by the GitHub build to check the packaged app can load its engine and plugins."""
    paths.ensure_user_files()
    eng = Engine(log=lambda m: None)
    import pandas  # noqa: F401  (plugins need these inside the .exe)
    import public_api_sdk  # noqa: F401
    import webview  # noqa: F401
    ok = not eng.registry.errors and len(eng.registry.rules) > 0 and all((paths.UI_DIR / f).exists() for f in ("index.html", "app.js", "pages.js", "icons.js", "style.css"))
    report = Path.cwd() / "selftest.txt"
    report.write_text(f"providers={[p.name for p in eng.providers]}\nrules={len(eng.registry.rules)}\n"
                      f"errors={eng.registry.errors}\nui={paths.UI_DIR}\nok={ok}\n", encoding="utf-8")
    print(report.read_text())
    return 0 if ok else 1


def unblock_downloaded_files():
    """Windows marks files from internet downloads as 'blocked', and the .NET part of the window
    (pythonnet) refuses to load blocked DLLs. Remove that mark from the app's own files."""
    if not (paths.FROZEN and sys.platform.startswith("win")):
        return
    for root, _dirs, files in os.walk(paths.BUNDLE_DIR):
        for name in files:
            if name.lower().endswith((".dll", ".pyd", ".exe")):
                try:
                    os.remove(os.path.join(root, name) + ":Zone.Identifier")
                except OSError:
                    pass


def main():
    if "--selftest" in sys.argv:
        sys.exit(selftest())

    unblock_downloaded_files()
    import webview

    api = Api()
    api._book.start()         # samples bid/ask sizes once a minute while the market is open
    api._bot.start()          # answers /commands sent to your Telegram bot while the app is open
    theme = store.settings().get("theme", "dark")
    webview.create_window(
        "Goyim Screener", url=str(paths.UI_DIR / "index.html"), js_api=api,
        width=1320, height=860, min_size=(1024, 680),
        background_color="#FFFFFF" if theme == "light" else "#000000",
    )
    webview.start(debug="--debug" in sys.argv)


if __name__ == "__main__":
    main()
