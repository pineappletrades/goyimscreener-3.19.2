"""Telegram alerts."""
import html

import requests

MAX_LEN = 4000


def _detailed():
    try:
        from . import store
        return bool(store.settings().get("telegram_detailed", False))
    except Exception:
        return False


def _short_setup(r, e):
    """One setup in 2–3 lines: ticker, grade, what it touched, price vs the lines, sector, stop/target."""
    tag = ""
    if r.get("touched_fast") and r.get("touched_slow"):
        tag = f"touched {r.get('fast_label', 'fast')} + {r.get('slow_label', 'slow')}"
    elif r.get("touched_fast"):
        tag = f"touched {r.get('fast_label', 'fast MA')}"
    elif r.get("touched_slow"):
        tag = f"touched {r.get('slow_label', 'slow MA')}"
    elif r.get("touched_fast_r") or r.get("touched_slow_r"):
        tag = "tested the line from below"
    elif r.get("entered_zone_today"):
        tag = "entered the zone"
    elif r.get("reversal_candle"):
        tag = "reversal candle"
    lines = [f"<b>{e(r['ticker'])}</b> {r.get('grade') or ''}" + (f" · {e(tag)}" if tag else "") + f"  <i>{e(r['profile_name'])}</i>"]
    if r.get("close") is not None:
        bits = [f"${r['close']:.2f}"]
        if r.get("ma_fast") is not None:
            bits.append(f"{r.get('fast_label', 'fast')} {r.get('dist_fast_pct', 0):+.1f}%")
        if r.get("ma_slow") is not None:
            bits.append(f"{r.get('slow_label', 'slow')} {r.get('dist_slow_pct', 0):+.1f}%")
        if r.get("sector"):
            bits.append(r["sector"] + (f" ({r['sector_quadrant']})" if r.get("sector_quadrant") else ""))
        lines.append(e(" · ".join(bits)))
    gp, p = r.get("gamma_plan"), r.get("plan")
    if gp and (gp.get("tp") or gp.get("sl")):
        bits = []
        if gp.get("tp"):
            bits.append(f"TP ${gp['tp']['price']:,.2f} ({gp.get('tp_pct', 0):+.1f}%)")
        if gp.get("sl"):
            bits.append(f"SL ${gp['sl']['price']:,.2f} ({gp.get('sl_pct', 0):+.1f}%)")
        lines.append(" · ".join(bits))
    elif p:
        lines.append(f"Stop ${p['stop']} · 2R ${p['target_2r']}")
    return "\n".join(lines)


def build_message(scan: dict, detailed=None) -> str:
    """detailed=None follows Settings → 'Detailed Telegram alerts' (off = short alerts)."""
    detailed = _detailed() if detailed is None else bool(detailed)
    e = html.escape
    res = scan.get("results", [])
    setups = [r for r in res if r["status"] == "setup" and r.get("grade") in ("A", "B", None)]
    setups.sort(key=lambda r: (r.get("grade") or "Z", r["ticker"]))
    appr = [r for r in res if r["status"] == "approaching"]

    m = scan.get("market")
    head = [f"<b>Goyim Screener Scan — {e(str(scan.get('data_date') or scan.get('run_at', '')[:10]))}</b>"]
    if scan.get("slot_test"):
        stt = scan["slot_test"]
        who = e(stt["name"]) if stt.get("slot", 0) < 0 else f"saved profile {stt['slot'] + 1}: {e(stt['name'])}"
        if stt.get("scheduled"):
            head.append(f"⏰ <b>Scheduled scan · {who}</b> ({'watchlist' if stt.get('universe') == 'watchlist' else 'all stocks'})")
        else:
            head.append(f"🧪 <b>Test scan with {who}</b> "
                        f"({'watchlist' if stt.get('universe') == 'watchlist' else 'all stocks'}) — not your daily scan"
                        + (f"\n<i>{e(stt['describe'])}</i>" if stt.get("describe") else ""))
    parts = ["\n".join(head)]
    if not detailed:
        mc = scan.get("macro") or {}
        if mc.get("regime"):
            parts[0] += f"\nMacro: {e(str(mc['regime']))}" + (f" {mc['score']:+.1f}" if mc.get("score") is not None else "")
    if detailed and scan.get("macro"):
        try:
            from .macro import lines as macro_lines
            ml = macro_lines(scan["macro"])
            if ml:
                parts.append("\n".join(ml))
        except Exception:
            pass
    if detailed and scan.get("valuation"):
        try:
            from .valuation import telegram_lines
            vl = telegram_lines(scan["valuation"])
            if vl:
                parts.append("\n".join(vl))
        except Exception:
            pass
    rot = scan.get("rotation") if detailed else None
    if rot and rot.get("summary"):
        sm = rot["summary"]
        rl = ["🔄 <b>Sector rotation</b> (vs SPY)"]
        for q, icon in (("Leading", "🟢"), ("Improving", "🔵"), ("Weakening", "🟡"), ("Lagging", "🔴")):
            if sm.get(q):
                rl.append(f"{icon} {q}: {', '.join(sm[q])}")
        if sm.get("turning_up"):
            rl.append("Turning up: " + ", ".join(sm["turning_up"]))
        if sm.get("rolling_over"):
            rl.append("Rolling over: " + ", ".join(sm["rolling_over"]))
        if len(rl) > 1:
            parts.append("\n".join(rl))
    for prof, names in (scan.get("not_checked") or {}).items():
        parts.append(f"⚠️ <b>{e(prof)}</b> didn't check: " + e("; ".join(names)) + ". Add a data source to include these.")
    if scan.get("fatal"):
        parts.append(f"⚠️ <b>Scan stopped:</b> {e(scan['fatal'])}\nFix it in the app's Data sources page.")

    for r in setups:
        if not detailed:
            parts.append(_short_setup(r, e))
            continue
        tags = []
        if r.get("entered_zone_today"):
            tags.append("🆕 ENTERED ZONE")
        if r.get("reversal_candle") and not (r.get("touched_fast") or r.get("touched_slow")):
            tags.append("🟢 REVERSAL")
        if r.get("touched_fast"):
            tags.append(f"📍 TOUCHED {r.get('fast_label', 'fast MA')}")
        if r.get("touched_slow"):
            tags.append(f"📍 TOUCHED {r.get('slow_label', 'slow MA')}")
        if r.get("touched_fast_r"):
            tags.append(f"🔺 TESTED {r.get('fast_label', 'fast MA')} FROM BELOW (resistance)")
        if r.get("touched_slow_r"):
            tags.append(f"🔺 TESTED {r.get('slow_label', 'slow MA')} FROM BELOW (resistance)")
        lines = [f"<b>{e(r['ticker'])}</b>  Grade {r.get('grade') or '-'}  ·  {e(r['profile_name'])}"
                 + (f"  |  {' · '.join(tags)}" if tags else "")]
        if r.get("close") is not None:
            lines.append(f"${r['close']:.2f}  |  {r.get('fast_label', 'fast')} ${r.get('ma_fast', 0):.2f} "
                         f"({r.get('dist_fast_pct', 0):+.1f}%)  |  {r.get('slow_label', 'slow')} ${r.get('ma_slow', 0):.2f} "
                         f"({r.get('dist_slow_pct', 0):+.1f}%)")
        fund = []
        if r.get("revenue_yoy"):
            fund.append("Rev YoY " + ", ".join("n/a" if x is None else f"{x:+.0f}%" for x in r["revenue_yoy"][:4]))
        if r.get("eps_yoy_pct") and r["eps_yoy_pct"][0] is not None:
            fund.append(f"EPS YoY {r['eps_yoy_pct'][0]:+.0f}%")
        if r.get("fcf_ttm") is not None:
            fund.append(f"FCF ${r['fcf_ttm'] / 1e9:,.2f}B")
        if r.get("market_cap"):
            fund.append(f"Mkt cap ${r['market_cap'] / 1e9:,.0f}B")
        if r.get("debt_pct_mcap") is not None or r.get("debt_pct_rev") is not None:
            bits_ = [f"{r['debt_pct_mcap']:.0f}% of mkt cap" if r.get("debt_pct_mcap") is not None else None,
                     f"{r['debt_pct_rev']:.0f}% of revenue" if r.get("debt_pct_rev") is not None else None,
                     f"D/E {r['debt_to_equity']:.2f}" if r.get("debt_to_equity") is not None else None]
            fund.append("Debt " + ", ".join(b_ for b_ in bits_ if b_))
        if r.get("ext_spread") is not None:
            fund.append(f"Fast {r['ext_spread']:+.1f}% vs slow" + (f", peak {r['ext_peak']:+.0f}% above slow" if r.get("ext_peak") is not None else ""))
        if r.get("beta") is not None:
            from .beta import describe as _bdesc
            fund.append(f"Beta {r['beta']:.2f} ({_bdesc(r['beta'])})")
        if fund:
            lines.append("  |  ".join(fund))
        eqb = []
        if r.get("pb_drop") is not None:
            eqb.append(f"fell {-r['pb_drop']:.1f}% into the line" + (f" (gap {r['pb_gap']:+.1f}%)" if (r.get("pb_gap") or 0) <= -2 else ""))
        if r.get("rel_spy") is not None:
            eqb.append(f"{r['rel_spy']:+.1f} pts vs SPY")
        if r.get("touch_n"):
            eqb.append({1: "1st", 2: "2nd", 3: "3rd"}.get(r["touch_n"], f"{r['touch_n']}th") + " touch this year")
        if r.get("slow_slope") is not None:
            eqb.append(f"slow line {r['slow_slope']:+.1f}%")
        if eqb:
            lines.append("Entry: " + " · ".join(eqb))
        for hl in r.get("level_history") or []:
            lines.append(e(hl))
        if r.get("support_check"):
            from .support import summary_line
            lines.append(e(summary_line(r["support_check"])))
        th = r.get("theme")
        if th:
            warn = (" ⚠️ " + ", ".join(th.get("flags") or []) + " — rotation risk") if th.get("risk", 0) >= 2 else \
                   (" (" + ", ".join(th["flags"]) + ")" if th.get("flags") else "")
            lines.append(e(f"🧭 Trades with {th['text']}{warn}"))
        if "sector" in r:
            from .sector_filter import tag
            lines.append("🏷 " + e(tag({"sector": r.get("sector"), "etf": r.get("sector_etf"), "quadrant": r.get("sector_quadrant"),
                                        "score": r.get("sector_value"), "value": r.get("sector_value_label")})))
        if r.get("options"):
            from .options import finder_line
            lines.append(finder_line(r["options"]))
        if r.get("gamma_plan"):
            from .gamma import plan_line
            gl = plan_line(r["gamma_plan"])
            if gl:
                lines.append(gl)
        p = r.get("plan")
        if p:
            only_res = r.get("resistance_test") and not (r.get("touched_fast") or r.get("touched_slow"))
            lines.append(("Only if it breaks out above the line — " if only_res else "")
                         + f"Plan: buy-stop ${p['entry']} · stop ${p['stop']} · {p['shares']} sh · "
                         f"2R ${p['target_2r']} · 3R ${p['target_3r']}")
        parts.append("\n".join(lines))

    if appr:
        seen = {}
        for r in appr:
            seen.setdefault(r["ticker"], r.get("dist_fast_pct"))
        near = sorted(seen.items(), key=lambda x: x[1] or 0)
        parts.append("<b>Approaching:</b> " + ", ".join(
            f"{e(t)} {d:+.1f}%" if d is not None else e(t) for t, d in near[:25])
            + (f" and {len(near) - 25} more" if len(near) > 25 else ""))
    if scan.get("errors"):
        parts.append("<i>Skipped: " + e("; ".join(scan["errors"][:8])) + "</i>")
    if not detailed and setups:
        parts.append("<i>Short alerts · /detail TICKER for everything on one stock · /alertstyle full for full alerts</i>")
    parts.append("<i>Shortlist only, not a buy signal. Not financial advice.</i>")
    return "\n\n".join(parts)


def send(token: str, chat_id: str, text: str) -> None:
    if not (token and chat_id):
        raise RuntimeError("Telegram bot token / chat ID not set (Settings → Telegram)")
    chunks, cur = [], ""
    for block in text.split("\n\n"):
        if cur and len(cur) + len(block) + 2 > MAX_LEN:
            chunks.append(cur)
            cur = ""
        cur = f"{cur}\n\n{block}" if cur else block
    if cur:
        chunks.append(cur)
    for c in chunks:
        r = requests.post(f"https://api.telegram.org/bot{token}/sendMessage",
                          json={"chat_id": chat_id, "text": c, "parse_mode": "HTML",
                                "disable_web_page_preview": True}, timeout=20)
        if r.status_code != 200:
            raise RuntimeError(f"Telegram error {r.status_code}: {r.text[:200]}")
