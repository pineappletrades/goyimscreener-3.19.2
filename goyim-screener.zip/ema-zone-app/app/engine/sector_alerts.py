"""Alerts on sectors and macro assets (checked after the daily scan, or on demand):
  score above / below N      the valuation score (-10 expensive ... +10 cheap) crosses a level
  quadrant <name>            the rotation quadrant becomes Leading / Improving / Weakening / Lagging
  turns                      any change of rotation quadrant
Each alert fires when its condition BECOMES true (not every day while it stays true)."""
import html
import uuid
from datetime import datetime

from . import store

E = html.escape
FILE = "sector_alerts.json"
QUADS = ("Leading", "Improving", "Weakening", "Lagging")
ALIASES = {"gold": "GLD", "silver": "SLV", "oil": "USO", "bonds": "TLT", "bond": "TLT", "dollar": "UUP",
           "market": "SPY", "breadth": "RSP", "tech": "XLK", "energy": "XLE", "financials": "XLF", "health": "XLV",
           "healthcare": "XLV", "staples": "XLP", "discretionary": "XLY", "industrials": "XLI", "materials": "XLB",
           "utilities": "XLU", "realestate": "XLRE", "real": "XLRE", "communication": "XLC", "comm": "XLC"}


def resolve(word):
    w = str(word).strip().lower().replace(" ", "")
    return ALIASES.get(w, str(word).strip().upper())


def load():
    return store.load(FILE, [])


def add(target, kind, value=None):
    t = resolve(target)
    if kind not in ("above", "below", "quadrant", "turns"):
        raise ValueError("Use above / below / quadrant / turns")
    if kind in ("above", "below"):
        value = float(value)
        if not -10 <= value <= 10:
            raise ValueError("Scores run from -10 to +10")
    if kind == "quadrant":
        value = str(value).capitalize()
        if value not in QUADS:
            raise ValueError("Quadrant must be Leading, Improving, Weakening or Lagging")
    lst = load()
    a = {"id": uuid.uuid4().hex[:8], "target": t, "kind": kind, "value": value,
         "created": datetime.now().isoformat(timespec="seconds"), "state": {}}
    lst.append(a)
    store.save(FILE, lst)
    return a


def remove(index):
    lst = load()
    if not 1 <= index <= len(lst):
        raise ValueError(f"Pick 1 to {len(lst)}" if lst else "No sector alerts")
    a = lst.pop(index - 1)
    store.save(FILE, lst)
    return a


def describe(a):
    if a["kind"] == "above":
        return f"{a['target']} valuation score rises to {a['value']:+g} or more"
    if a["kind"] == "below":
        return f"{a['target']} valuation score falls to {a['value']:+g} or less"
    if a["kind"] == "quadrant":
        return f"{a['target']} rotates into {a['value']}"
    return f"{a['target']} changes rotation quadrant"


def check(valuation, rotation_rows):
    """valuation: snapshot dict; rotation_rows: rows from rotation.analyse (any groups). Returns messages."""
    lst = load()
    if not lst:
        return []
    vrows = {r["ticker"]: r for r in (valuation or {}).get("rows", [])}
    qrows = {r["ticker"]: r for r in rotation_rows or []}
    out = []
    for a in lst:
        st = a.setdefault("state", {})
        t = a["target"]
        msg = None
        if a["kind"] in ("above", "below"):
            r = vrows.get(t)
            if not r or r.get("score") is None:
                continue
            now = r["score"] >= a["value"] if a["kind"] == "above" else r["score"] <= a["value"]
            if now and not st.get("active"):
                msg = f"📊 <b>{E(r['name'])} ({t})</b> valuation score is now <b>{r['score']:+.1f}</b> ({r['label']})"
            st["active"] = now
            st["last"] = r["score"]
        else:
            r = qrows.get(t)
            if not r or not r.get("quadrant"):
                continue
            q, prev = r["quadrant"], st.get("quadrant")
            if a["kind"] == "quadrant":
                if q == a["value"] and prev != q and prev is not None:
                    msg = f"🔄 <b>{E(r['name'])} ({t})</b> rotated into <b>{q}</b> (was {prev}) · 1M vs SPY {r['rel'].get('1M') or 0:+.1f}%"
            elif prev is not None and q != prev:
                msg = f"🔄 <b>{E(r['name'])} ({t})</b> moved {prev} → <b>{q}</b> · 1M vs SPY {r['rel'].get('1M') or 0:+.1f}%"
            st["quadrant"] = q
        if msg:
            st["last_fired"] = datetime.now().isoformat(timespec="seconds")
            out.append(msg)
    store.save(FILE, lst)
    return out
