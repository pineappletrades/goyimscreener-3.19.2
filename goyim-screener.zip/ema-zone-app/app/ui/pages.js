/* Goyim Screener v2 pages: Charts, Research, Compare, Screener, Calendar, Alerts and the bottom watchlist bar.
   Uses helpers from app.js ($, $$, esc, fmt, pct, money, call, toast, show, S) and icon() from icons.js. */
(function () {
  "use strict";

  const P = {
    chart: { ticker: "", data: null, view: null, ma: [], drag: null, hover: null },
    research: { ticker: "", data: null, range: 20, loading: false },
    compare: { tickers: ["", "", "", ""], data: null, range: 20, loading: false },
    screener: { db: null, filters: {}, sort: { key: "market_cap", dir: -1 }, open: null, enriched: {}, enrichKey: "",
                enriching: false, limit: 200, poll: null, perfKey: "perf_1m", activeScreen: null },
    calendar: { mode: "week", anchor: null, filter: "both", data: null, loading: false },
    alerts: { data: null, draft: null },
    bar: { rows: [], collapsed: false, sort: null, timer: null, needs: null },
  };
  const caps = () => (S.state && S.state.capabilities) || {};
  const capSrc = (k) => (caps().sources || {})[k] || "another data source";
  const cssCache = {};
  const cssVar = (name) => {
    const key = (document.documentElement.dataset.theme || "") + (document.documentElement.style.getPropertyValue("--bg") || "") + name;
    if (!(key in cssCache)) cssCache[key] = getComputedStyle(document.documentElement).getPropertyValue(name).trim();
    return cssCache[key];
  };
  const ic = (name, size = 16) => (typeof icon === "function" ? icon(name, size) : "");
  const big = (n) => {
    if (n == null || isNaN(n)) return "–";
    const a = Math.abs(n), s = n < 0 ? "-" : "";
    if (a >= 1e12) return s + "$" + (a / 1e12).toFixed(2) + "T";
    if (a >= 1e9) return s + "$" + (a / 1e9).toFixed(a >= 1e10 ? 1 : 2) + "B";
    if (a >= 1e6) return s + "$" + (a / 1e6).toFixed(0) + "M";
    if (a >= 1e3) return s + "$" + (a / 1e3).toFixed(0) + "K";
    return s + "$" + a.toFixed(2);
  };
  const cls = (n) => (n == null || isNaN(n) ? "" : n > 0 ? "pos" : n < 0 ? "neg" : "");
  const pctCell = (n) => `<span class="${cls(n)}">${pct(n)}</span>`;
  const isoDay = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
  const addDays = (d, n) => { const x = new Date(d); x.setDate(x.getDate() + n); return x; };
  const parseDay = (s) => new Date(s + "T12:00:00");
  const cleanT = (t) => String(t || "").trim().toUpperCase().replace(/[^A-Z0-9.\-]/g, "").slice(0, 10);
  const needBox = (what, src, extra = "") => `<div class="needs">${ic("plug", 18)}<div><b>${esc(what)} needs ${esc(src)}.</b>
      <span class="muted"> Add the key on Data sources and it switches on. ${extra}</span></div>
      <button class="btn ghost" data-go="sources">Data sources</button></div>`;

  function bindGo(root) {
    $$("[data-go]", root).forEach((b) => (b.onclick = () => show(b.dataset.go)));
  }
  function tickerForm(id, value, label, btn = "Load") {
    return `<form class="tk-form" id="${id}" autocomplete="off">
      <span class="search-ic">${ic("search", 18)}</span>
      <input name="t" value="${esc(value)}" placeholder="${esc(label)}" aria-label="${esc(label)}" maxlength="10">
      <button class="btn primary" type="submit">${esc(btn)}</button></form>`;
  }

  /* =====================================================================
     CHARTS: daily candles up to 10 years, 5 moving-average lines
     ===================================================================== */
  const MA_DEFAULTS = [
    { on: true, type: "EMA", len: 9, color: "#4FC3F7" },
    { on: true, type: "EMA", len: 21, color: "#2BD47D" },
    { on: false, type: "EMA", len: 50, color: "#FF7AB6" },
    { on: true, type: "EMA", len: 150, color: "#F2A93B" },
    { on: true, type: "EMA", len: 200, color: "#9A8CFF" },
  ];
  const RANGES = [["3M", 63], ["6M", 126], ["1Y", 252], ["2Y", 504], ["5Y", 1260], ["10Y", 99999]];

  function chartCfg() {
    const saved = ((S.state.settings || {}).chart || {}).lines;
    if (!P.chart.ma.length) P.chart.ma = (saved && saved.length === 5 ? saved : MA_DEFAULTS).map((x) => ({ ...x, vals: null }));
    return P.chart.ma;
  }
  let saveChartT = null;
  function saveChartCfg() {
    clearTimeout(saveChartT);
    saveChartT = setTimeout(() => {
      const lines = P.chart.ma.map(({ on, type, len, color }) => ({ on, type, len, color }));
      S.state.settings.chart = Object.assign({}, S.state.settings.chart, { lines, ticker: P.chart.ticker });
      call("save_chart_settings", S.state.settings.chart);
    }, 500);
  }

  function computeMA(closes, n, type) {
    const out = new Array(closes.length).fill(null);
    if (type === "SMA") {
      let sum = 0;
      for (let i = 0; i < closes.length; i++) {
        sum += closes[i];
        if (i >= n) sum -= closes[i - n];
        if (i >= n - 1) out[i] = sum / n;
      }
    } else {
      const k = 2 / (n + 1);
      let e = closes[0];
      for (let i = 0; i < closes.length; i++) { e = i ? closes[i] * k + e * (1 - k) : closes[0]; out[i] = i >= Math.min(n, closes.length) - 1 ? e : null; }
    }
    return out;
  }
  function recomputeMAs() {
    const d = P.chart.data;
    if (!d) return;
    P.chart.ma.forEach((m) => (m.vals = m.on ? computeMA(d.c, m.len, m.type) : null));
  }

  function renderCharts() {
    const root = $("#chartsBody");
    const c = caps();
    const ma = chartCfg();
    if (!P.chart.ticker) P.chart.ticker = ((S.state.settings || {}).chart || {}).ticker || (S.state.watchlist || [])[0] || "SPY";
    root.innerHTML = `
      <div class="pg-head">
        <h1>Charts</h1>
        ${tickerForm("chartForm", P.chart.ticker, "Ticker")}
        <div class="seg" id="chartRanges">${RANGES.map(([l, n]) => `<button data-n="${n}">${l}</button>`).join("")}</div>
        <button class="btn ghost" id="chartAlert">${ic("alerts")} Add alert</button>
      </div>
      ${c.bars_10y ? "" : needBox("Charts", capSrc("bars_10y"))}
      <div class="chart-card">
        <div class="chart-top"><div id="chartTitle"></div><div id="chartLegend" class="ma-legend"></div></div>
        <div class="canvas-wrap" id="cvWrap"><canvas id="cv"></canvas><canvas id="cvO" class="cv-over"></canvas><div id="cvTip" class="tip" hidden></div>
          <div id="cvMsg" class="cv-msg muted"></div></div>
        <div class="muted small cv-hint" id="cvHint">Scroll to zoom · drag to move · daily candles</div>
      </div>
      <div class="ma-panel">
        ${ma.map((m, i) => `
          <div class="ma-row ${m.on ? "" : "off"}" data-i="${i}">
            <label class="switch" title="Show line"><input type="checkbox" data-k="on" ${m.on ? "checked" : ""} aria-label="Show line ${i + 1}"><span></span></label>
            <input type="color" data-k="color" value="${esc(m.color)}" aria-label="Line ${i + 1} colour">
            <select data-k="type" aria-label="Line ${i + 1} type"><option ${m.type === "EMA" ? "selected" : ""}>EMA</option><option ${m.type === "SMA" ? "selected" : ""}>SMA</option></select>
            <input type="number" data-k="len" min="2" max="400" value="${m.len}" aria-label="Line ${i + 1} length">
            <input type="range" data-k="slide" min="2" max="400" value="${m.len}" aria-label="Line ${i + 1} length slider">
            <span class="ma-val num" id="maVal${i}">–</span>
          </div>`).join("")}
        <div class="ma-presets"><span class="muted small">Presets</span>
          <button class="tab" data-preset="9,21,50,150,200">9 · 21 · 50 · 150 · 200</button>
          <button class="tab" data-preset="10,20,50,100,200">10 · 20 · 50 · 100 · 200</button>
          <button class="tab" data-preset="8,21,34,55,89">8 · 21 · 34 · 55 · 89</button>
        </div>
      </div>`;
    bindGo(root);
    $("#chartForm").onsubmit = (e) => { e.preventDefault(); loadChart(cleanT(e.target.t.value)); };
    $$("#chartRanges button").forEach((b) => (b.onclick = () => setRange(+b.dataset.n)));
    $("#chartAlert").onclick = () => {
      const m = P.chart.ma.find((x) => x.on) || P.chart.ma[4];
      P.alerts.draft = { ticker: P.chart.ticker, kind: "ma_touch", ma_type: m.type, length: m.len };
      show("alerts");
    };
    $$(".ma-row").forEach((row) => {
      const i = +row.dataset.i, m = P.chart.ma[i];
      row.oninput = (e) => {
        const k = e.target.dataset.k;
        if (k === "on") { m.on = e.target.checked; row.classList.toggle("off", !m.on); }
        else if (k === "color") m.color = e.target.value;
        else if (k === "type") m.type = e.target.value;
        else if (k === "len" || k === "slide") {
          const v = Math.max(2, Math.min(400, parseInt(e.target.value, 10) || 2));
          m.len = v;
          if (k === "slide") $("[data-k=len]", row).value = v; else $("[data-k=slide]", row).value = v;
        }
        if (P.chart.data) m.vals = m.on ? computeMA(P.chart.data.c, m.len, m.type) : null;
        drawCanvas(); saveChartCfg();
      };
    });
    $$("[data-preset]").forEach((b) => (b.onclick = () => {
      b.dataset.preset.split(",").forEach((n, i) => { P.chart.ma[i].len = +n; P.chart.ma[i].type = "EMA"; P.chart.ma[i].on = true; });
      saveChartCfg(); renderCharts();
    }));
    bindCanvas();
    if (P.chart.data && P.chart.data.ticker === P.chart.ticker) { recomputeMAs(); drawCanvas(); }
    else if (c.bars_10y) loadChart(P.chart.ticker);
    else drawCanvas();
  }

  async function loadChart(t) {
    if (!t) return;
    P.chart.ticker = t;
    const f = $("#chartForm"); if (f) f.t.value = t;
    const msg = $("#cvMsg"); if (msg) msg.textContent = `Loading ${t}…`;
    const r = await call("get_chart", t);
    if (!r || !r.ok) {
      P.chart.data = null;
      if ($("#cvMsg")) $("#cvMsg").textContent = (r && r.error) || "Couldn't load the chart";
      drawCanvas();
      return;
    }
    P.chart.data = r;
    const hint = $("#cvHint");
    if (hint) hint.textContent = "Scroll to zoom · drag to move · daily candles" +
      (r.weekly_until ? ` (${r.older_bars || "longer"} bars before ${r.weekly_until}: Public gives daily bars for 5 years)` : "");
    const n = r.c.length;
    P.chart.view = { s: Math.max(0, n - 252), e: n };
    if (P.chart.focus) {                       // opened from a backtest row: centre ~6 months around that day
      const at = r.t.findIndex((x) => x >= P.chart.focus);
      if (at >= 0) { const s0 = Math.max(0, at - 70); P.chart.view = { s: s0, e: Math.min(n, s0 + 150) }; P.chart.hover = at; }
      P.chart.focus = null;
    }
    recomputeMAs();
    if ($("#cvMsg")) $("#cvMsg").textContent = "";
    saveChartCfg();
    drawCanvas();
  }

  function setRange(n) {
    const d = P.chart.data;
    if (!d) return;
    const len = d.c.length;
    P.chart.view = { s: Math.max(0, len - n), e: len };
    drawCanvas();
  }

  function chartGeom(cv) {
    const W = cv.clientWidth, H = cv.clientHeight;
    return { W, H, left: 8, right: 64, top: 10, priceH: Math.round(H * 0.76), volTop: Math.round(H * 0.8), bottom: 22 };
  }

  /* Redraws are batched to one per screen frame, so dragging/hovering/sliders stay smooth. */
  let drawPending = false;
  function drawCanvas() {
    if (drawPending) return;
    drawPending = true;
    requestAnimationFrame(() => { drawPending = false; drawNow(); });
  }
  function drawNow() {
    const cv = $("#cv");
    if (!cv) return;
    const dpr = window.devicePixelRatio || 1;
    const rect = cv.getBoundingClientRect();
    const w = Math.max(1, Math.round(rect.width * dpr)), hh = Math.max(1, Math.round(rect.height * dpr));
    const ov = $("#cvO");
    let resized = false;
    for (const c of [cv, ov]) if (c && (c.width !== w || c.height !== hh)) { c.width = w; c.height = hh; resized = true; }   // resizing is slow; only when needed
    const g = cv.getContext("2d");
    g.setTransform(dpr, 0, 0, dpr, 0, 0);
    const go = ov.getContext("2d");
    go.setTransform(dpr, 0, 0, dpr, 0, 0);
    go.clearRect(0, 0, rect.width, rect.height);
    const d = P.chart.data;
    const title = $("#chartTitle"), legend = $("#chartLegend");
    if (!d) { g.clearRect(0, 0, rect.width, rect.height); P.chart.baseKey = null; if (title) title.innerHTML = ""; if (legend) legend.innerHTML = ""; return; }
    const G = chartGeom(cv);
    const { s, e } = P.chart.view;
    const n = e - s, plotW = G.W - G.left - G.right, bw = plotW / n;
    const col = { text: cssVar("--text"), muted: cssVar("--muted"), line: cssVar("--line-soft"), up: cssVar("--pass"), dn: cssVar("--fail") };
    let hi = -Infinity, lo = Infinity, vmax = 0;
    for (let i = s; i < e; i++) {
      hi = Math.max(hi, d.h[i]); lo = Math.min(lo, d.l[i]); vmax = Math.max(vmax, d.v[i]);
      P.chart.ma.forEach((m) => { if (m.vals && m.vals[i] != null) { hi = Math.max(hi, m.vals[i]); lo = Math.min(lo, m.vals[i]); } });
    }
    const padP = (hi - lo) * 0.06 || 1; hi += padP; lo -= padP;
    const y = (v) => G.top + ((hi - v) / (hi - lo)) * (G.priceH - G.top);
    const x = (i) => G.left + (i - s + 0.5) * bw;
    const volH = G.H - G.bottom - G.volTop;
    P.chart.geom = { G, s, e, bw, x, y, hi, lo };

    const last = d.quote && d.quote.last ? d.quote.last : d.c[d.c.length - 1];
    // The candles, lines and axes only redraw when the view changes; hovering just redraws the crosshair layer.
    const baseKey = [d.ticker, d.c.length, s, e, w, hh, document.documentElement.dataset.theme,
      P.chart.ma.map((m) => (m.vals ? m.type + m.len + m.color : "-")).join()].join("|");
    if (baseKey !== P.chart.baseKey || resized) {
    P.chart.baseKey = baseKey;
    g.clearRect(0, 0, rect.width, rect.height);
    // grid + price axis
    g.font = "11px " + cssVar("--num");
    g.textBaseline = "middle";
    const step = niceStep((hi - lo) / 6);
    g.strokeStyle = col.line; g.fillStyle = col.muted; g.lineWidth = 1;
    for (let v = Math.ceil(lo / step) * step; v <= hi; v += step) {
      const yy = Math.round(y(v)) + 0.5;
      g.beginPath(); g.moveTo(G.left, yy); g.lineTo(G.W - G.right, yy); g.stroke();
      g.fillText(fmt(v, v >= 1000 ? 0 : 2), G.W - G.right + 8, yy);
    }
    // date axis
    g.textBaseline = "alphabetic";
    let lastLbl = -1e9;
    for (let i = s; i < e; i++) {
      const prev = i > 0 ? d.t[i - 1] : "";
      const newPeriod = n > 400 ? d.t[i].slice(0, 4) !== prev.slice(0, 4) : d.t[i].slice(0, 7) !== prev.slice(0, 7);
      if (!newPeriod || x(i) - lastLbl < 64) continue;
      const dt = parseDay(d.t[i]);
      const lbl = n > 400 ? String(dt.getFullYear()) : dt.toLocaleDateString(undefined, { month: "short" }) + (dt.getMonth() === 0 ? " " + dt.getFullYear() : "");
      g.fillText(lbl, x(i) - 10, G.H - 6);
      lastLbl = x(i);
    }
    // volume
    for (let i = s; i < e; i++) {
      const h = vmax ? (d.v[i] / vmax) * volH : 0;
      g.fillStyle = d.c[i] >= d.o[i] ? col.up : col.dn;
      g.globalAlpha = 0.28;
      g.fillRect(x(i) - Math.max(1, bw * 0.35), G.volTop + volH - h, Math.max(1, bw * 0.7), h);
    }
    g.globalAlpha = 1;
    // candles (or a line when zoomed far out)
    if (bw < 1.6) {
      g.strokeStyle = col.text; g.lineWidth = 1.2; g.beginPath();
      for (let i = s; i < e; i++) (i === s ? g.moveTo : g.lineTo).call(g, x(i), y(d.c[i]));
      g.stroke();
    } else {
      for (let i = s; i < e; i++) {
        const up = d.c[i] >= d.o[i];
        g.strokeStyle = g.fillStyle = up ? col.up : col.dn;
        const xx = Math.round(x(i)) + 0.5;
        g.beginPath(); g.moveTo(xx, y(d.h[i])); g.lineTo(xx, y(d.l[i])); g.stroke();
        const top = y(Math.max(d.o[i], d.c[i])), h = Math.max(1, Math.abs(y(d.o[i]) - y(d.c[i])));
        const w = Math.max(1, bw * 0.66);
        g.fillRect(x(i) - w / 2, top, w, h);
      }
    }
    // moving averages
    P.chart.ma.forEach((m) => {
      if (!m.vals) return;
      g.strokeStyle = m.color; g.lineWidth = 1.6; g.beginPath();
      let started = false;
      for (let i = s; i < e; i++) {
        const v = m.vals[i];
        if (v == null) continue;
        if (!started) { g.moveTo(x(i), y(v)); started = true; } else g.lineTo(x(i), y(v));
      }
      g.stroke();
    });
    // last price tag
    if (e === d.c.length && last >= lo && last <= hi) {
      const yy = y(last);
      g.setLineDash([3, 3]); g.strokeStyle = col.muted; g.beginPath(); g.moveTo(G.left, yy); g.lineTo(G.W - G.right, yy); g.stroke(); g.setLineDash([]);
      g.fillStyle = cssVar("--primary-bg"); roundRect(g, G.W - G.right + 2, yy - 10, G.right - 4, 20, 6); g.fill();
      g.fillStyle = cssVar("--primary-text"); g.textBaseline = "middle"; g.fillText(fmt(last, 2), G.W - G.right + 8, yy);
    }
    }
    // crosshair (overlay layer)
    const hv = P.chart.hover;
    if (hv != null && hv >= s && hv < e) {
      go.strokeStyle = col.muted; go.setLineDash([4, 4]); go.beginPath(); go.moveTo(Math.round(x(hv)) + 0.5, G.top); go.lineTo(Math.round(x(hv)) + 0.5, G.H - G.bottom); go.stroke(); go.setLineDash([]);
    }
    // header
    const idx = hv != null && hv >= s && hv < e ? hv : d.c.length - 1;
    const prevC = d.c[idx - 1];
    const chg = idx === d.c.length - 1 && d.quote && d.quote.prev_close ? (last / d.quote.prev_close - 1) * 100 : prevC ? (d.c[idx] / prevC - 1) * 100 : null;
    const shown = idx === d.c.length - 1 ? last : d.c[idx];
    const rangeChg = (d.c[e - 1] / d.c[s] - 1) * 100;
    const wk = d.weekly_until && d.t[idx] < d.weekly_until;
    if (title) title.innerHTML = `<span class="ct-t">${esc(d.ticker)}</span> <span class="ct-p num">$${fmt(shown)}</span> ${pctCell(chg)}
      <span class="muted small">${wk ? (d.older_bars === "monthly" ? "month of " : d.older_bars === "weekly" ? "week of " : "bar of ") : ""}${esc(d.t[idx])} · O ${fmt(d.o[idx])} H ${fmt(d.h[idx])} L ${fmt(d.l[idx])} C ${fmt(d.c[idx])} · range ${pct(rangeChg)}</span>`;
    if (legend) legend.innerHTML = P.chart.ma.filter((m) => m.vals).map((m) => `<span class="key"><i style="background:${esc(m.color)}"></i>${m.type} ${m.len} <b class="num">${fmt(m.vals[idx])}</b></span>`).join("");
    P.chart.ma.forEach((m, i) => {
      const el = $("#maVal" + i);
      if (!el) return;
      if (!m.vals || m.vals[d.c.length - 1] == null) { el.textContent = "–"; return; }
      const v = m.vals[d.c.length - 1], dist = (last / v - 1) * 100;
      el.innerHTML = `$${fmt(v)} <span class="${cls(dist)}">${pct(dist)}</span>`;
    });
    // range buttons
    $$("#chartRanges button").forEach((b) => b.classList.toggle("on", e === d.c.length && Math.min(+b.dataset.n, d.c.length) === n));
  }
  function roundRect(g, x, y, w, h, r) { g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r); g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath(); }
  function niceStep(raw) {
    const p = Math.pow(10, Math.floor(Math.log10(raw || 1))), f = raw / p;
    return (f < 1.5 ? 1 : f < 3 ? 2 : f < 7 ? 5 : 10) * p;
  }
  function idxAt(clientX) {
    const gm = P.chart.geom, cv = $("#cv");
    if (!gm || !cv) return null;
    const rx = clientX - cv.getBoundingClientRect().left;
    return Math.max(gm.s, Math.min(gm.e - 1, Math.floor((rx - gm.G.left) / gm.bw) + gm.s));
  }
  function bindCanvas() {
    const cv = $("#cv");
    if (!cv) return;
    cv.onwheel = (ev) => {
      if (!P.chart.data) return;
      ev.preventDefault();
      const len = P.chart.data.c.length, { s, e } = P.chart.view, n = e - s;
      const at = idxAt(ev.clientX), frac = (at - s) / n;
      const nn = Math.max(20, Math.min(len, Math.round(n * (ev.deltaY > 0 ? 1.15 : 0.87))));
      let ns = Math.round(at - frac * nn);
      ns = Math.max(0, Math.min(len - nn, ns));
      P.chart.view = { s: ns, e: ns + nn };
      drawCanvas();
    };
    cv.onmousedown = (ev) => { if (P.chart.data) P.chart.drag = { x: ev.clientX, s: P.chart.view.s, e: P.chart.view.e }; };
    window.addEventListener("mouseup", () => (P.chart.drag = null));
    cv.onmousemove = (ev) => {
      if (!P.chart.data) return;
      const dr = P.chart.drag;
      if (dr) {
        const gm = P.chart.geom, len = P.chart.data.c.length, n = dr.e - dr.s;
        let shift = Math.round((dr.x - ev.clientX) / gm.bw);
        let ns = Math.max(0, Math.min(len - n, dr.s + shift));
        P.chart.view = { s: ns, e: ns + n };
      }
      const hv = idxAt(ev.clientX);
      if (hv === P.chart.hover && !dr) return;
      P.chart.hover = hv;
      drawCanvas();
    };
    cv.onmouseleave = () => { P.chart.hover = null; drawCanvas(); };
  }





  /* =====================================================================
     ROTATION: heatmap of sectors / styles / industries / macro vs SPY
     ===================================================================== */
  P.rot = { group: "Sectors", mode: "rel", data: null, sort: null };
  const QCOL = { Leading: "var(--pass)", Weakening: "var(--near)", Lagging: "var(--fail)", Improving: "var(--focus)" };

  function renderRotation() {
    const root = $("#rotationBody"), R = P.rot, c = caps();
    const groups = ["Valuation"].concat((R.data && R.data.groups) || ["Sectors", "Size & style", "Industries", "Macro", "My list"]);
    root.innerHTML = `
      <div class="pg-head"><h1>Rotation</h1>
        <div class="seg" id="rotGroup">${groups.map((g) => `<button data-g="${esc(g)}" class="${g === R.group ? "on" : ""}">${esc(g)}</button>`).join("")}</div>
        ${R.group === "Valuation" ? "" : `<div class="seg" id="rotMode"><button data-m="rel" class="${R.mode === "rel" ? "on" : ""}">vs SPY</button><button data-m="abs" class="${R.mode === "abs" ? "on" : ""}">Absolute</button></div>`}
        <button class="btn ghost" id="rotRefresh">${ic("refresh")} Refresh</button><span class="muted small" id="rotAsOf"></span></div>
      ${c.bars ? "" : needBox("Rotation", capSrc("bars"))}
      ${R.group === "My list" ? `<form id="rotList" class="row-form" style="max-width:none"><input name="t" placeholder="Tickers for My list, e.g. NVDA, AMD, SMH, XLK (blank = your watchlist)" value="${esc(((S.state.settings || {}).rotation_custom || []).join(", "))}"><button class="btn primary">Save list</button></form>` : ""}
      <div id="rotInner"></div>`;
    $$("#rotGroup button").forEach((b) => (b.onclick = () => { R.group = b.dataset.g; if (R.group !== "Valuation") R.data = null; renderRotation(); }));
    $$("#rotMode button").forEach((b) => (b.onclick = () => { R.mode = b.dataset.m; renderRotation(); }));
    $("#rotRefresh").onclick = () => (R.group === "Valuation" ? loadValuation(true) : loadRotation());
    const lf = $("#rotList");
    if (lf) lf.onsubmit = async (e) => {
      e.preventDefault();
      const r = await call("save_rotation_list", e.target.t.value.split(/[\s,]+/).filter(Boolean));
      if (r.ok) { S.state.settings.rotation_custom = r.tickers; loadRotation(); }
    };
    bindGo(root);
    if (R.group === "Valuation") { if (P.val.data) drawValuation(); else if (c.bars) loadValuation(); return; }
    if (R.data && R.data.group === R.group) drawRotation();
    else if (c.bars) loadRotation();
  }

  async function loadRotation() {
    const R = P.rot, el = $("#rotInner");
    if (el) el.innerHTML = `<div class="loading">${ic("refresh", 18)} Loading ${esc(R.group)}…</div>`;
    const r = await call("get_rotation", R.group);
    R.data = r && r.ok ? r : { group: R.group, error: (r && r.error) || "Couldn't load" };
    if (S.page === "rotation") drawRotation();
  }

  function heat(v, scale) {
    if (v == null) return "";
    const k = Math.min(1, Math.abs(v) / (scale || 1));
    const amt = Math.round(12 + k * 58);
    return `background: color-mix(in srgb, ${v >= 0 ? "var(--pass)" : "var(--fail)"} ${amt}%, var(--panel));`;
  }

  function drawRotation() {
    const R = P.rot, d = R.data, el = $("#rotInner");
    if (!el) return;
    if (d.error) { el.innerHTML = `<div class="err">${esc(d.error)}</div>`; return; }
    $("#rotAsOf").textContent = "as of " + new Date(d.as_of).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
    const key = R.mode === "rel" ? "rel" : "abs";
    let rows = d.rows.slice();
    if (R.sort) {
      const [k, dir] = R.sort;
      const val = (r) => (k === "rank" ? -(r.rank ?? 999) : k === "from_high" || k === "vs_ema50" ? r[k] : r[key][k]);
      rows.sort((a, b) => ((val(b) ?? -1e9) - (val(a) ?? -1e9)) * dir);
    }
    const scale = {};
    d.periods.forEach((p) => {
      const vals = rows.filter((r) => !(R.mode === "rel" && r.benchmark)).map((r) => Math.abs(r[key][p] ?? 0)).sort((a, b) => a - b);
      scale[p] = vals[Math.floor(vals.length * 0.85)] || 1;     // 85th percentile so one outlier doesn't wash out the rest
    });
    const sm = d.summary;
    const chips = (list) => (list.length ? list.map((t) => `<button class="rot-chip" data-t="${esc(t)}">${esc(t)}</button>`).join("") : `<span class="muted small">none</span>`);
    let html = `<div class="rot-sum">
      ${["Leading", "Improving", "Weakening", "Lagging"].map((q) => `<div class="rot-q"><div class="rot-qh"><i style="background:${QCOL[q]}"></i>${q}</div><div class="muted small">${{ Leading: "beating SPY and still accelerating", Improving: "still behind SPY but gaining", Weakening: "ahead of SPY but losing steam", Lagging: "behind SPY and fading" }[q]}</div><div>${chips(sm[q] || [])}</div></div>`).join("")}
      <div class="rot-q"><div class="rot-qh">Money moving in <span class="muted small">1W vs SPY</span></div><div>${chips(sm.inflow)}</div>
        <div class="rot-qh" style="margin-top:6px">Moving out</div><div>${chips(sm.outflow)}</div></div>
      <div class="rot-q"><div class="rot-qh">Turning up <span class="muted small">Lagging → Improving/Leading in 4 weeks</span></div><div>${chips(sm.turning_up)}</div>
        <div class="rot-qh" style="margin-top:6px">Rolling over <span class="muted small">Leading → Weakening/Lagging</span></div><div>${chips(sm.rolling_over)}</div></div>
    </div>`;
    const th = (k, l, cls2 = "r") => `<th class="${cls2} sortable" data-k="${k}">${l}${R.sort && R.sort[0] === k ? (R.sort[1] > 0 ? " ↓" : " ↑") : ""}</th>`;
    html += `<div class="rot-grid"><div class="card rot-heat"><h3>${R.mode === "rel" ? "Performance vs SPY" : "Performance"} <span class="muted small">% change · click a column to sort · click a row for the chart</span></h3>
      <div class="table-wrap"><table class="heat"><thead><tr><th>ETF</th>${d.periods.map((p) => th(p, p)).join("")}${th("vs_ema50", "vs 50 EMA")}${th("from_high", "From high")}${th("rank", "Rank 1M")}<th>Rotation</th></tr></thead>
      <tbody>${rows.map((r) => `<tr data-t="${esc(r.ticker)}" class="${r.benchmark ? "bench" : ""}"><td><b>${esc(r.ticker)}</b><div class="muted small nm">${esc(r.name)}</div></td>
        ${d.periods.map((p) => { const v = r[key][p]; return `<td class="r num hc" style="${R.mode === "rel" && r.benchmark ? "" : heat(v, scale[p])}" title="${esc(r.ticker)} ${p}: ${v == null ? "n/a" : (v > 0 ? "+" : "") + fmt(v, 2) + "%"}">${v == null ? "–" : (v > 0 ? "+" : "") + fmt(v, 1) + "%"}</td>`; }).join("")}
        <td class="r num">${r.vs_ema50 == null ? "–" : `<span class="${cls(r.vs_ema50)}">${pct(r.vs_ema50, 1)}</span>`}${r.vs_ema200 != null ? `<div class="muted small">200: ${pct(r.vs_ema200, 1)}</div>` : ""}</td>
        <td class="r num">${r.from_high == null ? "–" : fmt(r.from_high, 1) + "%"}</td>
        <td class="r num">${r.rank ?? "–"}${r.rank_change ? ` <span class="${r.rank_change > 0 ? "pos" : "neg"} small">${r.rank_change > 0 ? "▲" : "▼"}${Math.abs(r.rank_change)}</span>` : ""}</td>
        <td>${r.quadrant ? `<span class="q-pill" style="--q:${QCOL[r.quadrant]}">${r.quadrant}</span>` : r.benchmark ? '<span class="muted small">benchmark</span>' : "–"}</td></tr>`).join("")}</tbody></table></div></div>
      <div class="rot-pair"><div class="card"><h3>Relative rotation <span class="muted small">vs SPY · last 8 weeks, dot = today</span></h3>${rrgChart(d.rows)}</div>
        <div class="card rot-read"><h3>How to read this</h3>
          <p><b>Heatmap:</b> each cell is the % change over that period${R.mode === "rel" ? " minus SPY's, so green = beat the market" : ""}. Deeper colour = bigger move for that column.</p>
          <p><b>Rotation chart:</b> right of centre = beating SPY over the last ~2 months; above centre = that edge is growing. Each tail is the last 8 weeks.
             Names usually turn clockwise: <span style="color:var(--focus)">Improving</span> → <span style="color:var(--pass)">Leading</span> → <span style="color:var(--near)">Weakening</span> → <span style="color:var(--fail)">Lagging</span>.</p>
          <p><b>Using it with your 150/200 EMA setups:</b> pullbacks in stocks whose sector is Leading or Improving tend to hold better; be pickier when the sector is Lagging or rolling over.
             Rank ▲ = climbed the 1-month table vs a month ago.</p></div></div></div>`;
    if (d.errors.length) html += `<p class="muted small">Not loaded: ${esc(d.errors.join("; "))}</p>`;
    el.innerHTML = html;
    $$("th.sortable", el).forEach((h) => (h.onclick = () => { const k = h.dataset.k; R.sort = R.sort && R.sort[0] === k ? [k, -R.sort[1]] : [k, 1]; drawRotation(); }));
    const go = (t) => { P.chart.ticker = t; P.chart.data = null; show("charts"); };
    $$(".heat tbody tr", el).forEach((tr) => (tr.onclick = () => go(tr.dataset.t)));
    $$(".rot-chip", el).forEach((b) => (b.onclick = () => go(b.dataset.t)));
  }

  function rrgChart(rows) {
    const pts = rows.filter((r) => r.tail && r.tail.length);
    if (!pts.length) return `<p class="muted">Not enough history yet.</p>`;
    const W = 520, H = 440, pad = 34;
    const all = pts.flatMap((r) => r.tail);
    const xr = Math.max(2, ...all.map((p) => Math.abs(p.ratio - 100))) * 1.15, yr = Math.max(1, ...all.map((p) => Math.abs(p.mom - 100))) * 1.15;
    const x = (v) => pad + ((v - (100 - xr)) / (2 * xr)) * (W - 2 * pad), y = (v) => pad + (((100 + yr) - v) / (2 * yr)) * (H - 2 * pad);
    const cx = x(100), cy = y(100);
    let out = `<rect x="${cx}" y="${pad}" width="${W - pad - cx}" height="${cy - pad}" fill="var(--pass)" opacity=".07"/>
      <rect x="${cx}" y="${cy}" width="${W - pad - cx}" height="${H - pad - cy}" fill="var(--near)" opacity=".07"/>
      <rect x="${pad}" y="${cy}" width="${cx - pad}" height="${H - pad - cy}" fill="var(--fail)" opacity=".07"/>
      <rect x="${pad}" y="${pad}" width="${cx - pad}" height="${cy - pad}" fill="var(--focus)" opacity=".07"/>
      <line x1="${pad}" x2="${W - pad}" y1="${cy}" y2="${cy}" stroke="var(--line)"/><line x1="${cx}" x2="${cx}" y1="${pad}" y2="${H - pad}" stroke="var(--line)"/>
      <text x="${W - pad - 4}" y="${pad + 14}" text-anchor="end" class="ax">Leading</text><text x="${W - pad - 4}" y="${H - pad - 6}" text-anchor="end" class="ax">Weakening</text>
      <text x="${pad + 4}" y="${H - pad - 6}" class="ax">Lagging</text><text x="${pad + 4}" y="${pad + 14}" class="ax">Improving</text>
      <text x="${W / 2}" y="${H - 8}" text-anchor="middle" class="ax">Relative strength →</text>
      <text x="12" y="${H / 2}" class="ax" transform="rotate(-90 12 ${H / 2})" text-anchor="middle">Momentum →</text>`;
    pts.forEach((r) => {
      const col = QCOL[r.quadrant] || "var(--muted)";
      out += `<path d="${r.tail.map((p, i) => (i ? "L" : "M") + x(p.ratio).toFixed(1) + " " + y(p.mom).toFixed(1)).join("")}" fill="none" stroke="${col}" stroke-width="1.5" opacity=".55"/>`;
      r.tail.slice(0, -1).forEach((p) => (out += `<circle cx="${x(p.ratio)}" cy="${y(p.mom)}" r="2" fill="${col}" opacity=".5"/>`));
      const last = r.tail[r.tail.length - 1];
      out += `<circle cx="${x(last.ratio)}" cy="${y(last.mom)}" r="5.5" fill="${col}" stroke="var(--panel)" stroke-width="2"><title>${r.ticker} (${r.name}): ${r.quadrant} · RS ${fmt(last.ratio, 1)} · momentum ${fmt(last.mom, 1)}</title></circle>
        <text x="${x(last.ratio) + 8}" y="${y(last.mom) + 4}" class="ax" fill="var(--text)" style="font-weight:600">${esc(r.ticker)}</text>`;
    });
    return `<svg viewBox="0 0 ${W} ${H}" class="qchart" role="img" aria-label="Relative rotation chart">${out}</svg>`;
  }


  /* ---------- Valuation (inside Rotation): -10 expensive … +10 cheap vs own history ---------- */
  P.val = { data: null, open: {}, poll: null };
  const VCOL = (s) => (s == null ? "var(--muted)" : s >= 0 ? "var(--pass)" : "var(--fail)");
  const PART_NAMES = { pe: "P/E", ps: "Price / sales", fcfy: "FCF yield", rel: "Price vs SPY", stretch: "Stretch from 200-day avg",
    range: "Price in its 10-year range", above200: "% of stocks above 200-day avg", equal_vs_cap: "Equal-weight vs S&P 500" };

  async function loadValuation(refresh) {
    const el = $("#rotInner");
    if (el) el.innerHTML = `<div class="loading">${ic("refresh", 18)} Scoring sectors, gold, oil, bonds and breadth…</div>`;
    const r = await call("get_valuation", !!refresh);
    P.val.data = r && r.ok ? r : { error: (r && r.error) || "Couldn't load" };
    if (S.page === "rotation" && P.rot.group === "Valuation") drawValuation();
  }

  function valPartText(k, v) {
    if (!v) return "";
    const num = (x, d = 1) => (x == null ? "–" : fmt(x, d));
    const unit = { pe: "×", ps: "×", fcfy: "%", stretch: "%", above200: "%" }[k] || "";
    const now = k === "rel" ? (v.chg_1y != null ? `${pct(v.chg_1y, 0)} vs SPY in 1y` : "") : k === "range" ? `$${num(v.now, 2)} (range $${num(v.lo, 0)}–$${num(v.hi, 0)}, ${num(v.years, 0)}y)` : `${num(v.now, k === "ps" ? 2 : 1)}${unit}`;
    const med = v.median != null ? ` · usual ${num(v.median, k === "ps" ? 2 : 1)}${unit}` : "";
    const ord = (n) => { n = Math.round(n); const t = n % 100, e = n % 10; return n + (t >= 11 && t <= 13 ? "th" : e === 1 ? "st" : e === 2 ? "nd" : e === 3 ? "rd" : "th"); };
    const p = v.pct == null ? "" : ` · ${ord(v.pct)} percentile of its history`;
    return `${now}${med}${p}${v.note ? ` <span class="muted">(${esc(v.note)})</span>` : ""}`;
  }

  function drawValuation() {
    const el = $("#rotInner"), d = P.val.data;
    if (!el) return;
    if (d.error) { el.innerHTML = `<div class="err">${esc(d.error)}</div>`; return; }
    const st = d.status || {};
    const asof = $("#rotAsOf"); if (asof) asof.textContent = "as of " + new Date(d.as_of).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
    const groups = [["market", "Whole market"], ["sector", "Sectors"], ["asset", "Gold, silver, oil, bonds, dollar"], ["breadth", "Breadth"]];
    const bar = (s) => {
      if (s == null) return `<div class="vbar"><span class="muted small">not enough history</span></div>`;
      const w = Math.min(50, Math.abs(s) * 5);
      return `<div class="vbar"><i class="mid"></i><i class="fill" style="${s >= 0 ? `left:50%;width:${w}%` : `left:${50 - w}%;width:${w}%`};background:${VCOL(s)}"></i></div>`;
    };
    let html = `<div class="val-head card">
        <div><b>Scores compare each one with its own past.</b> <span class="muted">+10 = cheapest it has been (extremely undervalued), 0 = normal, −10 = most expensive (extremely overvalued).
          Sectors use P/E, price/sales and FCF yield of their biggest companies over ~10 years of filings, plus price vs SPY and stretch from the 200-day average. Gold, oil, bonds and the dollar have no earnings, so they're scored on price.</span></div>
        <div class="val-build">${st.running ? `<span class="spin">${ic("refresh", 14)}</span> ${esc(st.stage || "")} ${st.total ? `${st.done}/${st.total}` : ""}`
          : `<span class="muted small">${d.has_history ? `Sector history built ${esc(String(d.history_built).slice(0, 10))} · rebuilt weekly after the close` : "Sector P/E history not built yet (sectors use price checks only)"}</span>
             <button class="btn ${d.has_history ? "ghost" : "primary"}" id="valBuild">${d.has_history ? "Rebuild history" : "Build sector history (~5–10 min)"}</button>`}</div></div>`;
    html += `<div class="val-legend muted small"><span>−10 extremely overvalued</span><span>−3 … +3 fair</span><span>+10 extremely undervalued</span></div>`;
    for (const [kind, title] of groups) {
      const rows = d.rows.filter((r) => r.kind === kind).sort((a, b) => (b.score ?? -99) - (a.score ?? -99));
      if (!rows.length) continue;
      html += `<div class="card val-group"><h3>${title}</h3>${rows.map((r) => {
        const key = r.kind + r.ticker, open = P.val.open[key];
        const parts = Object.entries(r.parts || {}).filter(([, v]) => v);
        return `<div class="vrow ${open ? "open" : ""}" data-k="${esc(key)}">
          <div class="vrow-main"><div class="vname"><b>${esc(r.name)}</b> <span class="muted small">${esc(r.ticker)}${r.members ? ` · ${r.members} companies` : ""}</span></div>
            ${bar(r.score)}<div class="vscore num" style="color:${VCOL(r.score)}">${r.score == null ? "–" : (r.score > 0 ? "+" : "") + fmt(r.score, 1)}</div>
            <div class="vlabel small">${esc(r.label)}</div></div>
          ${open ? `<div class="vdetail">${parts.map(([k, v]) => `<div class="vpart"><span class="vpn">${esc(PART_NAMES[k] || k)}</span>
              <span class="vpc" style="color:${VCOL(v.cheap)}">${v.cheap == null ? "–" : (v.cheap > 0 ? "+" : "") + fmt(v.cheap * 10, 1)}</span><span class="muted small">${valPartText(k, v)}</span></div>`).join("") || `<span class="muted">No details.</span>`}
            ${r.pe_history && r.pe_history.filter((x) => x.pe).length > 6 ? `<div class="vspark"><span class="muted small">P/E by quarter</span>${peSpark(r.pe_history, r.parts.pe && r.parts.pe.now)}</div>` : ""}
            ${r.kind === "sector" || r.kind === "market" ? `<button class="btn ghost small-btn" data-chart="${esc(r.ticker)}">${ic("charts", 14)} Chart ${esc(r.ticker)}</button>` : `<button class="btn ghost small-btn" data-chart="${esc(r.ticker)}">${ic("charts", 14)} Chart ${esc(r.ticker)}</button>`}</div>` : ""}</div>`;
      }).join("")}</div>`;
    }
    html += `<p class="muted small">Percentiles tell you how unusual today is for that asset, not where it goes next: cheap things can get cheaper. Oil uses the USO fund, which drifts lower over time from futures roll costs, so its long-range reading leans cheap.
      Breadth is contrarian: very few stocks above their 200-day average = washed out (positive); almost all = stretched (negative).</p>`;
    el.innerHTML = html;
    $$(".vrow-main", el).forEach((m) => (m.onclick = () => { const k = m.parentElement.dataset.k; P.val.open[k] = !P.val.open[k]; drawValuation(); }));
    $$("[data-chart]", el).forEach((b) => (b.onclick = (e) => { e.stopPropagation(); P.chart.ticker = b.dataset.chart; P.chart.data = null; show("charts"); }));
    const vb = $("#valBuild");
    if (vb) vb.onclick = async () => {
      const r = await call("build_valuation");
      if (!r.ok) return toast(r.error, true);
      clearInterval(P.val.poll);
      P.val.poll = setInterval(async () => {
        const s2 = await call("valuation_status");
        if (P.val.data) P.val.data.status = s2;
        if (S.page === "rotation" && P.rot.group === "Valuation") drawValuation();
        if (!s2.running) { clearInterval(P.val.poll); if (s2.error) toast(s2.error, true); else { toast("Sector history built"); loadValuation(true); } }
      }, 2000);
    };
    if (st.running && !P.val.poll) $("#valBuild");
  }

  function peSpark(h, now) {
    const pts = h.filter((x) => x.pe != null && x.pe > 0 && x.pe < 200);
    if (pts.length < 4) return "";
    const W = 260, H = 54, vals = pts.map((x) => x.pe).concat(now ? [now] : []);
    const mx = Math.max(...vals), mn = Math.min(...vals);
    const x = (i) => 2 + (i / (pts.length - (now ? 0 : 1))) * (W - 4), y = (v) => 4 + ((mx - v) / ((mx - mn) || 1)) * (H - 8);
    const med = [...pts.map((p) => p.pe)].sort((a, b) => a - b)[Math.floor(pts.length / 2)];
    return `<svg viewBox="0 0 ${W} ${H}" class="vspark-svg" role="img" aria-label="P/E history"><line x1="0" x2="${W}" y1="${y(med)}" y2="${y(med)}" stroke="var(--muted)" stroke-dasharray="3 3"/>
      <path d="${pts.map((p, i) => (i ? "L" : "M") + x(i).toFixed(1) + " " + y(p.pe).toFixed(1)).join("")}" fill="none" stroke="var(--slow)" stroke-width="1.6"/>
      ${now ? `<circle cx="${x(pts.length)}" cy="${y(now)}" r="3.5" fill="var(--text)"><title>Now: ${fmt(now, 1)}×</title></circle>` : ""}
      <text x="${W - 2}" y="${H - 2}" text-anchor="end" class="ax">${pts[0].key}–now · dashed = median ${fmt(med, 1)}×</text></svg>`;
  }

  function macroStrip(m) {
    if (!m || m.score == null) return "";
    const col = m.regime === "Risk-on" ? "var(--pass)" : m.regime === "Risk-off" ? "var(--fail)" : "var(--near)";
    const th = (e) => `<span class="vchip" title="${esc((m.themes[e] || {}).text || "")}"><b>${esc(e)}</b> ${esc((m.themes[e] || {}).name || "")}</span>`;
    return `<div class="card val-strip macro-strip"><div><span class="muted small">Macro environment (VIX, SPY trend & drawdown, breadth, credit · −10 risk-off … +10 risk-on)</span>
      <div class="vchips"><span class="vchip" style="border-color:${col}"><b style="color:${col}">${esc(m.regime)} ${m.score > 0 ? "+" : ""}${fmt(m.score, 1)}</b> ${esc(m.text)}</span>
        ${m.vix != null ? `<span class="vchip"><b>VIX ${fmt(m.vix, 1)}</b> ${esc(m.fear)}${m.vix_pct_1y != null ? ` · ${fmt(m.vix_pct_1y, 0)}th pct of the year` : ""}</span>` : ""}
        ${m.spy_dd != null ? `<span class="vchip"><b>SPY</b> ${m.spy_dd > 0 ? "+" : ""}${fmt(m.spy_dd, 1)}% from high</span>` : ""}</div>
      ${(m.out_of || []).length || (m.into || []).length ? `<div class="vchips">${(m.out_of || []).length ? `<span class="muted small">Money leaving</span> ${m.out_of.map(th).join("")}` : ""}
        ${(m.into || []).length ? `<span class="muted small">Moving into</span> ${m.into.map(th).join("")}` : ""}</div>` : ""}</div></div>`;
  }

  async function drawOptFinder(t) {
    const el = $("#gxOptBody");
    if (!el) return;
    el.innerHTML = `<div class="loading">${ic("refresh", 16)} Reading ${esc(t)}'s option chain…</div>`;
    const r = await call("options_finder", t);
    if (!$("#gxOptBody")) return;
    if (!r.ok) { el.innerHTML = `<p class="neg small">${esc(r.error)}</p>`; return; }
    const pc = (v) => (v == null ? "–" : `<span class="${cls(v)}">${v > 0 ? "+" : ""}${fmt(v, 0)}%</span>`);
    const b = r.best, sc = r.scenario;
    el.innerHTML = `<div class="opt-verdict ${r.verdict === "Calls" ? "pos" : ""}"><b>${esc(r.verdict)}</b> <span class="muted small">${esc(r.why)}</span></div>
      ${b ? `<div class="gx-plan-row"><span>Best call</span><b class="num">${esc(b.expiration)} $${fmt(b.strike, b.strike % 1 ? 1 : 0)}C</b><small class="muted">Δ${fmt(b.delta, 2)} · $${fmt(b.ask)} ask = $${fmt(b.cost, 0)}/contract · breakeven $${fmt(b.breakeven)} (${pct(b.breakeven_pct, 1)})</small></div>
        <div class="gx-plan-row"><span>If right / wrong</span><b class="num">${pc(b.if_right)} / ${pc(b.if_wrong)}</b><small class="muted">expected ${pc(b.ev)} vs shares ${pc(r.shares.ev)} (${pc(r.shares.if_right)} / ${pc(r.shares.if_wrong)})</small></div>` : ""}
      ${r.steady && b && r.steady.strike !== b.strike ? `<div class="gx-plan-row"><span>Steadier</span><b class="num">${esc(r.steady.expiration)} $${fmt(r.steady.strike, 0)}C</b><small class="muted">Δ${fmt(r.steady.delta, 2)} · expected ${pc(r.steady.ev)} · if wrong ${pc(r.steady.if_wrong)}</small></div>` : ""}
      <details class="small" style="margin-top:6px"><summary class="muted">Top ${r.candidates.length} of ${r.checked} calls checked</summary>
        <table class="res gx-tbl"><thead><tr><th>Call</th><th class="r">Δ</th><th class="r">Cost</th><th class="r">Expected</th><th class="r">Right</th><th class="r">Wrong</th><th class="r">Spread</th><th class="r">OI</th></tr></thead><tbody>
        ${r.candidates.map((c) => `<tr><td>${esc(c.expiration)} $${fmt(c.strike, c.strike % 1 ? 1 : 0)}</td><td class="r num">${fmt(c.delta, 2)}</td><td class="r num">$${fmt(c.cost, 0)}</td><td class="r num">${pc(c.ev)}</td><td class="r num">${pc(c.if_right)}</td><td class="r num">${pc(c.if_wrong)}</td><td class="r num">${fmt(c.spread_pct, 0)}%</td><td class="r num">${fmt(c.oi, 0)}</td></tr>`).join("")}</tbody></table></details>
      <p class="muted small" style="margin:6px 0 0">Scenario from ${esc(sc.source)}: wins ${fmt(sc.p_win * 100, 0)}% · avg win ${pct(sc.up_pct, 1)} · avg loss ${pct(sc.down_pct, 1)} · ~${sc.days} trading days. Buys at the ask, sells at the bid side.</p>`;
  }

  function valStrip(v) {
    if (!v || !v.rows) return "";
    const rows = v.rows.filter((r) => r.score != null);
    const sec = rows.filter((r) => r.kind === "sector").sort((a, b) => b.score - a.score);
    const chip = (r, name) => `<span class="vchip" title="${esc(r.name)}: ${esc(r.label)}"><b>${esc(name || r.name)}</b> <span style="color:${VCOL(r.score)}">${r.score > 0 ? "+" : ""}${fmt(r.score, 0)}</span></span>`;
    const pick = (t) => rows.find((r) => r.ticker === t);
    const others = [["SPY", "Market"], ["GLD", "Gold"], ["USO", "Oil"], ["TLT", "Bonds"], ["UUP", "Dollar"], ["RSP", "Breadth"]].map(([t, n]) => (pick(t) ? chip(pick(t), n) : "")).join("");
    return `<div class="card val-strip"><div><span class="muted small">Valuation vs own history (+10 cheap · −10 expensive)</span>
      <div class="vchips"><span class="muted small">Cheapest</span> ${sec.slice(0, 3).map((r) => chip(r)).join("")} <span class="muted small">Richest</span> ${sec.slice(-3).reverse().map((r) => chip(r)).join("")}</div>
      <div class="vchips">${others}</div></div><button class="btn ghost small-btn" id="valStripMore">All scores</button></div>`;
  }

  /* =====================================================================
     GAMMA: dealer gamma from Public's option chains (read-only)
     ===================================================================== */
  P.gx = { ticker: "", data: null, mode: "near", dates: null, loading: false };
  const gmoney = (v) => {
    if (v == null) return "–";
    const a = Math.abs(v), s = v < 0 ? "-" : "+";
    return s + "$" + (a >= 1e9 ? (a / 1e9).toFixed(2) + "B" : a >= 1e6 ? (a / 1e6).toFixed(1) + "M" : (a / 1e3).toFixed(0) + "K");
  };

  function renderGamma() {
    const root = $("#gammaBody"), G = P.gx, c = caps();
    if (!G.ticker) G.ticker = P.chart.ticker || "SPY";
    root.innerHTML = `
      <div class="pg-head"><h1>Gamma</h1>${tickerForm("gxForm", G.ticker, "Ticker", "Load")}
        <div class="seg" id="gxMode">${[["near", "Next 45 days"], ["quarter", "Next 3 months"], ["all", "All dates"]].map(([k, l]) => `<button data-m="${k}" class="${!G.dates && G.mode === k ? "on" : ""}">${l}</button>`).join("")}</div>
        <button class="btn ghost" id="gxRefresh">${ic("refresh")} Refresh</button>
        <button class="btn ghost" id="gxScanWl">${ic("watchlist")} Scan watchlist</button>
        <span class="muted small" id="gxAsOf"></span></div>
      <div id="gxScan"></div>
      ${c.option_chain ? "" : needBox("Gamma", "Public.com")}
      <details class="card gx-help"><summary><b>How to use this page</b> <span class="muted small">walls, the gamma flip, pins vs fast moves, and confirming EMA bounces</span></summary>
        <div class="gx-help-body">
          <p><b>Call wall</b>: the strike with the most call gamma, often a ceiling or magnet into expiration, so a natural price target to take profits near.
             <b>Put wall</b>: the strike with the most put gamma, often support; a clean break below it tends to speed up.</p>
          <p><b>Gamma flip</b>: above it dealers are long gamma and lean against moves (dips get bought, rips get sold), so levels like your 150/200 EMA tend to hold.
             Below it dealers are short gamma and chase the move, so support can break fast.</p>
          <p><b>Pin / reject</b> levels have heavy positive gamma; <b>fast</b> zones have negative gamma or almost none (air pockets) and price can travel through them quickly.
             Use "Check a price" to ask about any level.</p>
          <p><b>Expirations</b>: when a date holding a big share of the gamma expires (often monthly OPEX, the 3rd Friday), its walls disappear and price is freer to move.
             <b>Max pain</b> is where option holders get paid the least; price often drifts toward it into that expiry.</p>
          <p><b>EMA confirmation</b>: a bounce off the 150/200 EMA is better backed when a put wall or a big positive-gamma strike sits within ~1.5% of the line and price is above the flip.</p>
          <p class="muted small">Built from Public's option chain: open interest (updated once a day), gamma and IV per contract. The model assumes customers are net long options and dealers short them, which is usually but not always true.
             Flow is an estimate: each contract's whole day's volume is counted as bought or sold by where its last trade printed vs the mid. It's not tick-by-tick sweep data.</p>
        </div></details>
      <div id="gxInner"></div>`;
    bindGo(root);
    $("#gxForm").onsubmit = (e) => { e.preventDefault(); G.dates = null; loadGamma(cleanT(e.target.t.value)); };
    $$("#gxMode button").forEach((b) => (b.onclick = () => { G.mode = b.dataset.m; G.dates = null; renderGamma(); loadGamma(G.ticker, true); }));
    $("#gxRefresh").onclick = () => loadGamma(G.ticker, true);
    $("#gxScanWl").onclick = async () => {
      const r = await call("start_gamma_scan");
      if (!r.ok) return toast(r.error, true);
      pollGammaScan();
    };
    call("gamma_scan_status").then((st) => { if (st.running) pollGammaScan(); else drawGammaScan(st.result); });
    if (G.data && G.data.ticker === G.ticker) drawGamma();
    else if (c.option_chain) loadGamma(G.ticker);
  }

  async function loadGamma(t, force) {
    if (!t) return;
    const G = P.gx;
    G.ticker = t;
    const f = $("#gxForm"); if (f) f.t.value = t;
    const el = $("#gxInner");
    if (el) el.innerHTML = `<div class="loading">${ic("refresh", 18)} Loading ${esc(t)}'s option chains from Public…</div>`;
    const extra = [];
    if (P.ef.data && P.ef.data.ticker === t && P.ef.data.best) extra.push(P.ef.data.best);
    (P.chart.ma || []).forEach((m) => m.on && m.type === "EMA" && extra.push(m.len));
    const r = await call("get_gamma", t, G.mode, G.dates, extra);
    G.data = r && r.ok ? r : { ticker: t, error: (r && r.error) || "Couldn't load options" };
    if (S.page === "gamma" && G.ticker === t) drawGamma();
  }


  function pollGammaScan() {
    clearInterval(P.gx.scanPoll);
    const el = $("#gxScan");
    P.gx.scanPoll = setInterval(async () => {
      const st = await call("gamma_scan_status");
      if (st.running) { if (el) el.innerHTML = `<div class="note"><span class="spin">${ic("refresh", 14)}</span> Gamma scan: ${esc(st.current || "")} ${st.total ? `${st.done}/${st.total}` : ""}</div>`; return; }
      clearInterval(P.gx.scanPoll);
      drawGammaScan(st.result);
    }, 1500);
  }

  function drawGammaScan(res) {
    const el = $("#gxScan");
    if (!el || !res || !res.rows || !res.rows.length) { if (el) el.innerHTML = ""; return; }
    const lean = { bullish: '<span class="pos">📈 bullish</span>', bearish: '<span class="neg">📉 bearish</span>', mixed: '<span class="muted">mixed</span>' };
    el.innerHTML = `<details class="card" ${P.gx.scanOpen ? "open" : ""} id="gxScanBox"><summary><b>Watchlist gamma scan</b> <span class="muted small">${res.rows.length} tickers · ${new Date(res.as_of).toLocaleString([], { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })} · runs after each close and on /gammascan</span></summary>
      <div class="table-wrap"><table class="res gx-tbl"><thead><tr><th>Ticker</th><th class="r">Price</th><th>Gamma</th><th>Options lean</th><th class="r">Call wall</th><th class="r">Put wall</th><th>Biggest expiry</th><th class="r">Net premium</th><th>Unusual / hedges</th></tr></thead><tbody>
      ${res.rows.map((r) => `<tr data-t="${esc(r.ticker)}"><td><b>${esc(r.ticker)}</b></td><td class="r num">$${fmt(r.spot)}</td>
        <td>${r.regime === "positive" ? '<span class="gx-pill s3">positive</span>' : '<span class="gx-pill s0">negative</span>'} <span class="muted small">${r.flip ? (r.above_flip ? "above flip" : "below flip") : ""}</span></td>
        <td>${lean[r.lean]}<div class="muted small">${esc((r.why || []).join(" · "))}</div></td>
        <td class="r num">${r.call_wall ? "$" + fmt(r.call_wall, 0) : "–"}</td><td class="r num">${r.put_wall ? "$" + fmt(r.put_wall, 0) : "–"}</td>
        <td class="num small">${r.big_exp ? `${esc(r.big_exp.date.slice(5))} · ${fmt(r.big_exp.share, 0)}%` : "–"}</td>
        <td class="r num ${r.flow.net_premium > 0 ? "pos" : r.flow.net_premium < 0 ? "neg" : ""}">${gmoney(r.flow.net_premium)}</td>
        <td class="small gx-unus">${r.unusual.slice(0, 2).map((u) => `🔥 ${esc(u.exp.slice(5))} $${fmt(u.strike, 0)}${u.type === "call" ? "C" : "P"} ${gmoney(u.premium).replace("+", "")}`).join("<br>")}${r.hedges.map((h) => `<br>🛡 ${esc(h.exp)} $${fmt(h.strike, 0)}P ${gmoney(h.premium).replace("+", "")} (${fmt(h.otm_pct, 0)}% OTM)`).join("")}</td></tr>`).join("")}</tbody></table></div>
      ${res.errors && res.errors.length ? `<p class="muted small">Skipped: ${esc(res.errors.slice(0, 5).join("; "))}</p>` : ""}</details>`;
    const box = $("#gxScanBox"); if (box) box.ontoggle = () => (P.gx.scanOpen = box.open);
    $$("#gxScan tr[data-t]").forEach((tr) => (tr.onclick = () => { P.gx.dates = null; loadGamma(tr.dataset.t); }));
  }

  function drawGamma() {
    const G = P.gx, d = G.data, el = $("#gxInner");
    if (!el) return;
    if (d.error) { el.innerHTML = `<div class="err">${esc(d.error)}</div>`; return; }
    $("#gxAsOf").textContent = `as of ${new Date(d.as_of).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })} · ${d.used.length} expirations`;
    const pctFrom = (x) => (x == null ? "" : `<span class="muted small">${pct((x / d.spot - 1) * 100, 1)}</span>`);
    const pos = d.regime === "positive";
    let html = `<div class="gx-cards">
      <div class="gx-card"><span>Price</span><b class="num">$${fmt(d.spot)}</b><small class="muted">${esc(d.ticker)}</small></div>
      <div class="gx-card ${pos ? "good" : "bad"}"><span>Dealer gamma</span><b>${pos ? "Positive" : "Negative"}</b><small>${gmoney(d.total_gex)} per 1% move · ${pos ? "moves get damped, levels hold better" : "moves can speed up, levels break easier"}</small></div>
      <div class="gx-card"><span>Gamma flip</span><b class="num">${d.flip ? "$" + fmt(d.flip) : "–"}</b><small>${d.flip ? (d.spot >= d.flip ? "price is above it" : "price is below it") + " " + pctFrom(d.flip) : "no flip within ±15%"}</small></div>
      <div class="gx-card"><span>Call wall</span><b class="num">${d.call_wall_above ? "$" + fmt(d.call_wall_above) : "–"}</b><small>ceiling / target ${pctFrom(d.call_wall_above)}${d.call_wall !== d.call_wall_above && d.call_wall ? ` · biggest overall $${fmt(d.call_wall)}` : ""}</small></div>
      <div class="gx-card"><span>Put wall</span><b class="num">${d.put_wall_below ? "$" + fmt(d.put_wall_below) : "–"}</b><small>support ${pctFrom(d.put_wall_below)}${d.put_wall !== d.put_wall_below && d.put_wall ? ` · biggest overall $${fmt(d.put_wall)}` : ""}</small></div>
      <div class="gx-card"><span>Expected move</span><b class="num">${d.expected_move ? "±" + fmt(d.expected_move.pct, 1) + "%" : "–"}</b><small>${d.expected_move ? `$${fmt(d.expected_move.low)} – $${fmt(d.expected_move.high)} by ${esc(d.expected_move.date)}` : ""}</small></div>
    </div>`;
    html += `<div class="gx-grid">
      <div class="card gx-chart-card"><h3>Gamma by strike <span class="muted small">calls right (green) · puts left (red) · dot = net</span></h3>${gxStrikeChart(d)}</div>
      <div class="gx-side">
        ${d.plan && !d.plan.tp && !d.plan.sl ? `<div class="card gx-plan"><h3>Trade plan from gamma</h3><p class="muted small" style="margin:0">No gamma wall or pin is far enough from $${fmt(d.plan.entry)} for a take profit (1.5%+ above) or a stop (1%+ below). Try <b>Next 3 months</b> for levels further out.</p></div>` : ""}
        ${d.plan && (d.plan.tp || d.plan.sl) ? `<div class="card gx-plan"><h3>Trade plan from gamma <span class="muted small">long from $${fmt(d.plan.entry)}</span></h3>
          <div class="gx-plan-row"><span>Take profit</span><b class="num pos">${d.plan.tp ? "$" + fmt(d.plan.tp.price) : "–"}</b><small class="muted">${d.plan.tp ? pct(d.plan.tp_pct, 1) + " · just under the " + esc(d.plan.tp.why) + " $" + fmt(d.plan.tp.level) : "no resistance within range"}</small></div>
          ${d.plan.tp2 ? `<div class="gx-plan-row"><span>Second target</span><b class="num">$${fmt(d.plan.tp2.price)}</b><small class="muted">${esc(d.plan.tp2.why)} $${fmt(d.plan.tp2.level)}</small></div>` : ""}
          <div class="gx-plan-row"><span>Stop loss</span><b class="num neg">${d.plan.sl ? "$" + fmt(d.plan.sl.price) : "–"}</b><small class="muted">${d.plan.sl ? pct(d.plan.sl_pct, 1) + " · 1% under the " + esc(d.plan.sl.why) + " $" + fmt(d.plan.sl.level) : "no gamma support within 15%"}</small></div>
          ${d.plan.rr != null ? `<div class="gx-plan-row"><span>Reward / risk</span><b class="num">${fmt(d.plan.rr, 1)}</b><small class="muted">${d.plan.rr >= 2 ? "good" : d.plan.rr >= 1 ? "okay" : "poor: target is closer than the stop"}</small></div>` : ""}
          ${d.plan.warning ? `<p class="small neg" style="margin:6px 0 0">${esc(d.plan.warning)}</p>` : ""}</div>` : ""}
        <div class="card" id="gxOpt"><h3>Calls or shares?</h3><div id="gxOptBody"><p class="muted small" style="margin:0 0 8px">Scores every liquid call against your Strategy Test track record (win rate, avg win/loss, days held).</p><button class="btn ghost" id="gxOptLoad">${ic("refresh", 14)} Find the best call</button></div></div>
        <div class="card"><h3>Check a price</h3><form id="gxCheck" class="gx-check"><input type="number" step="0.01" name="p" placeholder="e.g. ${fmt(d.put_wall_below || d.spot, 0)}" aria-label="Price to check"><button class="btn primary">Check</button></form><div id="gxVerdict" class="muted small">Will price reject there or move through it fast?</div></div>
        <div class="card"><h3>Your EMAs vs gamma</h3>${d.confirmations.length ? `<div class="gx-conf">${d.confirmations.sort((a, b) => Math.abs(a.dist_pct) - Math.abs(b.dist_pct)).map((c) => `
          <div class="gx-conf-row"><div><b>${esc(c.name)}</b> <span class="num">$${fmt(c.level)}</span> <span class="muted small">${pct(c.dist_pct, 1)}</span></div>
          <div class="gx-pill s${c.score >= 3 ? 3 : c.score >= 1 ? 1 : 0}">${esc(c.label)}</div><div class="muted small">${esc(c.why.join(" · "))}</div></div>`).join("")}</div>` : `<p class="muted">No EMA data.</p>`}</div>
        <div class="card"><h3>Levels</h3>
          ${d.pins.length ? `<div class="gx-lv"><span class="gx-pill s3">Pin / reject</span> ${d.pins.map((x) => `<button class="lv" data-p="${x}">$${fmt(x, x % 1 ? 1 : 0)}</button>`).join("")}</div>` : ""}
          ${d.accel.length ? `<div class="gx-lv"><span class="gx-pill s0">Fast if hit</span> ${d.accel.map((x) => `<button class="lv" data-p="${x}">$${fmt(x, x % 1 ? 1 : 0)}</button>`).join("")}</div>` : ""}
          ${d.pockets.length ? `<div class="gx-lv"><span class="gx-pill s1">Air pockets</span> ${d.pockets.map((p) => `<span class="num small">$${fmt(p[0], 0)}–$${fmt(p[1], 0)}</span>`).join(" · ")}</div>` : ""}
          <p class="muted small">Click a level to check it. Air pockets have almost no gamma: price can cross them quickly.</p></div>
      </div></div>`;
    html += `<div class="card"><h3>Gamma if price moves <span class="muted small">total dealer gamma at each price · above zero = damped, below = accelerating</span></h3>${gxProfile(d)}</div>`;
    const f = d.flow;
    html += `<div class="two">
      <div class="card"><h3>Expirations <span class="muted small">tick dates and reload to focus on them</span></h3><div class="table-wrap"><table class="res gx-tbl"><thead><tr><th></th><th>Date</th><th class="r">Days</th><th class="r">Share of gamma</th><th class="r">Net gamma</th><th class="r">Put/Call OI</th><th class="r">Max pain</th></tr></thead>
        <tbody>${d.expirations.map((e) => `<tr><td><input type="checkbox" class="gx-d" value="${e.date}" ${!G.dates || G.dates.includes(e.date) ? "checked" : ""}></td><td class="num">${esc(parseDay(e.date).toLocaleDateString(undefined, { month: "short", day: "numeric" }))}${isOpex(e.date) ? ' <span class="tag">OPEX</span>' : ""}</td>
          <td class="r num">${e.days}</td><td class="r num"><span class="gx-share"><i style="width:${Math.min(100, e.share || 0)}%"></i></span>${fmt(e.share, 0)}%</td>
          <td class="r num ${cls(e.net_gex)}">${gmoney(e.net_gex)}</td><td class="r num">${e.pc_oi == null ? "–" : fmt(e.pc_oi, 2)}</td><td class="r num">${e.max_pain ? "$" + fmt(e.max_pain, 0) : "–"}</td></tr>`).join("")}</tbody></table></div>
        <div class="toolbar" style="margin:10px 0 0"><button class="btn ghost" id="gxDates">Reload with ticked dates</button>
          <select id="gxAdd" aria-label="Add an expiration"><option value="">Add another date…</option>${d.all_expirations.filter((x) => !d.used.includes(x)).slice(0, 40).map((x) => `<option>${x}</option>`).join("")}</select></div></div>
      <div class="card"><h3>Today's option flow <span class="muted small">estimated from Public's daily volume</span></h3>
        <div class="gx-flow">
          <div><span>Calls bought</span><b class="pos num">${gmoney(f.call_bought).replace("+", "")}</b></div><div><span>Calls sold</span><b class="num">${gmoney(f.call_sold).replace("+", "")}</b></div>
          <div><span>Puts bought</span><b class="neg num">${gmoney(f.put_bought).replace("+", "")}</b></div><div><span>Puts sold</span><b class="num">${gmoney(f.put_sold).replace("+", "")}</b></div>
          <div class="wide"><span>Net premium (calls bought − sold) − (puts bought − sold)</span><b class="num ${f.net_premium > 0 ? "pos" : "neg"}">${gmoney(f.net_premium)} · ${esc(f.tilt)}</b></div></div>
        ${d.hot.length ? `<div class="table-wrap"><table class="res gx-tbl"><thead><tr><th>Contract</th><th class="r">Premium</th><th class="r">Volume</th><th class="r">Vol / OI</th><th>Side</th></tr></thead><tbody>
          ${d.hot.map((h) => `<tr><td class="num">${esc(h.exp.slice(5))} <b>$${fmt(h.strike, h.strike % 1 ? 1 : 0)} ${h.type === "call" ? "C" : "P"}</b></td><td class="r num">${gmoney(h.premium).replace("+", "")}</td><td class="r num">${fmt(h.volume, 0)}</td>
            <td class="r num ${h.vol_oi > 1 ? "pos" : ""}">${h.vol_oi == null ? "–" : fmt(h.vol_oi, 2)}</td><td>${h.side === "bought" ? '<span class="pos">bought</span>' : '<span class="muted">sold</span>'}</td></tr>`).join("")}</tbody></table></div>
          <p class="muted small">Vol/OI above 1 = more traded today than was open: likely new positions. Sides are estimates.</p>` : `<p class="muted">No option trades yet today.</p>`}</div></div>`;
    if (d.errors && d.errors.length) html += `<p class="muted small">Some dates didn't load: ${esc(d.errors.join("; "))}</p>`;
    el.innerHTML = html;
    const check = async (price) => {
      const v = $("#gxVerdict");
      v.innerHTML = "Checking…";
      const r = await call("gamma_check", d.ticker, price);
      if (!r.ok) { v.textContent = r.error; return; }
      const lbl = { reject: ["s3", "Likely to stall / reject"], slow: ["s1", "Likely to slow down"], fast: ["s0", "Could move through fast"], open: ["s1", "Little in the way"] }[r.verdict];
      v.innerHTML = `<div class="gx-pill ${lbl[0]}">$${fmt(r.price)}: ${lbl[1]}</div><div>${esc(r.note)}</div><div class="muted small">Gamma within 1%: ${gmoney(r.local_gex)} · ${r.above_flip ? "above" : "below"} the flip</div>`;
    };
    const ol = $("#gxOptLoad"); if (ol) ol.onclick = () => drawOptFinder(d.ticker);
    $("#gxCheck").onsubmit = (e) => { e.preventDefault(); const p = +e.target.p.value; if (p > 0) check(p); };
    $$(".lv", el).forEach((b) => (b.onclick = () => { $("#gxCheck").p.value = b.dataset.p; check(+b.dataset.p); }));
    $("#gxDates").onclick = () => { G.dates = $$(".gx-d:checked", el).map((x) => x.value); if (!G.dates.length) return toast("Tick at least one date", true); loadGamma(G.ticker, true); };
    $("#gxAdd").onchange = (e) => { if (!e.target.value) return; G.dates = $$(".gx-d:checked", el).map((x) => x.value).concat(e.target.value); loadGamma(G.ticker, true); };
  }
  function isOpex(ds) { const d = parseDay(ds); return d.getDay() === 5 && d.getDate() >= 15 && d.getDate() <= 21; }

  function gxStrikeChart(d) {
    let rows = d.strikes.filter((r) => Math.abs(r.strike / d.spot - 1) <= 0.1 && (r.call_gex || r.put_gex));
    if (!rows.length) return `<p class="muted">No open interest near the price.</p>`;
    // group strikes into even buckets so the bars stay readable and sit on a true price scale
    const span = rows[rows.length - 1].strike - rows[0].strike;
    const bucket = rows.length > 70 ? niceStep(span / 60) : 0;
    if (bucket) {
      const m = {};
      rows.forEach((r) => { const k = Math.round(r.strike / bucket) * bucket; const b = m[k] || (m[k] = { strike: k, call_gex: 0, put_gex: 0, net_gex: 0 }); b.call_gex += r.call_gex; b.put_gex += r.put_gex; b.net_gex += r.net_gex; });
      rows = Object.values(m).sort((a, b) => a.strike - b.strike);
    }
    const hiS = Math.max(rows[rows.length - 1].strike, d.spot), loS = Math.min(rows[0].strike, d.spot);
    const gaps = rows.slice(1).map((r, i) => r.strike - rows[i].strike).filter((g) => g > 0);
    const unit = bucket || (gaps.length ? Math.min(...gaps) : 1);
    const W = 640, padL = 64, padR = 112, padT = 10, padB = 10;
    const H = Math.max(320, Math.min(900, ((hiS - loS) / unit) * 11 + padT + padB));
    const y = (price) => padT + ((hiS - price) / ((hiS - loS) || 1)) * (H - padT - padB);
    const bh = Math.max(2, Math.min(12, ((H - padT - padB) / ((hiS - loS) / unit || 1)) * 0.8));
    const mx = Math.max(...rows.map((r) => Math.max(r.call_gex, -r.put_gex)), 1);
    const cx = padL + (W - padL - padR) / 2, half = (W - padL - padR) / 2;
    let out = `<line x1="${cx}" x2="${cx}" y1="${padT}" y2="${H - padB}" stroke="var(--line)"/>`;
    const tick = niceStep((hiS - loS) / 14);
    for (let t = Math.ceil(loS / tick) * tick; t <= hiS; t += tick) out += `<text x="${padL - 8}" y="${y(t) + 4}" text-anchor="end" class="ax">${fmt(t, t % 1 ? 1 : 0)}</text><line x1="${padL - 4}" x2="${padL}" y1="${y(t)}" y2="${y(t)}" stroke="var(--line)"/>`;
    rows.forEach((r) => {
      const yy = y(r.strike) - bh / 2;
      const cw = Math.max(0, (r.call_gex / mx) * half), pw = Math.max(0, (-r.put_gex / mx) * half);
      const lbl = bucket ? `$${fmt(r.strike - bucket / 2, 0)}–$${fmt(r.strike + bucket / 2, 0)}` : `$${fmt(r.strike, r.strike % 1 ? 1 : 0)}`;
      out += `<rect x="${cx}" y="${yy}" width="${cw}" height="${bh}" fill="var(--pass)" opacity=".75"><title>${lbl}: calls ${gmoney(r.call_gex)}</title></rect>
        <rect x="${cx - pw}" y="${yy}" width="${pw}" height="${bh}" fill="var(--fail)" opacity=".75"><title>${lbl}: puts ${gmoney(r.put_gex)}</title></rect>
        <circle cx="${cx + (r.net_gex / mx) * half}" cy="${y(r.strike)}" r="2.2" fill="var(--text)"><title>${lbl}: net ${gmoney(r.net_gex)}</title></circle>`;
    });
    const used = [];
    const mark = (price, label, col, dash) => {
      if (price == null || price > hiS || price < loS) return "";
      const yy = y(price);
      let ty = yy + 4;
      while (used.some((u) => Math.abs(u - ty) < 12)) ty += 12;      // keep labels from overlapping
      used.push(ty);
      return `<line x1="${padL}" x2="${W - padR + 4}" y1="${yy}" y2="${yy}" stroke="${col}" stroke-width="1.4" ${dash ? 'stroke-dasharray="4 3"' : ""}/>
        <text x="${W - padR + 8}" y="${ty}" class="ax" fill="${col}">${esc(label)}</text>`;
    };
    out += mark(d.spot, `Price $${fmt(d.spot)}`, "var(--text)", false) + mark(d.call_wall, `Call wall $${fmt(d.call_wall, 0)}`, "var(--pass)", true) +
      mark(d.put_wall, `Put wall $${fmt(d.put_wall, 0)}`, "var(--fail)", true) + mark(d.flip, `Flip $${fmt(d.flip, 0)}`, "var(--near)", true);
    d.confirmations.filter((c) => !/^EMA (9|21)$/.test(c.name)).forEach((c) => (out += mark(c.level, c.name, "var(--slow)", true)));
    return `<svg viewBox="0 0 ${W} ${H}" class="qchart" role="img" aria-label="Gamma exposure by strike">${out}</svg>`;
  }

  function gxProfile(d) {
    const pr = d.profile.filter((p) => p.gex != null);
    if (!pr.length) return `<p class="muted">Not enough IV data to build the curve.</p>`;
    const W = 1100, H = 200, padT = 12, padB = 24, padR = 70;
    const xs = pr.map((p) => p.price), ys = pr.map((p) => p.gex);
    const x0 = Math.min(...xs), x1 = Math.max(...xs), ymax = Math.max(...ys.map(Math.abs), 1);
    const x = (v) => 4 + ((v - x0) / (x1 - x0)) * (W - padR - 8), y = (v) => padT + ((ymax - v) / (2 * ymax)) * (H - padT - padB);
    let out = `<line x1="0" x2="${W - padR}" y1="${y(0)}" y2="${y(0)}" stroke="var(--muted)" stroke-width=".8"/>`;
    out += `<path d="M${x(x0)} ${y(0)} ${pr.map((p) => `L${x(p.price).toFixed(1)} ${y(Math.max(0, p.gex)).toFixed(1)}`).join(" ")} L${x(x1)} ${y(0)}Z" fill="var(--pass)" opacity=".18"/>`;
    out += `<path d="M${x(x0)} ${y(0)} ${pr.map((p) => `L${x(p.price).toFixed(1)} ${y(Math.min(0, p.gex)).toFixed(1)}`).join(" ")} L${x(x1)} ${y(0)}Z" fill="var(--fail)" opacity=".18"/>`;
    out += `<path d="${pr.map((p, i) => (i ? "L" : "M") + x(p.price).toFixed(1) + " " + y(p.gex).toFixed(1)).join("")}" fill="none" stroke="var(--text)" stroke-width="1.8"/>`;
    const v = (price, label, col) => (price == null ? "" : `<line x1="${x(price)}" x2="${x(price)}" y1="${padT}" y2="${H - padB}" stroke="${col}" stroke-dasharray="4 3"/><text x="${x(price) + 4}" y="${padT + 10}" class="ax" fill="${col}">${label}</text>`);
    out += v(d.spot, "Price", "var(--text)") + v(d.flip, "Flip", "var(--near)");
    const step = niceStep((x1 - x0) / 8);
    for (let t = Math.ceil(x0 / step) * step; t <= x1; t += step) out += `<text x="${x(t)}" y="${H - 6}" class="ax" text-anchor="middle">${fmt(t, t >= 100 ? 0 : 2)}</text>`;
    out += `<text x="${W - padR + 6}" y="${y(ymax) + 4}" class="ax">${gmoney(ymax)}</text><text x="${W - padR + 6}" y="${y(-ymax) + 4}" class="ax">${gmoney(-ymax)}</text>`;
    return `<svg viewBox="0 0 ${W} ${H}" class="qchart" role="img" aria-label="Gamma profile">${out}</svg>`;
  }

  /* =====================================================================
     EMA FINDER: which moving average this stock has respected the most
     ===================================================================== */
  P.ef = { ticker: "", data: null, params: { kind: "EMA", min_len: 5, max_len: 250, step: 1, tolerance: 1, break_pct: 2, bounce_pct: 3, lookahead: 15, cooldown: 5, min_tests: 3 }, sort: "score" };

  function renderFinder() {
    const root = $("#finderBody"), F = P.ef, p = F.params, c = caps();
    if (!F.ticker) F.ticker = P.chart.ticker || (S.state.watchlist || [])[0] || "AAPL";
    root.innerHTML = `
      <div class="pg-head"><h1>EMA Finder</h1>${tickerForm("efForm", F.ticker, "Ticker", "Find")}
        <span class="muted small">Tests every ${esc(p.kind)} from ${p.min_len} to ${p.max_len} on the last 5 years to find the line price respects most</span></div>
      ${c.bars ? "" : needBox("The EMA finder", capSrc("bars"))}
      <details class="card ef-set"><summary><b>How a bounce is judged</b> <span class="muted small">touch within ${p.tolerance}% · bounce ${p.bounce_pct}% within ${p.lookahead} days · fails on a close ${p.break_pct}% under the line</span></summary>
        <form id="efSet" class="bt-set">
          <label>Average<select name="kind"><option ${p.kind === "EMA" ? "selected" : ""}>EMA</option><option ${p.kind === "SMA" ? "selected" : ""}>SMA</option></select></label>
          <label>Lengths from<input type="number" name="min_len" min="2" max="400" value="${p.min_len}"></label>
          <label>to<input type="number" name="max_len" min="2" max="400" value="${p.max_len}"></label>
          <label>Touch within<span class="unit-in"><input type="number" name="tolerance" step="0.1" min="0" max="5" value="${p.tolerance}">%</span></label>
          <label>Bounce = rally of<span class="unit-in"><input type="number" name="bounce_pct" step="0.5" min="0.5" max="30" value="${p.bounce_pct}">%</span></label>
          <label>within<span class="unit-in"><input type="number" name="lookahead" min="3" max="60" value="${p.lookahead}">days</span></label>
          <label>Fail = close under by<span class="unit-in"><input type="number" name="break_pct" step="0.5" min="0" max="15" value="${p.break_pct}">%</span></label>
          <label>Need at least<span class="unit-in"><input type="number" name="min_tests" min="1" max="20" value="${p.min_tests}">tests</span></label>
          <div class="bt-btns"><button class="btn primary">Find</button></div>
        </form></details>
      <div id="efInner"></div>`;
    bindGo(root);
    const set = $("#efSet");
    const read = () => Object.fromEntries([...new FormData(set)].map(([k, v]) => [k, k === "kind" ? v : +v]));
    set.onsubmit = (e) => { e.preventDefault(); F.params = { ...F.params, ...read() }; loadFinder(F.ticker); };
    $("#efForm").onsubmit = (e) => { e.preventDefault(); F.params = { ...F.params, ...read() }; loadFinder(cleanT(e.target.t.value)); };
    if (F.data && F.data.ticker === F.ticker) drawFinder();
    else if (c.bars) loadFinder(F.ticker);
  }

  async function loadFinder(t) {
    if (!t) return;
    const F = P.ef;
    F.ticker = t;
    const f = $("#efForm"); if (f) f.t.value = t;
    const el = $("#efInner");
    if (el) el.innerHTML = `<div class="loading">${ic("refresh", 18)} Testing ${F.params.max_len - F.params.min_len + 1} lines on ${esc(t)}…</div>`;
    const r = await call("find_emas", t, F.params);
    F.data = r && r.ok ? r : { ticker: t, error: (r && r.error) || "Couldn't run" };
    if (S.page === "finder" && F.ticker === t) drawFinder();
  }

  function drawFinder() {
    const F = P.ef, d = F.data, el = $("#efInner");
    if (!el) return;
    if (d.error) { el.innerHTML = `<div class="err">${esc(d.error)}</div>`; return; }
    const k = d.params.kind;
    const pc = (v, colour) => (v == null ? `<span class="muted">–</span>` : `<span class="${colour ? cls(v) : ""}">${v > 0 && colour ? "+" : ""}${fmt(v, 1)}%</span>`);
    const per = `${parseDay(d.period.start).toLocaleDateString(undefined, { month: "short", year: "numeric" })} – ${parseDay(d.period.end).toLocaleDateString(undefined, { month: "short", year: "numeric" })}`;
    if (!d.best) {
      el.innerHTML = `<div class="empty"><p><b>No line was tested ${d.params.min_tests}+ times by ${esc(d.ticker)} in ${per}.</b></p>
        <p class="muted">It may have spent the period below its averages, or moved too fast to come back to them. Try a wider touch % or fewer required tests.</p></div>`;
      return;
    }
    const b = d.top[0], det = d.best_detail;
    let html = `<div class="ef-hero card">
      <div><div class="muted small">Most respected line · ${per}</div>
        <div class="ef-best num">${esc(k)} ${d.best}</div>
        <div>Price came down to it <b>${b.tests}</b> times and bounced <b>${b.bounces}</b> (${fmt(b.respect, 0)}%).
          Broke through ${b.breaks} time${b.breaks === 1 ? "" : "s"}.</div></div>
      <div class="ef-stats">
        <div class="stat"><span>Typical distance from it</span><b class="num">${fmt(b.avg_abs_dist, 1)}%</b></div>
        <div class="stat"><span>Median distance when above</span><b class="num">${b.median_dist_above == null ? "–" : "+" + fmt(b.median_dist_above, 1) + "%"}</b></div>
        <div class="stat"><span>Avg rally after a touch (20d)</span><b class="num">${pc(b.avg_bounce, true)}</b></div>
        <div class="stat"><span>Avg dip under it on a test</span><b class="num">${pc(b.avg_undercut, true)}</b></div>
        <div class="stat"><span>Days to bounce (median)</span><b class="num">${b.days_to_bounce ?? "–"}</b></div>
        <div class="stat"><span>Price now vs line</span><b class="num">${pc(b.now_dist, true)} <span class="muted small">($${fmt(b.now_ma)})</span></b></div>
      </div>
      <div class="ef-actions"><button class="btn primary" id="efChart">${ic("charts")} Show on chart</button>
        <button class="btn ghost" id="efAlert">${ic("alerts")} Alert on this line</button></div></div>`;
    html += `<div class="chart-card bt-chart">${efChart(d)}<div class="seg-legend"><span class="key"><i style="background:var(--text)"></i>Price</span>
      <span class="key"><i style="background:var(--fast)"></i>${esc(k)} ${d.best}</span>
      <span class="key"><i class="dot-k" style="background:var(--pass)"></i>Bounced</span><span class="key"><i class="dot-k" style="background:var(--fail)"></i>Broke</span>
      <span class="key"><i class="dot-k" style="background:var(--muted)"></i>Faded / too recent</span></div></div>`;
    html += `<div class="card"><h3>Respect by length <span class="muted small">bounce rate for every ${esc(k)} tested · bars = how many times it was tested</span></h3>${efCurve(d)}</div>`;
    const cl = Object.entries(d.classics);
    const rowsHtml = (rows) => rows.map((r) => `<tr data-len="${r.length}" class="${r.length === d.best ? "best-row" : ""}"><td class="tk">${esc(k)} ${r.length}</td>
        <td class="r num">${r.tests}</td><td class="r num">${r.bounces}</td><td class="r num">${r.respect == null ? "–" : fmt(r.respect, 0) + "%"}</td>
        <td class="r num">${fmt(r.score, 0)}</td><td class="r num">${fmt(r.avg_abs_dist, 1)}%</td><td class="r num">${pc(r.avg_bounce, true)}</td>
        <td class="r num">${pc(r.avg_undercut, true)}</td><td class="r num">${pc(r.now_dist, true)}</td></tr>`).join("");
    const head = `<thead><tr><th>Line</th><th class="r">Tests</th><th class="r">Bounces</th><th class="r">Respect</th><th class="r" title="Respect adjusted for how many tests: 9 of 10 beats 2 of 2">Score</th>
      <th class="r">Typical distance</th><th class="r">Avg rally</th><th class="r">Avg dip under</th><th class="r">Now vs line</th></tr></thead>`;
    html += `<div><div class="card"><h3>Top 10 <span class="muted small">one per area (179, 180, 181… count as the same line) · click a row to chart it</span></h3><div class="table-wrap"><table class="res bt-tbl ef-tbl">${head}<tbody>${rowsHtml(d.top)}</tbody></table></div></div>
      <div class="card"><h3>The usual lines</h3><div class="table-wrap"><table class="res bt-tbl ef-tbl">${head}<tbody>${rowsHtml(cl.map(([, v]) => v).filter((v) => v))}</tbody></table></div></div></div>
      <p class="muted small">A test = price came down to the line from above (low within ${d.params.tolerance}% of it). Bounce = a ${d.params.bounce_pct}% rally off the line within ${d.params.lookahead} days before any close more than ${d.params.break_pct}% under it.
        Score ranks lines by bounce rate adjusted for sample size. Every line is judged over the same days. Past respect doesn't guarantee the next bounce.</p>`;
    el.innerHTML = html;
    const useLine = (len) => {
      const ma = chartCfg();
      ma[0] = { ...ma[0], on: true, type: k, len };
      P.chart.ticker = d.ticker; P.chart.data = null; saveChartCfg(); show("charts");
    };
    $("#efChart").onclick = () => useLine(d.best);
    $("#efAlert").onclick = () => { P.alerts.draft = { ticker: d.ticker, kind: "ma_touch", ma_type: k, length: d.best, direction: "above" }; show("alerts"); };
    $$(".ef-tbl tbody tr", el).forEach((tr) => (tr.onclick = () => useLine(+tr.dataset.len)));
  }

  function efChart(d) {
    const ch = d.best_detail.chart, W = 1100, H = 280, padT = 10, padB = 22, padR = 60;
    const all = ch.c.concat(ch.ma).filter((v) => v != null);
    let max = Math.max(...all), min = Math.min(...all);
    const pad = (max - min) * 0.05; max += pad; min -= pad;
    const n = ch.t.length, x = (i) => 4 + (i / Math.max(1, n - 1)) * (W - padR - 8);
    const y = (v) => padT + ((max - v) / (max - min)) * (H - padT - padB);
    const path = (arr) => arr.map((v, i) => (v == null ? "" : (i && arr[i - 1] != null ? "L" : "M") + x(i).toFixed(1) + " " + y(v).toFixed(1))).join("");
    let out = "";
    const step = niceStep((max - min) / 5);
    for (let v = Math.ceil(min / step) * step; v <= max; v += step) out += `<line x1="0" x2="${W - padR}" y1="${y(v)}" y2="${y(v)}" stroke="var(--line-soft)"/><text x="${W - padR + 6}" y="${y(v) + 4}" class="ax">${fmt(v, v >= 100 ? 0 : 2)}</text>`;
    let ly = "";
    ch.t.forEach((t, i) => { if (t.slice(0, 4) !== ly && i > 0) out += `<text x="${x(i)}" y="${H - 5}" class="ax" text-anchor="middle">${t.slice(0, 4)}</text>`; ly = t.slice(0, 4); });
    out += `<path d="${path(ch.ma)}" fill="none" stroke="var(--fast)" stroke-width="2"/><path d="${path(ch.c)}" fill="none" stroke="var(--text)" stroke-width="1.2" opacity=".85"/>`;
    const pos = (date) => { let lo = 0, hi = n - 1; while (lo < hi) { const m = (lo + hi) >> 1; if (ch.t[m] < date) lo = m + 1; else hi = m; } return lo; };
    d.best_detail.events.forEach((e) => {
      const col = e.outcome === "bounce" ? "var(--pass)" : e.outcome === "break" ? "var(--fail)" : "var(--muted)";
      out += `<circle cx="${x(pos(e.date))}" cy="${y(e.low)}" r="5" fill="${col}" stroke="var(--panel)" stroke-width="1.5"><title>${e.date} · ${e.outcome} · low $${fmt(e.low)} vs line $${fmt(e.ma)}</title></circle>`;
    });
    return `<svg viewBox="0 0 ${W} ${H}" class="qchart" role="img" aria-label="Price with the most respected line">${out}</svg>`;
  }

  function efCurve(d) {
    const rows = d.rows, W = 1100, H = 200, padT = 12, padB = 24, padR = 50;
    const maxT = Math.max(1, ...rows.map((r) => r.tests));
    const L0 = rows[0].length, L1 = rows[rows.length - 1].length;
    const x = (L) => 4 + ((L - L0) / Math.max(1, L1 - L0)) * (W - padR - 8);
    const y = (v) => padT + ((100 - v) / 100) * (H - padT - padB);
    const bw = Math.max(1, (W - padR) / rows.length * 0.7);
    let out = "";
    [0, 25, 50, 75, 100].forEach((v) => (out += `<line x1="0" x2="${W - padR}" y1="${y(v)}" y2="${y(v)}" stroke="var(--line-soft)"/><text x="${W - padR + 6}" y="${y(v) + 4}" class="ax">${v}%</text>`));
    rows.forEach((r) => { const h = (r.tests / maxT) * (H - padT - padB) * 0.45; out += `<rect x="${x(r.length) - bw / 2}" y="${H - padB - h}" width="${bw}" height="${h}" fill="var(--slow)" opacity=".35"><title>${d.params.kind} ${r.length}: tested ${r.tests} times</title></rect>`; });
    let dd = "", started = false;
    rows.forEach((r) => { if (r.respect == null || r.tests < d.params.min_tests) { started = false; return; } dd += (started ? "L" : "M") + x(r.length).toFixed(1) + " " + y(r.respect).toFixed(1); started = true; });
    out += `<path d="${dd}" fill="none" stroke="var(--pass)" stroke-width="2"/>`;
    const tick = L1 - L0 > 150 ? 25 : L1 - L0 > 60 ? 10 : 5;
    for (let L = Math.ceil(L0 / tick) * tick; L <= L1; L += tick) out += `<text x="${x(L)}" y="${H - 6}" class="ax" text-anchor="middle">${L}</text>`;
    out += `<line x1="${x(d.best)}" x2="${x(d.best)}" y1="${padT}" y2="${H - padB}" stroke="var(--fast)" stroke-dasharray="4 4"/><text x="${x(d.best) + 5}" y="${padT + 10}" class="ax" fill="var(--fast)">${d.params.kind} ${d.best}</text>`;
    return `<svg viewBox="0 0 ${W} ${H}" class="qchart" role="img" aria-label="Bounce rate by length">${out}</svg>`;
  }


  /* =====================================================================
     STRATEGY TEST: replay the Investing alert for 5 years + stop-loss finder
     ===================================================================== */
  P.sbt = { data: null, params: null, poll: null, sort: ["calmar", -1], daysShown: 30, curveMode: "value", hidden: {} };
  const SB_PERIODS = [["all", "All the data"], ["20y", "Past 20 years"], ["15y", "Past 15 years"], ["10y", "Past 10 years"], ["5y", "Past 5 years"], ["3y", "Past 3 years"], ["2y", "Past 2 years"], ["1y", "Past year"],
    ["ytd", "Year to date"], ["6m", "Past 6 months"], ["3m", "Past 3 months"], ["1m", "Past month"]];
  const SB_LINES = [["Strategy", "var(--text)"], ["Calls", "#A77BFF"], ["All sectors", "var(--muted)"], ["No filters", "var(--muted)"], ["SPY", "#3FA7F5"], ["QQQ", "var(--fast)"], ["RSP", "#E0569B"]];
  const OPT_DTE = [[21, "1 month"], [42, "2 months"], [63, "3 months"], [126, "6 months"], [252, "1 year"], [378, "18 months"]];
  const OPT_DELTA = [[0.85, "0.85 deep in the money"], [0.7, "0.70 in the money"], [0.5, "0.50 at the money"], [0.3, "0.30 out of the money"]];
  const SUP_SIGNALS = [["light_pullback", "Pullback on light volume"], ["strong_close", "Closed strong at the line"], ["absorption", "Heavy volume, but it held"],
    ["accumulation", "Accumulation into the pullback"], ["respected", "Line held before"], ["no_repeat", "Skip if the line just failed"]];
  const SECTOR_FILTERS = [["off", "Any sector", ""], ["leading", "Leading only", "Rotation"], ["leading_improving", "Leading or Improving", "Rotation"], ["not_lagging", "Anything but Lagging", "Rotation"],
    ["undervalued", "Undervalued only (+3 or more)", "Valuation"], ["not_overvalued", "Anything but Overvalued", "Valuation"]];
  const stopKey = (s) => `${s.type}:${s.value ?? ""}`;

  async function renderStrategyBt() {
    const root = $("#strategybtBody"), B = P.sbt;
    if (!B.hiddenLoaded) { try { B.hidden = JSON.parse(localStorage.getItem("sbHidden") || "{}") || {}; } catch (e) { B.hidden = {}; } B.hiddenLoaded = true; }
    if (!B.data) B.data = await call("get_strategy_bt");
    const d = B.data || {};
    if (!B.params) B.params = Object.assign({}, d.defaults || {}, (d.result && d.result.params) || {});
    const p = B.params, c = caps();
    const st = d.status || {};
    const stops = d.stops || [], tps = d.tps || [{ type: "none", label: "No take profit" }];
    const tpLabel = (tps.find((s) => stopKey(s) === stopKey(p.take_profit || { type: "none" })) || { label: "No take profit" }).label;
    const secLabel = (SECTOR_FILTERS.find((x) => x[0] === (p.sector_filter || "off")) || SECTOR_FILTERS[0])[1];
    root.innerHTML = `
      <div class="pg-head"><h1>Strategy Test</h1>
        <select id="sbUni" aria-label="Which stocks"><option value="all" ${p.universe !== "watchlist" ? "selected" : ""}>All stocks over $${fmt(Math.max(1, (p.min_cap_b || 5) / 2.5), 0)}B (first run ~15–30 min)</option><option value="watchlist" ${p.universe === "watchlist" ? "selected" : ""}>My watchlist only (about a minute)</option></select>
        <select id="sbSrc" aria-label="Price data" title="Public: 5 years of daily bars. FMP: up to 30 years of daily bars (needs an FMP key on Data sources; long history needs FMP Premium)">
          <option value="public" ${p.data_source !== "fmp" ? "selected" : ""}>Prices: Public (5 years)</option>
          <option value="fmp" ${p.data_source === "fmp" ? "selected" : ""} ${d.fmp ? "" : "disabled"}>Prices: FMP${d.fmp ? "" : " (add key on Data sources)"}</option></select>
        <select id="sbYears" aria-label="Years of FMP data" ${p.data_source === "fmp" ? "" : "hidden"}>${[10, 15, 20, 30].map((y) => `<option value="${y}" ${+(p.years || 10) === y ? "selected" : ""}>${y} years</option>`).join("")}</select>
        <select id="sbPeriod" aria-label="Test period">${SB_PERIODS.map(([k, l]) => `<option value="${k}" ${(p.period || "all") === k ? "selected" : ""}>${l}</option>`).join("")}</select>
        <button class="btn primary" id="sbRun">${ic("play")} Run backtest</button>
        <span class="sb-opt-ctl"><select id="sbObj" aria-label="What to optimize for">
            <option value="cagr">Best match: highest return</option><option value="calmar">Best match: return for the risk</option><option value="vs_qqq">Best match: beat QQQ most</option></select>
          <button class="btn ghost" id="sbBest" title="Searches stops, take profits, hold time and every filter on the first 70% of the period, then checks the winner on the last 30% it never saw">${ic("refresh", 14)} Find best settings</button></span>
        <label class="muted small sb-chk"><input type="checkbox" id="sbRefresh"> Re-download data</label>
        <div id="sbStatus" class="db-status"></div></div>
      ${c.bars && c.fundamentals_all ? "" : needBox("The strategy test", "Public.com (prices) and SEC EDGAR (filings)")}
      <p class="muted" style="margin:-6px 0 14px;max-width:120ch">Goes back through every trading day of the last ~${p.data_source === "fmp" ? (p.years || 10) : 5} years${p.period && p.period !== "all" ? ` (testing ${esc((SB_PERIODS.find((x) => x[0] === p.period) || [0, ""])[1].toLowerCase())})` : ""}, finds every stock your <b>Investing</b> alert would have flagged that evening
        (using only the filings that were public by then), buys it at that close, and tracks it for up to ${p.hold_days || 252} trading days. Then it tests ${stops.length} stop-loss rules on the same alerts and compares everything with SPY, QQQ and RSP (equal-weight S&P 500).</p>
      <details class="card ef-set" id="sbSet"><summary><b>Rules being tested</b> <span class="muted small">${esc(p.ma_type)} ${p.fast}/${p.slow} touch within ${p.tolerance}% · cap ≥ $${p.min_cap_b || 0}B${p.use_fcf ? " · FCF > 0" : ""}${p.use_rev ? " · revenue up" : ""}${p.use_eps ? " · EPS up" : ""} · hold ${p.hold_days} days · ${p.slots} slots · stop: ${esc((stops.find((s) => stopKey(s) === stopKey(p.stop || { type: "none" })) || { label: "No stop" }).label)} · take profit: ${esc(tpLabel)}${p.sector_filter && p.sector_filter !== "off" ? ` · sector: ${esc(secLabel)}` : ""}${(p.require || []).length ? ` · support: ${(p.require || []).length} required` : ""}${p.use_debt ? ` · debt ≤ ${p.max_debt_mcap ? p.max_debt_mcap + "% of cap" : ""}${p.max_debt_mcap && p.max_debt_rev ? " & " : ""}${p.max_debt_rev ? p.max_debt_rev + "% of revenue" : ""}${p.max_debt_equity ? " · D/E ≤ " + p.max_debt_equity : ""}` : ""}${p.use_speed ? ` · fell ≤ ${p.speed_max_drop}% in ${p.speed_days || 5}d${p.speed_max_gap ? ", gap ≤ " + p.speed_max_gap + "%" : ""}` : ""}${p.use_rel ? ` · ≤ ${p.rel_max_spy} pts weaker than SPY` : ""}${p.use_touches ? ` · touch #${p.touch_max} or earlier` : ""}${p.use_slope ? ` · slow line ≥ ${p.slope_min}% in ${p.slope_days || 60}d` : ""}${p.use_earn && (p.earn_before || p.earn_after) ? ` · no earnings ${[p.earn_before ? "within " + p.earn_before + "d ahead" : "", p.earn_after ? p.earn_after + "d after" : ""].filter(Boolean).join(" / ")}` : ""}${p.use_ext && (p.ext_max_spread || p.ext_max_peak) ? ` · not extended (${[p.ext_max_spread ? "fast ≤ " + p.ext_max_spread + "% above slow" : "", p.ext_max_peak ? "peak ≤ " + p.ext_max_peak + "% in " + (p.ext_days || 60) + "d" : ""].filter(Boolean).join(", ")}${p.ext_beta ? ", × beta" : ""})` : ""}${p.use_beta && (p.beta_min || p.beta_max) ? ` · beta ${p.beta_min ? "≥ " + p.beta_min : ""}${p.beta_min && p.beta_max ? " & " : ""}${p.beta_max ? "≤ " + p.beta_max : ""}` : ""}${(p.exclude_years || []).length ? ` · leaving out ${(p.exclude_years || []).join(", ")}` : ""}${p.macro_min != null ? ` · macro ≥ ${p.macro_min}` : ""}${p.theme_max_risk != null ? ` · theme < ${p.theme_max_risk} warnings` : ""}</span></summary>
        <form id="sbForm" class="bt-set">
          <label>Average<select name="ma_type"><option ${p.ma_type === "EMA" ? "selected" : ""}>EMA</option><option ${p.ma_type === "SMA" ? "selected" : ""}>SMA</option></select></label>
          <label>Fast<input type="number" name="fast" min="2" max="400" value="${p.fast}"></label>
          <label>Slow<input type="number" name="slow" min="2" max="400" value="${p.slow}"></label>
          <label>Lines<select name="lines">${[["both", "Both"], ["fast", "Fast only"], ["slow", "Slow only"]].map(([k, l]) => `<option value="${k}" ${p.lines === k ? "selected" : ""}>${l}</option>`).join("")}</select></label>
          <label>Touch within<span class="unit-in"><input type="number" name="tolerance" step="0.1" min="0" max="5" value="${p.tolerance}">%</span></label>
          <label>Above both lines<span class="unit-in"><input type="number" name="above_days" min="0" max="20" value="${p.above_days}">of 20 days</span></label>
          <label class="chk"><input type="checkbox" name="hold" ${p.hold ? "checked" : ""}> Close held the line</label>
          <label class="chk"><input type="checkbox" name="new_only" ${p.new_only ? "checked" : ""}> First day of a touch only</label>
          <label>Market cap at least<span class="unit-in"><input type="number" name="min_cap_b" step="0.5" min="0" value="${p.min_cap_b}">$B</span></label>
          <label class="chk"><input type="checkbox" name="use_fcf" ${p.use_fcf ? "checked" : ""}> FCF positive</label>
          <label class="chk"><input type="checkbox" name="use_rev" ${p.use_rev ? "checked" : ""}> Revenue up YoY</label>
          <label class="chk"><input type="checkbox" name="use_eps" ${p.use_eps ? "checked" : ""}> EPS up YoY</label>
          <label>Hold up to<span class="unit-in"><input type="number" name="hold_days" min="5" max="756" value="${p.hold_days}">trading days</span></label>
          <label>Portfolio slots<span class="unit-in"><input type="number" name="slots" min="1" max="50" value="${p.slots}">positions</span></label>
          <label>Stop loss<select name="stop">${stops.map((s) => `<option value="${stopKey(s)}" ${stopKey(s) === stopKey(p.stop || { type: "none" }) ? "selected" : ""}>${esc(s.label)}</option>`).join("")}</select></label>
          <label>Take profit<select name="take_profit">${tps.map((s) => `<option value="${stopKey(s)}" ${stopKey(s) === stopKey(p.take_profit || { type: "none" }) ? "selected" : ""}>${esc(s.label)}</option>`).join("")}</select></label>
          <label title="Rotation: the stock's sector ETF vs SPY on the alert day. Valuation: the sector's −10…+10 score on the alert day.">Sector filter<select name="sector_filter">
            <option value="off" ${(p.sector_filter || "off") === "off" ? "selected" : ""}>Any sector</option>
            ${["Rotation", "Valuation"].map((g) => `<optgroup label="${g === "Rotation" ? "Leading sectors (rotation)" : "Undervalued sectors (valuation)"}">${SECTOR_FILTERS.filter((x) => x[2] === g).map(([k, l]) => `<option value="${k}" ${p.sector_filter === k ? "selected" : ""}>${l}</option>`).join("")}</optgroup>`).join("")}</select></label>
          <div class="sb-sup" style="width:100%"><span class="muted small">Only take alerts with:</span>
            ${SUP_SIGNALS.map(([k, l]) => `<label class="chk"><input type="checkbox" name="req_${k}" ${(p.require || []).includes(k) ? "checked" : ""}> ${l}</label>`).join("")}</div>
          <div class="sb-sup" style="width:100%"><label class="chk"><input type="checkbox" name="use_debt" ${p.use_debt ? "checked" : ""}> <b>Debt filter:</b></label>
            <label class="inl">at most <input type="number" name="max_debt_mcap" min="0" step="5" value="${p.max_debt_mcap ?? 50}" style="width:70px">% of market cap</label>
            <label class="inl">and <input type="number" name="max_debt_rev" min="0" step="10" value="${p.max_debt_rev ?? 150}" style="width:76px">% of yearly revenue</label>
            <label class="inl">debt-to-equity at most <input type="number" name="max_debt_equity" min="0" step="0.1" value="${p.max_debt_equity ?? 1.5}" style="width:64px">×</label>
            <label class="chk"><input type="checkbox" name="debt_block_neg_equity" ${p.debt_block_neg_equity !== false ? "checked" : ""}> block negative equity</label>
            <label class="chk"><input type="checkbox" name="debt_net" ${p.debt_net ? "checked" : ""}> subtract cash</label>
            <label class="chk"><input type="checkbox" name="debt_skip_fin" ${p.debt_skip_fin !== false ? "checked" : ""}> skip banks/insurers/REITs</label>
            <span class="muted small">(0 = don't check that one)</span></div>
          <div class="sb-sup sb-eq" style="width:100%"><span class="muted small" style="width:100%">How it got to the line:</span>
            <label class="chk" title="Skip stocks that crashed into the line: a fast drop or a gap down is usually news"><input type="checkbox" name="use_speed" ${p.use_speed ? "checked" : ""}> <b>Pullback speed:</b></label>
            <label class="inl">fell at most <input type="number" name="speed_max_drop" min="0" max="50" step="0.5" value="${p.speed_max_drop ?? 10}" style="width:62px">% in</label>
            <label class="inl"><input type="number" name="speed_days" min="2" max="30" step="1" value="${p.speed_days ?? 5}" style="width:52px">days, gap down at most</label>
            <label class="inl"><input type="number" name="speed_max_gap" min="0" max="30" step="0.5" value="${p.speed_max_gap ?? 0}" style="width:58px">%</label>
            <span class="eq-br"></span>
            <label class="chk" title="Skip stocks that fell much more than SPY: weakness of its own usually means a company problem"><input type="checkbox" name="use_rel" ${p.use_rel ? "checked" : ""}> <b>Weakness vs market:</b></label>
            <label class="inl">at most <input type="number" name="rel_max_spy" min="0" max="50" step="0.5" value="${p.rel_max_spy ?? 8}" style="width:58px">pts weaker than SPY</label>
            <label class="inl">and <input type="number" name="rel_max_sec" min="0" max="50" step="0.5" value="${p.rel_max_sec ?? 0}" style="width:58px">pts than its sector, over</label>
            <label class="inl"><input type="number" name="rel_days" min="5" max="120" step="1" value="${p.rel_days ?? 20}" style="width:56px">days</label>
            <span class="eq-br"></span>
            <label class="chk" title="The first pullback to the line after a run holds best; later touches are an aging trend"><input type="checkbox" name="use_touches" ${p.use_touches ? "checked" : ""}> <b>Touch number:</b></label>
            <label class="inl">only touch #1 to #<input type="number" name="touch_max" min="1" max="10" step="1" value="${p.touch_max ?? 2}" style="width:52px">of the last 12 months</label>
            <span class="eq-br"></span>
            <label class="chk" title="A flat slow line means the trend stalled; require it to be clearly rising"><input type="checkbox" name="use_slope" ${p.use_slope ? "checked" : ""}> <b>Slow-line slope:</b></label>
            <label class="inl">up at least <input type="number" name="slope_min" min="-20" max="50" step="0.5" value="${p.slope_min ?? 2}" style="width:58px">% over</label>
            <label class="inl"><input type="number" name="slope_days" min="5" max="250" step="5" value="${p.slope_days ?? 60}" style="width:58px">days</label>
            <span class="muted small">(0 = don't check that one, except slope: 0 = just rising)</span></div>
          <div class="sb-sup" style="width:100%"><label class="chk" title="Earnings report dates from FMP (needs your FMP key, even with Public prices). Days are trading days."><input type="checkbox" name="use_earn" ${p.use_earn ? "checked" : ""} ${d.fmp ? "" : "disabled"}> <b>Near earnings:</b></label>
            <label class="inl">skip if the next report is within <input type="number" name="earn_before" min="0" max="90" step="1" value="${p.earn_before ?? 10}" style="width:60px">trading days</label>
            <label class="inl">or the last one was within <input type="number" name="earn_after" min="0" max="60" step="1" value="${p.earn_after ?? 0}" style="width:60px">trading days</label>
            <span class="muted small">${d.fmp ? "(0 = don't check that one · dates from FMP)" : "(add your FMP key on Data sources to use this)"}</span></div>
          <div class="sb-sup" style="width:100%"><label class="chk" title="Skip stocks that already ran far above their slow line: the touch after a big run-up often keeps falling to the slow line"><input type="checkbox" name="use_ext" ${p.use_ext ? "checked" : ""}> <b>Not overextended:</b></label>
            <label class="inl">fast line at most <input type="number" name="ext_max_spread" min="0" max="200" step="1" value="${p.ext_max_spread ?? 10}" style="width:64px">% above the slow line</label>
            <label class="inl">and highest close at most <input type="number" name="ext_max_peak" min="0" max="500" step="5" value="${p.ext_max_peak ?? 0}" style="width:70px">% above the slow line</label>
            <label class="inl">in the last <input type="number" name="ext_days" min="5" max="252" step="5" value="${p.ext_days ?? 60}" style="width:64px">days</label>
            <label class="chk" title="Multiplies the stretch by the stock's beta first (clamped 0.5–3): a beta-2 stock gets half the room, a beta-0.5 stock twice the room, because high-beta stocks fall back harder"><input type="checkbox" name="ext_beta" ${p.ext_beta ? "checked" : ""}> scale by beta</label>
            <span class="muted small">(0 = don't check that one)</span></div>
          <div class="sb-sup" style="width:100%"><label class="chk" title="Beta vs SPY from the year before each alert: 1.0 moves with the market, 1.5 about 1.5× as much"><input type="checkbox" name="use_beta" ${p.use_beta ? "checked" : ""}> <b>Beta filter:</b></label>
            <label class="inl">beta at least <input type="number" name="beta_min" min="0" max="5" step="0.1" value="${p.beta_min ?? 0}" style="width:64px"></label>
            <label class="inl">and at most <input type="number" name="beta_max" min="0" max="5" step="0.1" value="${p.beta_max ?? 2}" style="width:64px"></label>
            <span class="muted small">(0 = no limit · 1.0 = moves with SPY)</span></div>
          <div class="sb-sup" style="width:100%"><span class="muted small">Compare with calls:</span>
            <label class="inl">Expiration <select name="opt_dte">${OPT_DTE.map(([k, l]) => `<option value="${k}" ${+((p.options || {}).dte || 126) === k ? "selected" : ""}>${l}</option>`).join("")}</select></label>
            <label class="inl">Strike <select name="opt_delta">${OPT_DELTA.map(([k, l]) => `<option value="${k}" ${+((p.options || {}).delta || 0.7) === k ? "selected" : ""}>delta ${l}</option>`).join("")}</select></label>
            <label class="inl" title="Implied vol = the stock's realized vol × this">IV × <input type="number" name="opt_iv" step="0.05" min="0.5" max="3" value="${(p.options || {}).iv_mult || 1.15}" style="width:70px"></label>
            <label class="inl" title="Bid/ask cost, round trip, as % of the premium">Spread <input type="number" name="opt_spread" step="0.5" min="0" max="30" value="${(p.options || {}).spread_pct ?? 4}" style="width:64px">%</label></div>
          <label title="Macro score from VIX, SPY trend and drawdown, breadth and credit, on each alert day">Macro<select name="macro_min">
            ${[["", "Any market"], ["-2", "Not risk-off (−2 or more)"], ["0", "Neutral or better (0+)"], ["3", "Risk-on only (+3 or more)"]].map(([k, l]) => `<option value="${k}" ${String(p.macro_min ?? "") === k ? "selected" : ""}>${l}</option>`).join("")}</select></label>
          <label title="The ETF each stock trades with (e.g. SMH for chip stocks): weakening vs SPY, 10-day outflow, overvalued">Theme rotation<select name="theme_max_risk">
            ${[["", "Ignore"], ["3", "Block if all 3 warnings"], ["2", "Block if 2+ warnings"], ["1", "Block on any warning"]].map(([k, l]) => `<option value="${k}" ${String(p.theme_max_risk ?? "") === k ? "selected" : ""}>${l}</option>`).join("")}</select></label>
          <div class="bt-btns"><button type="button" class="btn ghost" id="sbReset">Use my Investing settings</button><button class="btn primary">Run with these</button></div>
          ${(d.defaults && d.defaults.not_simulated && d.defaults.not_simulated.length) ? `<p class="muted small" style="width:100%">Not simulated (no history for them): ${esc(d.defaults.not_simulated.join(", "))}</p>` : ""}
        </form></details>
      <details class="card sb-slots" id="sbSlots" ${B.slotsOpen ? "open" : ""}><summary><b>Saved settings</b> <span class="muted small">10 slots · save these settings, load them back later, or use one in the daily scan</span></summary><div id="sbSlotsBody" class="loading">Loading…</div></details>
      <div id="sbOptBox"></div>
      <div id="sbInner"></div>`;
    bindGo(root);
    const form = $("#sbForm");
    const read = () => {
      const f = new FormData(form), o = {};
      ["fast", "slow", "tolerance", "above_days", "min_cap_b", "hold_days", "slots"].forEach((k) => (o[k] = +f.get(k)));
      ["hold", "new_only", "use_fcf", "use_rev", "use_eps"].forEach((k) => (o[k] = form[k].checked));
      o.ma_type = f.get("ma_type"); o.lines = f.get("lines");
      o.stop = stops.find((s) => stopKey(s) === f.get("stop")) || { type: "none" };
      o.take_profit = tps.find((s) => stopKey(s) === f.get("take_profit")) || { type: "none" };
      o.sector_filter = f.get("sector_filter") || "off";
      o.require = SUP_SIGNALS.map(([k]) => k).filter((k) => form["req_" + k].checked);
      o.use_debt = form.use_debt.checked; o.max_debt_mcap = +f.get("max_debt_mcap"); o.max_debt_rev = +f.get("max_debt_rev");
      o.debt_net = form.debt_net.checked; o.debt_skip_fin = form.debt_skip_fin.checked;
      o.max_debt_equity = +f.get("max_debt_equity"); o.debt_block_neg_equity = form.debt_block_neg_equity.checked;
      o.use_speed = form.use_speed.checked; o.speed_max_drop = +f.get("speed_max_drop"); o.speed_days = +f.get("speed_days") || 5; o.speed_max_gap = +f.get("speed_max_gap");
      o.use_rel = form.use_rel.checked; o.rel_max_spy = +f.get("rel_max_spy"); o.rel_max_sec = +f.get("rel_max_sec"); o.rel_days = +f.get("rel_days") || 20;
      o.use_touches = form.use_touches.checked; o.touch_max = +f.get("touch_max") || 2;
      o.use_slope = form.use_slope.checked; o.slope_min = +f.get("slope_min"); o.slope_days = +f.get("slope_days") || 60;
      o.use_earn = form.use_earn.checked; o.earn_before = +f.get("earn_before"); o.earn_after = +f.get("earn_after");
      o.use_ext = form.use_ext.checked; o.ext_max_spread = +f.get("ext_max_spread"); o.ext_max_peak = +f.get("ext_max_peak"); o.ext_days = +f.get("ext_days") || 60; o.ext_beta = form.ext_beta.checked;
      o.use_beta = form.use_beta.checked; o.beta_min = +f.get("beta_min"); o.beta_max = +f.get("beta_max");
      o.options = { dte: +f.get("opt_dte"), delta: +f.get("opt_delta"), iv_mult: +f.get("opt_iv"), spread_pct: +f.get("opt_spread") };
      o.macro_min = f.get("macro_min") === "" ? null : +f.get("macro_min");
      o.theme_max_risk = f.get("theme_max_risk") === "" ? null : +f.get("theme_max_risk");
      o.universe = $("#sbUni").value;
      o.data_source = $("#sbSrc").value; o.years = +$("#sbYears").value; o.period = $("#sbPeriod").value;
      o.exclude_years = (B.params && B.params.exclude_years) || [];
      return o;
    };
    const start = async (extra) => {
      B.params = Object.assign({}, B.params, read(), extra || {});
      const r = await call("start_strategy_bt", B.params, $("#sbRefresh").checked);
      if (!r.ok) return toast(r.error, true);
      pollSbt();
    };
    form.onsubmit = (e) => { e.preventDefault(); start(); };
    $("#sbRun").onclick = () => start();
    const fitYears = () => {                    // a 10/15/20-year period needs at least that much FMP data
      const need = { "10y": 10, "15y": 15, "20y": 20 }[$("#sbPeriod").value];
      if (!need) return;
      if ($("#sbSrc").value !== "fmp" && d.fmp) { $("#sbSrc").value = "fmp"; $("#sbYears").hidden = false; toast(`Switched prices to FMP: Public only has 5 years`); }
      if ($("#sbSrc").value === "fmp" && +$("#sbYears").value < need) { $("#sbYears").value = String(need === 15 ? 15 : need === 20 ? 20 : 10); }
      if ($("#sbSrc").value !== "fmp") toast(`Public only has 5 years of prices: add an FMP key on Data sources for ${need} years`, true);
    };
    $("#sbPeriod").onchange = fitYears;
    $("#sbSrc").onchange = () => { $("#sbYears").hidden = $("#sbSrc").value !== "fmp"; fitYears(); };
    $("#sbYears").onchange = () => { const need = { "10y": 10, "15y": 15, "20y": 20 }[$("#sbPeriod").value]; if (need && +$("#sbYears").value < need) toast(`${$("#sbYears").value} years of data is shorter than the ${need}-year period: it will test what's there`); };
    $("#sbReset").onclick = () => { B.params = Object.assign({}, d.defaults); renderStrategyBt(); };
    P.sbt.start = start;
    P.sbt.read = read;
    $("#sbSlots").ontoggle = () => { B.slotsOpen = $("#sbSlots").open; };
    drawSlots();
    $("#sbBest").onclick = async () => {
      B.params = Object.assign({}, B.params, read());
      const r = await call("start_optimize", B.params, $("#sbObj").value, 20);
      if (!r.ok) return toast(r.error, true);
      pollOpt();
    };
    if (!B.opt) call("get_optimize").then((r) => { B.opt = (r && r.result) || null; drawOpt(); });
    else drawOpt();
    drawSbtStatus(st);
    if (st.running) pollSbt();
    drawStrategyBt();
  }

  async function drawSlots() {
    const el = $("#sbSlotsBody"), B = P.sbt;
    if (!el) return;
    const r = await call("list_param_slots");
    if (!$("#sbSlotsBody")) return;
    const act = r.scan_slot || {};
    const pc = (v, colour = true) => (v == null ? "–" : `<span class="${colour ? cls(v) : ""}">${v > 0 ? "+" : ""}${fmt(v, 1)}%</span>`);
    el.className = "slot-grid";
    el.innerHTML = r.slots.map((x, i) => `<div class="slot ${x ? "" : "empty"} ${act.slot === i ? "in-scan" : ""}" data-i="${i}">
        <div class="slot-head"><span class="slot-n">${i + 1}</span><input class="slot-name" value="${esc(x ? x.name : "")}" placeholder="Name this slot" aria-label="Slot ${i + 1} name">
          ${act.slot === i ? `<span class="gx-pill s1" title="The daily scan is using these settings${act.edited ? " (edited since)" : ""}">in scan${act.edited ? "*" : ""}</span>` : ""}</div>
        ${x ? `<div class="muted small slot-desc">${esc(x.describe)}</div>
          ${x.summary ? `<div class="small slot-sum">${pc(x.summary.cagr)}/yr · drop ${pc(x.summary.maxdd, false)} · ${fmt(x.summary.trades || 0, 0)} trades <span class="muted">· SPY ${pc(x.summary.spy_cagr)} · QQQ ${pc(x.summary.qqq_cagr)}</span></div>` : `<div class="muted small">No results saved with it</div>`}
          <div class="muted small">saved ${esc(new Date(x.saved).toLocaleString([], { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" }))}</div>` : `<div class="muted small slot-desc">Empty</div>`}
        <div class="slot-btns">
          ${x ? `<button class="btn ghost small-btn" data-act="load">Load</button>` : ""}
          <button class="btn ghost small-btn" data-act="save">${x ? "Overwrite" : "Save here"}</button>
          ${x ? `<button class="btn ghost small-btn" data-act="scan" title="Copy its entry rules and filters into the Investing strategy for the daily scan">Use in scan</button><button class="btn ghost small-btn" data-act="clear" title="Empty this slot">✕</button>` : ""}
        </div></div>`).join("");
    $$(".slot", el).forEach((card) => {
      const i = +card.dataset.i, x = r.slots[i];
      $$("button[data-act]", card).forEach((b) => (b.onclick = async () => {
        const act_ = b.dataset.act, name = $(".slot-name", card).value.trim() || (x && x.name) || `Slot ${i + 1}`;
        if (act_ === "load") {
          B.params = Object.assign({}, B.params, x.params);
          toast(`Loaded slot ${i + 1}: ${x.name}`); renderStrategyBt();
        } else if (act_ === "save") {
          const cur = Object.assign({}, B.params, P.sbt.read ? P.sbt.read() : {});
          const res = B.data && B.data.result;
          const same = res && Object.keys(cur).every((k) => k === "not_simulated" || res.params[k] === undefined || JSON.stringify(res.params[k]) === JSON.stringify(cur[k]));
          const out = await call("save_param_slot", i, name, cur, !!same);
          if (!out.ok) return toast(out.error, true);
          toast(`Saved to slot ${i + 1}${same ? " with the last run's results" : " (run the test to save results with it)"}`); drawSlots();
        } else if (act_ === "scan") {
          const out = await call("load_slot_into_scan", i);
          if (!out.ok) return toast(out.error, true);
          toast(`Daily scan now uses slot ${i + 1}: ${out.name}`); if (typeof refresh === "function") refresh(); drawSlots();
        } else if (act_ === "clear") {
          await call("clear_param_slot", i); drawSlots();
        }
      }));
    });
  }

  function pollOpt() {
    clearInterval(P.sbt.optPoll);
    const box = () => $("#sbOptBox");
    P.sbt.optPoll = setInterval(async () => {
      const st = await call("optimize_status");
      if (box() && st.running) box().innerHTML = `<div class="card sb-note"><span class="spin">${ic("refresh", 14)}</span> ${esc(st.stage || "")} ${st.total ? `${st.done}/${st.total}` : ""} <span class="muted small">${esc(st.current || "")}</span> <button class="btn ghost small-btn" id="sbOptStop">Stop</button></div>`;
      const sb = $("#sbOptStop"); if (sb) sb.onclick = () => call("stop_optimize");
      if (!st.running) {
        clearInterval(P.sbt.optPoll);
        if (st.error) { toast(st.error, true); if (box()) box().innerHTML = ""; return; }
        const r = await call("get_optimize"); P.sbt.opt = r.result; toast("Best settings found"); drawOpt();
      }
    }, 1000);
  }

  function drawOpt() {
    const el = $("#sbOptBox"), o = P.sbt.opt;
    if (!el) return;
    if (!o) { el.innerHTML = ""; return; }
    const pc = (v, colour = true) => (v == null ? `<span class="muted">–</span>` : `<span class="${colour ? cls(v) : ""}">${v > 0 ? "+" : ""}${fmt(v, 1)}%</span>`);
    const W = o.windows, good = /^Held up/.test(o.verdict), part = /^Partly/.test(o.verdict);
    const row = (name, m, bh) => m ? `<td class="r num">${pc(m.cagr)}</td><td class="r num">${pc(m.maxdd, false)}</td>${bh ? "" : `<td class="r num muted">${fmt(m.taken, 0)}</td>`}` : `<td colspan="${bh ? 2 : 3}" class="muted">–</td>`;
    const wrow = (w, title) => { const x = W[w]; return `<tr><td style="white-space:nowrap"><b>${title}</b> <span class="muted small">${esc(x.start)} → ${esc(x.end)}</span></td>${row("b", x.best)}${row("y", x.yours)}${row("s", x.SPY, true)}${row("q", x.QQQ, true)}</tr>`; };
    const names = Object.keys(o.best_labels);
    el.innerHTML = `<div class="card sb-best-card"><h3>Best settings found <span class="muted small">${esc(o.objective_label)} · ${esc(o.period)}${(o.exclude_years || []).length ? " · leaving out " + esc(o.exclude_years.join(", ")) : ""} · ${o.evaluations} combinations tried · ${esc(new Date(o.finished).toLocaleString([], { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" }))}</span>
        <button class="btn ghost small-btn" id="sbOptHide" style="float:right">Hide</button></h3>
      <div class="opt-verdict ${good ? "pos" : part ? "" : "neg"}"><b>${esc(o.verdict)}</b></div>
      <div class="opt-stack">
        <div><h4 class="sb-sub">Settings</h4><div class="table-wrap"><table class="res gx-tbl"><thead><tr><th></th><th>Yours</th><th>Best found</th></tr></thead><tbody>
          ${names.map((n) => { const ch = o.best_labels[n] !== o.your_labels[n]; return `<tr class="${ch ? "best-row" : ""}"><td>${esc(n)}</td><td class="muted">${esc(o.your_labels[n])}</td><td>${ch ? "<b>" : ""}${esc(o.best_labels[n])}${ch ? "</b>" : ""}</td></tr>`; }).join("")}</tbody></table></div>
          <div class="bt-btns" style="margin-top:8px"><button class="btn primary" id="sbOptUse">Use these settings and run the full test</button></div></div>
        <div><h4 class="sb-sub">Yearly return · worst drop · trades</h4><div class="table-wrap"><table class="res gx-tbl"><thead><tr><th></th><th class="r" colspan="3">Best found</th><th class="r" colspan="3">Yours</th><th class="r" colspan="2">SPY</th><th class="r" colspan="2">QQQ</th></tr></thead><tbody>
          ${wrow("search", "Search (first 70%)")}${wrow("check", "Check (last 30%, unseen)")}${wrow("full", "Whole period")}</tbody></table></div>
          ${o.steps.length ? `<h4 class="sb-sub" style="margin-top:10px">What changed, in order</h4><ol class="small opt-steps">${o.steps.map((x) => `<li><b>${esc(x.setting)}</b>: ${esc(x.from)} → ${esc(x.to)} <span class="muted">(${pc(x.cagr_before)} → ${pc(x.cagr_after)}/yr in the search window)</span></li>`).join("")}</ol>` : `<p class="muted small">Your settings were already the best of everything tried.</p>`}</div></div>
      <p class="muted small">Only the <b>check window</b> is a fair test: the settings were picked using the search window, so they'll always look good there. Entry rules (EMA lengths, fundamentals) stay as you set them; each option needed at least ${o.min_trades} trades in the search window.</p></div>`;
    sbCollapsify(el);
    $("#sbOptHide").onclick = () => { P.sbt.opt = null; el.innerHTML = ""; };
    $("#sbOptUse").onclick = () => { if (P.sbt.start) { toast("Running the full test with the best settings"); P.sbt.start(o.params); } };
  }

  function drawSbtStatus(st) {
    const el = $("#sbStatus");
    if (!el) return;
    if (st && st.running) {
      const pc = st.total ? Math.round((st.done / st.total) * 100) : 0;
      el.innerHTML = `<span class="spin">${ic("refresh", 14)}</span> ${esc(st.stage || "")} ${st.total ? `${st.done}/${st.total} (${pc}%)` : ""} ${st.current ? `<span class="muted">· ${esc(st.current)}</span>` : ""} <button class="btn ghost small-btn" id="sbStop">Stop</button>`;
      $("#sbStop").onclick = () => call("stop_strategy_bt");
    } else if (st && st.error) el.innerHTML = `<span class="neg">${esc(st.error)}</span>`;
    else el.innerHTML = "";
  }

  function pollSbt() {
    clearInterval(P.sbt.poll);
    P.sbt.poll = setInterval(async () => {
      const st = await call("strategy_bt_status");
      if (S.page === "strategybt") drawSbtStatus(st);
      if (!st.running) {
        clearInterval(P.sbt.poll);
        P.sbt.data = await call("get_strategy_bt");
        P.sbt.search = null; P.sbt.wlSearch = null;
        if (st.error) toast(st.error, true); else if (st.stage === "Done") toast("Backtest finished");
        if (S.page === "strategybt") renderStrategyBt();
      }
    }, 1500);
  }

  function drawStrategyBt() {
    const B = P.sbt, el = $("#sbInner"), r = B.data && B.data.result;
    if (!el) return;
    if (!r) {
      el.innerHTML = `<div class="empty"><p><b>No backtest yet.</b></p><p class="muted">Pick <b>My watchlist only</b> for a quick first look, or <b>All stocks</b> for the real test (the first run downloads ~5 years of prices and SEC filings for every stock; later runs reuse them and finish in seconds).</p></div>`;
      return;
    }
    const pc = (v, colour = true) => (v == null ? `<span class="muted">–</span>` : `<span class="${colour ? cls(v) : ""}">${v > 0 ? "+" : ""}${fmt(v, 1)}%</span>`);
    const hz = r.horizons, y1 = hz["252"] || {}, s = r.stats, pf = r.portfolio, bm = r.benchmarks;
    const PB = (r.beta && r.beta.portfolio) || {};
    const betaCells = (x) => x ? `<td class="r num"><b>${fmt(x.beta, 2)}</b></td><td class="r num">${x.corr == null ? "–" : fmt(x.corr, 2)}</td><td class="r num">${pc(x.alpha)}</td>` : `<td class="r num muted">–</td><td class="r num muted">–</td><td class="r num muted">–</td>`;
    const years = Math.max(0.5, r.info.days / 252);
    const ds_ = r.data_source || { label: "Public.com", years: 5 };
    let html = `<div class="sb-foldbar"><button class="btn ghost small-btn" id="sbFoldAll">▸ Hide all sections</button><button class="btn ghost small-btn" id="sbUnfoldAll">▾ Show all sections</button><span class="muted small">or click any section's title to hide / show it</span></div>
      <div class="muted small" style="margin-bottom:10px">Tested ${fmt(r.universe, 0)} stocks (${r.mode === "watchlist" ? "watchlist" : "all stocks"}) from ${esc(r.info.first_day)} to ${esc(r.info.last_day)}
      · ${esc(r.info.period || "All the data")}${(r.info.exclude_years || []).length ? ` · leaving out ${esc(r.info.exclude_years.join(", "))}` : ""} · prices from ${esc(ds_.label)}${ds_.source === "fmp" ? ` (${ds_.years} years)` : ""} · data from ${esc(String(r.dataset_built).slice(0, 10))} · finished ${new Date(r.finished).toLocaleString([], { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })}</div>
      <div class="gx-cards">
        <div class="gx-card"><span>Alerts found</span><b class="num">${fmt(r.alerts_total, 0)}</b><small>on ${fmt(r.alert_days_total, 0)} days · ~${fmt(r.alerts_total / years, 0)} a year</small></div>
        <div class="gx-card"><span>Up after 1 year</span><b class="num">${y1.win == null ? "–" : fmt(y1.win, 0) + "%"}</b><small>${y1.n || 0} alerts with a full year</small></div>
        <div class="gx-card"><span>Avg 1-year return</span><b class="num">${pc(y1.avg)}</b><small>median ${pc(y1.median)}</small></div>
        <div class="gx-card"><span>Avg 1 year vs SPY / QQQ / RSP</span><b class="num">${pc(y1.vs_SPY)}</b><small>QQQ ${pc(y1.vs_QQQ)} · RSP ${pc(y1.vs_RSP)}</small></div>
        <div class="gx-card"><span>Portfolio (${esc(r.stop.label)}${r.take_profit && r.take_profit.type !== "none" ? " · TP " + esc(r.take_profit.label) : ""})</span><b class="num">${pf.cagr == null ? "–" : fmt(pf.cagr, 1) + "%/yr"}</b><small>max drop ${pc(pf.maxdd, false)} · $10k → $${fmt(pf.final, 0)}</small></div>
        ${PB.Strategy ? `<div class="gx-card"><span>Strategy beta vs SPY</span><b class="num">${fmt(PB.Strategy.beta, 2)}</b><small>${esc(betaWord(PB.Strategy.beta))} · alpha ${pc(PB.Strategy.alpha)}/yr${r.beta.avg_alert_beta != null ? ` · stocks avg ${fmt(r.beta.avg_alert_beta, 2)}` : ""}</small></div>` : ""}
        <div class="gx-card"><span>Buy &amp; hold SPY / QQQ / RSP</span><b class="num">${bm.SPY ? fmt(bm.SPY.cagr, 1) + "%/yr" : "–"}</b><small>QQQ ${bm.QQQ ? fmt(bm.QQQ.cagr, 1) + "%" : "–"} · RSP ${bm.RSP ? fmt(bm.RSP.cagr, 1) + "%" : "–"}/yr</small></div>
      </div>`;
    if (s.open && s.n != null && s.open > s.n) html += `<div class="sb-note card"><b>Most trades are still open</b> <span class="muted">— ${fmt(s.open, 0)} open vs ${fmt(s.n, 0)} finished in this period, because trades are held up to ${r.params.hold_days} trading days. Win rate and averages only count finished trades; for short periods, lower <b>Hold up to</b> (e.g. 21 or 63 days).</span></div>`;
    const sec = r.sector;
    if (sec && sec.filter !== "off") html += `<div class="sb-note card"><b>Sector filter: ${esc(sec.label)}</b> <span class="muted">— kept ${fmt(sec.alerts_kept, 0)} of ${fmt(sec.alerts_all, 0)} alerts, judged by ${sec.kind === "valuation" ? "the sector's valuation score" : "where the sector ETF sat vs SPY"} on each alert day. Every number on this page uses the filtered alerts.</span></div>`;
    // horizons
    html += `<div class="card"><h3>Every alert, held a fixed time <span class="muted small">no stop · close to close · compared with buying each benchmark the same day</span></h3>
      <div class="table-wrap"><table class="res gx-tbl"><thead><tr><th>Held</th><th class="r">Alerts</th><th class="r">Up</th><th class="r">Average</th><th class="r">Median</th><th class="r">vs SPY</th><th class="r">vs QQQ</th><th class="r">vs RSP</th><th class="r">Beat SPY</th><th class="r">Beat RSP</th></tr></thead>
      <tbody>${[["5", "1 week"], ["21", "1 month"], ["63", "3 months"], ["126", "6 months"], ["252", "1 year"]].map(([k, l]) => { const h = hz[k] || {}; return `<tr><td>${l}</td><td class="r num">${fmt(h.n, 0)}</td><td class="r num">${h.win == null ? "–" : fmt(h.win, 0) + "%"}</td>
        <td class="r num">${pc(h.avg)}</td><td class="r num">${pc(h.median)}</td><td class="r num">${pc(h.vs_SPY)}</td><td class="r num">${pc(h.vs_QQQ)}</td><td class="r num">${pc(h.vs_RSP)}</td>
        <td class="r num">${h.beat_SPY == null ? "–" : fmt(h.beat_SPY, 0) + "%"}</td><td class="r num">${h.beat_RSP == null ? "–" : fmt(h.beat_RSP, 0) + "%"}</td></tr>`; }).join("")}</tbody></table></div>
      <p class="muted small">"vs SPY" = the alert's return minus SPY's return over exactly the same days. Positive = the alert beat simply buying SPY that day.</p></div>`;
    // equity curve
    const YR = r.yearly || {}, yrKeys = Object.keys(YR).sort();
    const yrSel = B.curveYear && YR[B.curveYear] ? B.curveYear : null;
    const yrStrip = yrKeys.length ? `<div class="yr-strip" role="tablist" aria-label="Show one year">
        <button class="yr-tab ${yrSel ? "" : "on"}" data-cy=""><b>All years</b><small>${pc(pf.total)}</small><small class="muted">${esc(String(r.info.first_day).slice(0, 4))}–${esc(String(r.info.last_day).slice(0, 4))}</small></button>
        ${yrKeys.map((y) => { const st_ = YR[y].stats || {}, sv = st_.Strategy || {}, sp = st_.SPY || {}; const d_ = sv.ret != null && sp.ret != null ? sv.ret - sp.ret : null;
          return `<button class="yr-tab ${yrSel === y ? "on" : ""}" data-cy="${y}" title="Start every line at $10,000 on the last close of ${+y - 1} and show ${y} only"><b>${y}${YR[y].partial ? "<sup>*</sup>" : ""}</b><small>${pc(sv.ret)}</small><small class="muted">SPY ${pc(sp.ret, false)}</small>${d_ == null ? "" : `<i class="yr-bar ${d_ >= 0 ? "pos-bg" : "neg-bg"}" style="width:${Math.min(100, Math.abs(d_) * 3)}%"></i>`}</button>`; }).join("")}
      </div>` : "";
    let yrTable = "";
    if (yrSel) {
      const Y = YR[yrSel], ST = Y.stats || {}, spr = (ST.SPY || {}).ret, tr = Y.trades;
      const row = (k, label, sub) => ST[k] ? `<tr><td><span class="cmp-dot" style="background:${(SB_LINES.find((x) => x[0] === k) || [0, "var(--muted)"])[1]}"></span>${k === "Strategy" ? "<b>" + label + "</b>" : label} <span class="muted small">${esc(sub || "")}</span></td><td class="r num">${pc(ST[k].ret)}</td><td class="r num">${pc(ST[k].maxdd, false)}</td><td class="r num">$${fmt(ST[k].final, 0)}</td><td class="r num">${k === "SPY" || spr == null || ST[k].ret == null ? "–" : pc(ST[k].ret - spr)}</td></tr>` : "";
      yrTable = `<div class="table-wrap"><table class="res gx-tbl"><thead><tr><th>${yrSel}${Y.partial ? ` <span class="muted small">(${esc(Y.from)} → ${esc(Y.to)})</span>` : ""}</th><th class="r">Return in ${yrSel}</th><th class="r">Worst drop in ${yrSel}</th><th class="r">$10k became</th><th class="r">vs SPY</th></tr></thead><tbody>
        ${row("Strategy", "Strategy", r.stop.label)}${row("Calls", "Calls", "modeled")}${row("No filters", "No filters", "")}${row("All sectors", "All sectors", "")}${row("SPY", "SPY", "S&P 500")}${row("QQQ", "QQQ", "Nasdaq 100")}${row("RSP", "RSP", "S&P 500 equal weight")}</tbody></table></div>
        ${tr ? `<p class="small" style="margin:8px 0 0">Trades that <b>started</b> in ${yrSel}: <b>${fmt(tr.n || 0, 0)}</b> finished${tr.open ? ` + ${fmt(tr.open, 0)} open` : ""} · win ${tr.win == null ? "–" : fmt(tr.win, 0) + "%"} · avg ${pc(tr.avg)} · vs SPY ${pc(tr.vs_SPY)} <span class="muted">(each held up to ${r.params.hold_days} days, so some ran into the next year)</span></p>` : ""}
        <p class="muted small">Every line restarts at $10,000 on the last close before ${yrSel}, so this is ${yrSel}'s performance alone. The strategy starts the year holding whatever positions it already had.${Y.partial ? " <sup>*</sup>Partial year." : ""}</p>`;
    }
    const allTable = `      <div class="table-wrap"><table class="res gx-tbl"><thead><tr><th></th><th class="r">Total</th><th class="r">Per year</th><th class="r">Worst drop</th><th class="r">$10k became</th><th class="r" title="How much it moved when SPY moved, day to day (1.0 = like SPY)">Beta</th><th class="r" title="How closely its daily moves followed SPY (1 = in lockstep)">Correlation</th><th class="r" title="Yearly return not explained by SPY's moves × beta">Alpha /yr</th></tr></thead><tbody>
        <tr><td><span class="cmp-dot" style="background:var(--text)"></span><b>Strategy</b> <span class="muted small">${esc(r.stop.label)}</span></td><td class="r num">${pc(pf.total)}</td><td class="r num">${pc(pf.cagr)}</td><td class="r num">${pc(pf.maxdd, false)}</td><td class="r num">$${fmt(pf.final, 0)}</td>${betaCells(PB.Strategy)}</tr>
        ${r.options && PB.Calls ? `<tr><td><span class="cmp-dot" style="background:${(SB_LINES.find((x) => x[0] === "Calls") || [0, "#A77BFF"])[1]}"></span>Calls <span class="muted small">modeled</span></td><td class="r num">${pc(r.options.portfolio.total)}</td><td class="r num">${pc(r.options.portfolio.cagr)}</td><td class="r num">${pc(r.options.portfolio.maxdd, false)}</td><td class="r num">$${fmt(r.options.portfolio.final, 0)}</td>${betaCells(PB.Calls)}</tr>` : ""}
        ${["SPY", "QQQ", "RSP"].filter((b) => bm[b]).map((b) => `<tr><td><span class="cmp-dot" style="background:${SB_LINES.find((x) => x[0] === b)[1]}"></span>${b} <span class="muted small">${esc(bm[b].name)}</span></td><td class="r num">${pc(bm[b].total)}</td><td class="r num">${pc(bm[b].cagr)}</td><td class="r num">${pc(bm[b].maxdd, false)}</td><td class="r num">$${fmt(bm[b].final, 0)}</td>${betaCells(PB[b])}</tr>`).join("")}
      </tbody></table></div>
`;
    const cvShow = yrSel ? Object.assign({ t: YR[yrSel].t, month: true }, YR[yrSel].lines) : r.curves;
    html += `<div class="card"><h3>$10,000 portfolio vs buy &amp; hold${yrSel ? ` <span class="yr-badge">${yrSel} only</span>` : ""} <span class="muted small">${pf.taken} trades taken, ${pf.skipped} skipped (all ${r.params.slots} slots full) · ${fmt(pf.exposure, 0)}% of days invested</span></h3>
      <div class="sb-lines">${SB_LINES.filter(([k]) => r.curves[k]).map(([k, col]) => `<button class="sb-line ${B.hidden[k] ? "off" : ""}" data-line="${esc(k)}"><i style="background:${col}"></i>${esc(k)}</button>`).join("")}<span class="muted small">click to hide / show a line</span></div>
      <div class="sb-years"><span class="muted small" title="Cuts those years out of every line (your strategy, calls, SPY, QQQ, RSP) and every number on this page, as if they never happened. No new trades start in them either.">Leave out years:</span>
        ${(r.info.years_available || []).map((y) => { const off = (r.info.exclude_years || []).map(Number).includes(+y); return `<button class="chip-btn ${off ? "chip-off" : ""}" data-exyr="${y}" title="${off ? "Put " + y + " back" : "Leave " + y + " out of everything"}">${off ? "✕ " : ""}${y}</button>`; }).join("")}
        ${(r.info.exclude_years || []).length ? `<span class="muted small">left out of every line and number: ${esc(r.info.exclude_years.join(", "))}</span>` : `<span class="muted small">click a year to cut it out of every line</span>`}</div>
      ${sbCurve(cvShow, B.hidden)}
      ${yrStrip}
      ${yrSel ? yrTable : allTable}
      <p class="muted small">Each new alert gets 1/${r.params.slots} of the account if a slot is free (biggest companies first when several alert the same day). Exits at the stop or after ${r.params.hold_days} trading days. No fees, slippage or dividends.</p></div>`;
    // which filters help?
    const FR = r.filter_report;
    if (FR && FR.rows && FR.rows.length) {
      const dd = (v, d, u = "") => (v == null ? `<span class="muted">–</span>` : `<span class="${v > 0.0001 ? "pos" : v < -0.0001 ? "neg" : "muted"}">${v > 0 ? "+" : ""}${fmt(v, d)}${u}</span>`);
      const can = (x) => /^(use_|require:)/.test(x.key || "");
      html += `<div class="card" data-sec="filter-report"><h3>Which filters help? <span class="muted small">each filter on its own at the numbers in your rules (or a default if it's off), vs taking every alert · ${esc(r.stop.label.toLowerCase())}</span></h3>
        <div class="table-wrap"><table class="res gx-tbl fr-tbl"><thead><tr><th>Filter</th><th>Setting</th><th class="r">Trades kept</th><th class="r">Win</th><th class="r">Win change</th><th class="r">Avg trade</th><th class="r">Avg change</th><th class="r">Profit factor</th><th class="r">PF change</th><th class="r" title="Years where the kept trades won more often than all trades (years with 5+ kept trades)">Years it helped</th><th></th></tr></thead><tbody>
          <tr class="fr-base"><td><b>Every alert</b></td><td class="muted small">no filters</td><td class="r num">${fmt(FR.base.n || 0, 0)}</td><td class="r num">${FR.base.win == null ? "–" : fmt(FR.base.win, 0) + "%"}</td><td></td><td class="r num">${pc(FR.base.avg)}</td><td></td><td class="r num">${FR.base.pf == null ? "–" : fmt(FR.base.pf, 2)}</td><td></td><td></td><td></td></tr>
          ${FR.rows.map((x) => { const ok_ = (x.d_win || 0) > 0 && (x.d_pf || 0) > 0 && x.kept >= 60 && x.years && x.years_helped / x.years >= 0.6;
            return `<tr class="${ok_ ? "best-row" : ""}"><td>${esc(x.name)}${x.on ? ' <span class="gx-pill s1">on</span>' : ""}</td><td class="muted small">${esc(x.setting)}</td>
            <td class="r num">${fmt(x.kept, 0)} <span class="muted small">${fmt(x.kept_pct, 0)}%</span></td><td class="r num">${x.win == null ? "–" : fmt(x.win, 0) + "%"}</td><td class="r num">${dd(x.d_win, 1, " pts")}</td>
            <td class="r num">${pc(x.avg)}</td><td class="r num">${dd(x.d_avg, 2, "%")}</td><td class="r num">${x.pf == null ? "–" : fmt(x.pf, 2)}</td><td class="r num">${dd(x.d_pf, 2)}</td>
            <td class="r num">${x.years ? `${x.years_helped}/${x.years}` : "–"}</td>
            <td>${can(x) && !x.on ? `<button class="btn ghost small-btn" data-fr="${esc(x.key)}">Turn on</button>` : ""}</td></tr>`; }).join("")}</tbody></table></div>
        <p class="muted small">Highlighted = raises both win rate and profit factor, keeps 60+ trades and helped in most years: the ones most likely to be real. A filter that only helps in one year, or keeps very few trades, is probably luck. Filters overlap, so two good ones together add less than their sum: <b>Find best settings</b> checks combinations on data it never saw.</p></div>`;
    }
    // entry quality buckets
    const Q = r.quality;
    if (Q && (Q.drop.length || Q.rel.length || Q.touch.length || Q.slope.length)) {
      const qrow = (x) => `<tr><td>${esc(x.name)}</td><td class="r num">${fmt(x.n, 0)}${x.open ? `<span class="muted small"> +${x.open} open</span>` : ""}</td><td class="r num">${x.win == null ? "–" : fmt(x.win, 0) + "%"}</td><td class="r num">${pc(x.avg)}</td><td class="r num">${pc(x.vs_SPY)}</td><td class="r num">${x.stopped == null ? "–" : fmt(x.stopped, 0) + "%"}</td><td class="r num">${x.pf == null ? "–" : fmt(x.pf, 2)}</td></tr>`;
      const qtab = (title, first, rows_) => rows_.length ? `<div><h4 class="sb-sub">${title}</h4><div class="table-wrap"><table class="res gx-tbl"><thead><tr><th>${first}</th><th class="r">Trades</th><th class="r">Win</th><th class="r">Avg trade</th><th class="r">vs SPY</th><th class="r">Stopped</th><th class="r">Profit factor</th></tr></thead><tbody>${rows_.map(qrow).join("")}</tbody></table></div></div>` : "<div></div>";
      html += `<div class="card" data-sec="entry-quality"><h3>How did it get to the line? <span class="muted small">every alert (filters or not), on the alert day · ${esc(r.stop.label.toLowerCase())}</span></h3>
        <div class="two">${qtab(`Pullback speed: drop from the high close of the last ${Q.days.speed} days`, "Fell", Q.drop)}${qtab(`Weakness vs SPY over ${Q.days.rel} days`, "Stock vs SPY", Q.rel)}</div>
        <div class="two">${qtab("Which touch of the line in the last 12 months", "Touch", Q.touch)}${qtab(`Slow-line slope over ${Q.days.slope} days`, "Slow line", Q.slope)}</div>
        <p class="muted small">Look for rows that clearly win less or get stopped more, backed by enough trades, then set the matching filter in the rules just past where results fall off.</p></div>`;
    }
    // alert calendar (filled in by drawCalendar)
    html += `<div class="card" data-sec="alert-calendar"><h3>Alert calendar <span class="muted small">every alert on the day it fired · colour = how that day's trades ended · ${esc(r.stop.label.toLowerCase())}${r.take_profit && r.take_profit.type !== "none" ? " · TP " + esc(r.take_profit.label) : ""}</span></h3>
      <div id="sbCalBody"><div class="loading">${ic("refresh", 16)} Loading the calendar…</div></div></div>`;
    // best winners / worst losers
    const WS = B.wlSearch, ex = WS ? WS.res : r.extremes;
    if (ex && (WS || ex.winners.length || ex.losers.length)) {
      const wm = B.wlMode || "ret", wn = B.wlShown || 15, wOpen = B.wlOpen !== false;
      const pick = (k) => (ex[wm === "spy" ? k + "_spy" : k] || []).filter((x) => wOpen || x.reason !== "open").slice(0, wn);
      const W_ = pick("winners"), L_ = pick("losers");
      const dstr = (d_) => esc(parseDay(d_).toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" }));
      const why = (x) => (x.reason === "stop" ? "stop" : x.reason === "target" ? "target" : x.reason === "open" ? "open" : x.reason === "expired" ? "expired" : "time");
      const wlTable = (rows_, side) => `<div class="wl-col wl-${side}"><h4 class="sb-sub">${side === "win" ? "🏆 Best winners" : "💥 Worst losers"} <span class="muted small">${side === "win" ? fmt(ex.n_win, 0) + (ex.n_win === 1 ? " winner" : " winners") : fmt(ex.n_lose, 0) + (ex.n_lose === 1 ? " loser" : " losers")} in total</span></h4>
        ${rows_.length ? `<div class="table-wrap"><table class="res gx-tbl wl-tbl"><thead><tr><th class="r">#</th><th>Ticker</th><th>Alerted</th><th class="r">Gain / loss</th><th class="r" title="SPY over the same days">SPY</th><th class="r">vs SPY</th><th>Exit · days</th></tr></thead><tbody>
          ${rows_.map((x, i) => `<tr title="${esc(x.ticker)}: bought $${fmt(x.entry)} on ${dstr(x.date)}, out $${fmt(x.exit)} on ${dstr(x.exit_date)} (${why(x)})"><td class="r muted num">${i + 1}</td><td class="nw"><button class="rot-chip" data-t="${esc(x.ticker)}">${esc(x.ticker)}</button>${x.sector ? `<div class="muted small wl-sec">${esc(x.sector)}</div>` : ""}</td>
            <td class="num nw">${dstr(x.date)}</td>
            <td class="r num wl-ret"><b>${pc(x.ret)}</b></td><td class="r num">${pc(x.spy)}</td><td class="r num"><b>${pc(x.vs_SPY)}</b></td>
            <td class="muted small nw">${why(x)} · ${fmt(x.days, 0)}d</td></tr>`).join("")}</tbody></table></div>`
          : `<p class="muted">None${wOpen ? "" : " finished"}.</p>`}</div>`;
      html += `<div class="card" data-sec="winlose"><h3>Best winners &amp; worst losers <span class="muted small">every trade with ${esc(r.stop.label.toLowerCase())} · ${fmt(ex.beat_spy, 0)} of ${fmt(ex.n, 0)} beat SPY over the same days · click a ticker for its chart</span></h3>
        <div class="wl-ctl"><span class="seg"><button class="${wm === "ret" ? "on" : ""}" data-wm="ret">Rank by gain / loss</button><button class="${wm === "spy" ? "on" : ""}" data-wm="spy">Rank by vs SPY</button></span>
          <label class="muted small sb-chk"><input type="checkbox" id="wlOpen" ${wOpen ? "checked" : ""}> Include still-open trades${ex.n_open ? ` (${fmt(ex.n_open, 0)})` : ""}</label></div>
        <form class="sb-search wl-search" id="wlSearch">
          <input type="text" name="tk" placeholder="TICKER" value="${esc((WS && WS.tk) || "")}" aria-label="Ticker" style="width:110px;text-transform:uppercase">
          <span class="muted small">alerted from</span><input type="date" name="frm" min="${esc(r.info.first_day)}" max="${esc(r.info.last_day)}" value="${esc((WS && WS.frm) || "")}" aria-label="From date">
          <span class="muted small">to</span><input type="date" name="to" min="${esc(r.info.first_day)}" max="${esc(r.info.last_day)}" value="${esc((WS && WS.to) || "")}" aria-label="To date">
          <button class="btn primary small-btn">${ic("search", 14)} Search</button>
          ${WS ? `<button type="button" class="btn ghost small-btn" id="wlClear">Clear</button>` : ""}
          <span class="sb-quick">${(r.info.years_available || []).map((y) => `<button type="button" class="chip-btn" data-wlyr="${y}">${y}</button>`).join("")}</span>
        </form>
        ${WS ? `<div class="sb-search-sum"><b>${fmt(ex.n, 0)} trades</b>${WS.tk ? ` in <b>${esc(WS.tk)}</b>` : ""}${WS.frm || WS.to ? ` alerted ${esc(srRange(WS, r.info.first_day, r.info.last_day))}` : ""}
          <span class="sep">|</span> ${fmt(ex.n_win, 0)} winner${ex.n_win === 1 ? "" : "s"} · ${fmt(ex.n_lose, 0)} loser${ex.n_lose === 1 ? "" : "s"} <span class="sep">|</span> ${fmt(ex.beat_spy, 0)} beat SPY${ex.n_open ? ` <span class="sep">|</span> ${fmt(ex.n_open, 0)} still open` : ""}
          ${WS.partial ? `<div class="muted small">Searching only the newest 400 alert days: run the test once on this version to search all of them.</div>` : ""}</div>` : ""}
        <div class="wl-grid">${wlTable(W_, "win")}${wlTable(L_, "lose")}</div>
        ${wn < 100 && ((ex.winners.length > wn) || (ex.losers.length > wn)) ? `<button class="btn ghost more" id="wlMore">Show 15 more</button>` : ""}
        <p class="muted small">"SPY" = what SPY did from the alert's close to the exit; "vs SPY" = the trade minus that. Hover a row for its entry and exit prices. Shows up to 100 on each side.</p></div>`;
    }
    if (!ex) html += `<div class="card" data-sec="winlose"><h3>Best winners &amp; worst losers</h3><p class="muted">This result was saved by an older version. Press <b>Run backtest</b> once (it reuses the downloaded data, so it only takes seconds) to see the best and worst trades here.</p></div>`;
    // sector rotation breakdown
    if (sec && sec.by_quadrant && sec.by_quadrant.length) {
      const u = sec.unfiltered;
      const qcls = (q) => ({ undervalued: "q-leading", overvalued: "q-lagging", "fair value": "q-unknown" }[q.toLowerCase()] || "q-" + q.toLowerCase());
      const grpTable = (title, rows_) => `<div><h4 class="sb-sub">${title}</h4><div class="table-wrap"><table class="res gx-tbl"><thead><tr><th>Sector was</th><th class="r">Alerts</th><th class="r">Up after 1 yr</th><th class="r">Avg 1 yr</th><th class="r">Trade win</th><th class="r">Avg trade</th><th class="r">vs SPY</th><th class="r">Profit factor</th></tr></thead><tbody>
        ${rows_.map((q) => `<tr><td><span class="q-tag ${qcls(q.quadrant)}">${esc(q.quadrant)}</span></td><td class="r num">${fmt(q.alerts, 0)}</td>
          <td class="r num">${q.y1_win == null ? "–" : fmt(q.y1_win, 0) + "%"}</td><td class="r num">${pc(q.y1_avg)}</td><td class="r num">${q.win == null ? "–" : fmt(q.win, 0) + "%"}</td>
          <td class="r num">${pc(q.avg)}</td><td class="r num">${pc(q.vs_SPY)}</td><td class="r num">${q.pf == null ? "–" : fmt(q.pf, 2)}</td></tr>`).join("")}</tbody></table></div></div>`;
      html += `<div class="card"><h3>By sector on the alert day <span class="muted small">every alert (filter or not), grouped by its sector's reading that day · ${esc(r.stop.label.toLowerCase())}</span></h3>
        <div class="two">${grpTable("Rotation (sector ETF vs SPY)", sec.by_quadrant)}${sec.by_value && sec.by_value.length ? grpTable("Valuation (sector score)", sec.by_value) : ""}</div>
        ${u ? `<div class="table-wrap"><table class="res gx-tbl"><thead><tr><th></th><th class="r">Trades</th><th class="r">Win</th><th class="r">Avg trade</th><th class="r">vs SPY</th><th class="r">Portfolio /yr</th><th class="r">Worst drop</th><th class="r">Return ÷ drop</th></tr></thead><tbody>
          <tr class="best-row"><td><b>${esc(sec.label)}</b></td><td class="r num">${fmt(s.n, 0)}</td><td class="r num">${s.win == null ? "–" : fmt(s.win, 0) + "%"}</td><td class="r num">${pc(s.avg)}</td><td class="r num">${pc(s.vs_SPY)}</td><td class="r num">${pc(pf.cagr)}</td><td class="r num">${pc(pf.maxdd, false)}</td><td class="r num">${pf.calmar == null ? "–" : fmt(pf.calmar, 2)}</td></tr>
          <tr><td>All sectors (no filter)</td><td class="r num">${fmt(u.stats.n, 0)}</td><td class="r num">${u.stats.win == null ? "–" : fmt(u.stats.win, 0) + "%"}</td><td class="r num">${pc(u.stats.avg)}</td><td class="r num">${pc(u.stats.vs_SPY)}</td><td class="r num">${pc(u.portfolio.cagr)}</td><td class="r num">${pc(u.portfolio.maxdd, false)}</td><td class="r num">${u.portfolio.calmar == null ? "–" : fmt(u.portfolio.calmar, 2)}</td></tr>
          </tbody></table></div>` : `<p class="muted small">Pick a <b>Sector rotation</b> filter above to compare it with taking every alert.</p>`}
        <p class="muted small">Sector = the company's SEC industry code mapped to a sector ETF (XLK, XLF, XLE…). Both readings use only prices up to the alert day.
          The valuation here uses the score's price checks (sector vs SPY, and stretch above its 200-day average, each vs its own past); the live score on the Rotation page also adds P/E, P/S and FCF yield once its history is built. "Unknown" = no sector ETF, or not enough history yet.</p></div>`;
    }
    // support / macro / theme
    const su = r.support;
    if (su && (su.signals.length || su.by_macro.length)) {
      const hr = (x) => (x.held_rate == null ? "–" : fmt(x.held_rate, 0) + "%");
      const edge = (e) => (e == null ? `<span class="muted">–</span>` : `<span class="${e >= 5 ? "pos" : e <= -5 ? "neg" : "muted"}">${e > 0 ? "+" : ""}${fmt(e, 0)} pts</span>`);
      const gtab = (title, rows_) => `<div><h4 class="sb-sub">${title}</h4><div class="table-wrap"><table class="res gx-tbl"><thead><tr><th></th><th class="r">Alerts</th><th class="r">Line held</th><th class="r">Avg trade</th><th class="r">Win</th><th class="r">Avg 1 yr</th></tr></thead><tbody>
        ${rows_.map((x) => `<tr><td>${esc(x.name)}</td><td class="r num">${fmt(x.n, 0)}</td><td class="r num">${hr(x)}</td><td class="r num">${pc(x.avg)}</td><td class="r num">${x.win == null ? "–" : fmt(x.win, 0) + "%"}</td><td class="r num">${pc(x.y1_avg)}</td></tr>`).join("")}</tbody></table></div></div>`;
      html += `<div class="card"><h3>Is anyone defending the line? <span class="muted small">every alert, grouped by what was true on the alert day · "held" = no close more than 2% below the line in the next 10 trading days</span></h3>
        ${su.signals.length ? `<div class="table-wrap"><table class="res gx-tbl"><thead><tr><th>Signal on the alert day</th><th class="r">Held when ON</th><th class="r">Held when OFF</th><th class="r">Difference</th><th class="r">Avg trade ON</th><th class="r">Avg trade OFF</th><th class="r">Avg 1 yr ON</th><th class="r">Avg 1 yr OFF</th></tr></thead><tbody>
          ${su.signals.slice().sort((a, b) => (b.edge ?? -99) - (a.edge ?? -99)).map((x) => `<tr><td>${esc(x.label)}</td><td class="r num">${hr(x.with)} <span class="muted small">${x.with.held_n}</span></td><td class="r num">${hr(x.without)} <span class="muted small">${x.without.held_n}</span></td>
            <td class="r num">${edge(x.edge)}</td><td class="r num">${pc(x.with.avg)}</td><td class="r num">${pc(x.without.avg)}</td><td class="r num">${pc(x.with.y1_avg)}</td><td class="r num">${pc(x.without.y1_avg)}</td></tr>`).join("")}</tbody></table></div>`
          : `<p class="muted">Support signals need volume data: tick <b>Re-download data</b> and run again.</p>`}
        <div class="two">${su.by_macro.length ? gtab("Macro on the alert day", su.by_macro) : ""}${su.by_theme.length ? gtab("Theme rotation warnings on the alert day", su.by_theme) : ""}</div>
        ${su.unfiltered ? `<div class="table-wrap"><table class="res gx-tbl"><thead><tr><th></th><th class="r">Trades</th><th class="r">Win</th><th class="r">Avg trade</th><th class="r">vs SPY</th><th class="r">Portfolio /yr</th><th class="r">Worst drop</th><th class="r">Return ÷ drop</th></tr></thead><tbody>
          <tr class="best-row"><td><b>With your filters</b> <span class="muted small">${fmt(su.alerts_kept, 0)} of ${fmt(su.alerts_all, 0)} alerts</span></td><td class="r num">${fmt(s.n, 0)}</td><td class="r num">${s.win == null ? "–" : fmt(s.win, 0) + "%"}</td><td class="r num">${pc(s.avg)}</td><td class="r num">${pc(s.vs_SPY)}</td><td class="r num">${pc(pf.cagr)}</td><td class="r num">${pc(pf.maxdd, false)}</td><td class="r num">${pf.calmar == null ? "–" : fmt(pf.calmar, 2)}</td></tr>
          <tr><td>No filters</td><td class="r num">${fmt(su.unfiltered.stats.n, 0)}</td><td class="r num">${su.unfiltered.stats.win == null ? "–" : fmt(su.unfiltered.stats.win, 0) + "%"}</td><td class="r num">${pc(su.unfiltered.stats.avg)}</td><td class="r num">${pc(su.unfiltered.stats.vs_SPY)}</td><td class="r num">${pc(su.unfiltered.portfolio.cagr)}</td><td class="r num">${pc(su.unfiltered.portfolio.maxdd, false)}</td><td class="r num">${su.unfiltered.portfolio.calmar == null ? "–" : fmt(su.unfiltered.portfolio.calmar, 2)}</td></tr></tbody></table></div>` : ""}
        <p class="muted small">A signal is worth switching on in the scan when "Held when ON" beats "Held when OFF" by a clear margin <i>and</i> there are enough alerts behind it (the small grey numbers). Gamma, option flow and bids only exist live, so they're tracked below instead.</p></div>`;
    }
    html += `<div class="card" id="sbLive"><h3>Live support signals <span class="muted small">gamma, option flow and bids can't be backtested, so every scan setup's checks are saved and graded 10 trading days later</span></h3>
      <div id="sbLiveBody"><button class="btn ghost" id="sbLiveLoad">${ic("refresh", 14)} Show how they've done so far</button></div></div>`;
    // debt levels
    const dt = r.debt;
    if (dt && (dt.mcap.length || dt.rev.length)) {
      const drow = (x) => `<tr><td>${esc(x.name)}</td><td class="r num">${fmt(x.n, 0)}${x.open ? `<span class="muted small"> +${x.open} open</span>` : ""}</td><td class="r num">${x.win == null ? "–" : fmt(x.win, 0) + "%"}</td><td class="r num">${pc(x.avg)}</td><td class="r num">${pc(x.vs_SPY)}</td><td class="r num">${x.pf == null ? "–" : fmt(x.pf, 2)}</td></tr>`;
      const dtab = (title, rows_) => `<div><h4 class="sb-sub">${title}</h4><div class="table-wrap"><table class="res gx-tbl"><thead><tr><th>Debt was</th><th class="r">Trades</th><th class="r">Win</th><th class="r">Avg trade</th><th class="r">vs SPY</th><th class="r">Profit factor</th></tr></thead><tbody>${rows_.map(drow).join("")}</tbody></table></div></div>`;
      html += `<div class="card"><h3>By debt on the alert day <span class="muted small">every alert (filters or not) · debt from the latest SEC filing known that day, market cap at that day's close · ${esc(r.stop.label.toLowerCase())}</span></h3>
        <div class="two">${dtab("Debt as % of market cap", dt.mcap)}${dtab("Debt as % of yearly revenue", dt.rev)}</div>
        ${(dt.de || []).length ? `<div class="two">${dtab("Debt-to-equity", dt.de)}<div></div></div>` : ""}
        <p class="muted small">"No debt reported" usually means the company has none, but some report it under tags the app doesn't read. Banks, insurers and REITs carry debt as part of their business, so the filter skips them by default.</p></div>`;
    }
    // earnings buckets
    const et = r.earnings;
    if (et && (et.next.length || et.last.length)) {
      const erow = (x) => `<tr><td>${esc(x.name)}</td><td class="r num">${fmt(x.n, 0)}${x.open ? `<span class="muted small"> +${x.open} open</span>` : ""}</td><td class="r num">${x.win == null ? "–" : fmt(x.win, 0) + "%"}</td><td class="r num">${pc(x.avg)}</td><td class="r num">${pc(x.vs_SPY)}</td><td class="r num">${x.stopped == null ? "–" : fmt(x.stopped, 0) + "%"}</td><td class="r num">${x.pf == null ? "–" : fmt(x.pf, 2)}</td></tr>`;
      const etab = (title, rows_) => `<div><h4 class="sb-sub">${title}</h4><div class="table-wrap"><table class="res gx-tbl"><thead><tr><th>On the alert day</th><th class="r">Trades</th><th class="r">Win</th><th class="r">Avg trade</th><th class="r">vs SPY</th><th class="r">Stopped</th><th class="r">Profit factor</th></tr></thead><tbody>${rows_.map(erow).join("")}</tbody></table></div></div>`;
      html += `<div class="card" data-sec="by-earnings"><h3>Near earnings? <span class="muted small">every alert (filters or not), by trading days to the next report and since the last one · dates from FMP · ${esc(r.stop.label.toLowerCase())}</span></h3>
        <div class="two">${etab("Next earnings report", et.next)}${etab("Last earnings report", et.last)}</div>
        <p class="muted small">If alerts right before a report do worse or get stopped more, turn on <b>Near earnings</b> in the rules. A stop can't protect you from an overnight earnings gap: it fills at the open. Earnings dates downloaded ${et.built ? esc(String(et.built).slice(0, 10)) : "with this data"}; tick <b>Re-download data</b> to refresh them.</p></div>`;
    }
    // extension buckets
    const xt = r.extension;
    if (xt && (xt.spread.length || xt.peak.length)) {
      const xrow = (x) => `<tr><td>${esc(x.name)}</td><td class="r num">${fmt(x.n, 0)}${x.open ? `<span class="muted small"> +${x.open} open</span>` : ""}</td><td class="r num">${x.win == null ? "–" : fmt(x.win, 0) + "%"}</td><td class="r num">${pc(x.avg)}</td><td class="r num">${pc(x.vs_SPY)}</td><td class="r num">${x.stopped == null ? "–" : fmt(x.stopped, 0) + "%"}</td><td class="r num">${x.pf == null ? "–" : fmt(x.pf, 2)}</td></tr>`;
      const xtab = (title, first, rows_) => `<div><h4 class="sb-sub">${title}</h4><div class="table-wrap"><table class="res gx-tbl"><thead><tr><th>${first}</th><th class="r">Trades</th><th class="r">Win</th><th class="r">Avg trade</th><th class="r">vs SPY</th><th class="r">Stopped</th><th class="r">Profit factor</th></tr></thead><tbody>${rows_.map(xrow).join("")}</tbody></table></div></div>`;
      html += `<div class="card" data-sec="by-extension"><h3>How extended was it? <span class="muted small">every alert (filters or not), grouped by how far the trend had stretched on the alert day · ${esc(r.stop.label.toLowerCase())}</span></h3>
        <div class="two">${xtab(`Fast line above the slow line`, "Fast vs slow", xt.spread)}${xtab(`Highest close of the last ${xt.days} days above the slow line`, "Peak vs slow", xt.peak)}</div>
        ${(xt.spread_beta || []).length ? `<div class="two">${xtab("Fast vs slow × beta (what “scale by beta” uses)", "Stretch × beta", xt.spread_beta)}<div></div></div>` : ""}
        <p class="muted small">If the stretched rows (bottom of each table) win less or get stopped more, turn on <b>Not overextended</b> in the rules and set the limit just under where results drop off.</p></div>`;
    }
    // beta buckets
    const btb = r.beta;
    if (btb && btb.buckets && btb.buckets.length) {
      html += `<div class="card" data-sec="by-beta"><h3>By stock beta on the alert day <span class="muted small">every alert (filters or not) · beta vs SPY from the year before the alert · ${esc(r.stop.label.toLowerCase())}</span></h3>
        <div class="table-wrap"><table class="res gx-tbl"><thead><tr><th>Beta was</th><th class="r">Trades</th><th class="r">Win</th><th class="r">Avg trade</th><th class="r">vs SPY</th><th class="r">Profit factor</th></tr></thead><tbody>
        ${btb.buckets.map((x) => `<tr><td>${esc(x.name)}</td><td class="r num">${fmt(x.n, 0)}${x.open ? `<span class="muted small"> +${x.open} open</span>` : ""}</td><td class="r num">${x.win == null ? "–" : fmt(x.win, 0) + "%"}</td><td class="r num">${pc(x.avg)}</td><td class="r num">${pc(x.vs_SPY)}</td><td class="r num">${x.pf == null ? "–" : fmt(x.pf, 2)}</td></tr>`).join("")}</tbody></table></div>
        <p class="muted small">Your trades' stocks averaged a beta of <b>${btb.avg_alert_beta == null ? "–" : fmt(btb.avg_alert_beta, 2)}</b> (median ${btb.median_alert_beta == null ? "–" : fmt(btb.median_alert_beta, 2)}). The strategy's own beta (in the portfolio table) is usually lower, because it holds cash when slots are empty and spreads money over several stocks. Turn on <b>Beta filter</b> in the rules to only take a range.</p></div>`;
    }
    // shares vs calls
    const op = r.options;
    if (op && op.grid) {
      const oset = op.settings, osel = OPT_DTE.find((x) => x[0] === +oset.dte), win = op.winner || {};
      const [ok_, od] = B.osort || ["cagr", -1];
      const ov = (x) => ({ cagr: x.portfolio.cagr, calmar: x.portfolio.calmar, avg: x.stats.avg, win: x.stats.win, maxdd: x.portfolio.maxdd }[ok_]);
      const og = op.grid.slice().sort((a, b) => ((ov(b) ?? -1e9) - (ov(a) ?? -1e9)) * -od);
      const oth = (k, l) => `<th class="r sortable" data-ok="${k}">${l}${ok_ === k ? (od < 0 ? " ↓" : " ↑") : ""}</th>`;
      html += `<div class="card"><h3>Shares vs calls <span class="muted small">modeled with Black-Scholes · same alerts, same exits, same dollars per slot · click a row to use that call</span></h3>
        <div class="gx-cards">
          <div class="gx-card"><span>Shares</span><b class="num">${pf.cagr == null ? "–" : fmt(pf.cagr, 1) + "%/yr"}</b><small>worst drop ${pc(pf.maxdd, false)} · avg trade ${pc(s.avg)}</small></div>
          <div class="gx-card"><span>Calls: ${esc(osel ? osel[1] : oset.dte + " days")}, delta ${fmt(oset.delta, 2)}</span><b class="num">${op.portfolio.cagr == null ? "–" : fmt(op.portfolio.cagr, 1) + "%/yr"}</b><small>worst drop ${pc(op.portfolio.maxdd, false)} · avg trade ${pc(op.stats.avg)}</small></div>
          <div class="gx-card"><span>Calls win rate</span><b class="num">${op.stats.win == null ? "–" : fmt(op.stats.win, 0) + "%"}</b><small>shares ${s.win == null ? "–" : fmt(s.win, 0) + "%"} · ${op.expired == null ? "" : fmt(op.expired, 0) + "% expired before the exit"}</small></div>
          <div class="gx-card"><span>Typical call cost</span><b class="num">${op.avg_cost_pct == null ? "–" : fmt(op.avg_cost_pct, 1) + "%"}</b><small>of the share price · avg implied vol ${op.avg_iv ?? "–"}%</small></div>
          <div class="gx-card"><span>Best growth</span><b>${esc(win.cagr || "–")}</b><small>best return ÷ drop: ${esc(win.risk || "–")}</small></div>
        </div>
        <div class="table-wrap"><table class="res gx-tbl sb-opt"><thead><tr><th>Call</th><th class="r">Trades</th>${oth("win", "Win %")}${oth("avg", "Avg trade")}<th class="r">Expired</th><th class="r">Cost % of stock</th>${oth("cagr", "Portfolio /yr")}${oth("maxdd", "Worst drop")}${oth("calmar", "Return ÷ drop")}</tr></thead><tbody>
          <tr class="sb-shares"><td><b>Shares</b></td><td class="r num">${fmt(s.n, 0)}</td><td class="r num">${s.win == null ? "–" : fmt(s.win, 0) + "%"}</td><td class="r num">${pc(s.avg)}</td><td class="r num">–</td><td class="r num">100%</td><td class="r num">${pc(pf.cagr)}</td><td class="r num">${pc(pf.maxdd, false)}</td><td class="r num">${pf.calmar == null ? "–" : fmt(pf.calmar, 2)}</td></tr>
          ${og.map((x) => { const on = x.dte === +oset.dte && x.delta === +oset.delta; return `<tr data-dte="${x.dte}" data-delta="${x.delta}" class="${on ? "best-row" : ""}"><td>${esc(x.label)}${win.cagr === x.label ? ' <span class="gx-pill s1">growth</span>' : ""}${win.risk === x.label ? ' <span class="gx-pill s3">★</span>' : ""}</td>
            <td class="r num">${fmt(x.stats.n, 0)}</td><td class="r num">${x.stats.win == null ? "–" : fmt(x.stats.win, 0) + "%"}</td><td class="r num">${pc(x.stats.avg)}</td><td class="r num">${x.expired == null ? "–" : fmt(x.expired, 0) + "%"}</td>
            <td class="r num">${x.avg_cost_pct == null ? "–" : fmt(x.avg_cost_pct, 1) + "%"}</td><td class="r num">${pc(x.portfolio.cagr)}</td><td class="r num">${pc(x.portfolio.maxdd, false)}</td><td class="r num">${x.portfolio.calmar == null ? "–" : fmt(x.portfolio.calmar, 2)}</td></tr>`; }).join("")}</tbody></table></div>
        <p class="muted small"><b>This is a model, not real fills.</b> Public has no historical option prices, so each call is priced with Black-Scholes using the stock's own recent volatility × ${fmt(oset.iv_mult, 2)} as implied vol, ${fmt(oset.spread_pct, 1)}% round-trip spread, bought at the alert's close and sold when the share trade exits (or at expiration if that's sooner, which is what "Expired" counts).
          It doesn't capture earnings IV crush, skew, or wide spreads on thin options. Calls risk the whole premium: a 6-month 0.70-delta call usually costs 10–15% of the stock, so a $1,000 slot in calls moves like $5–8k of shares. The worst-drop column is the honest one.</p></div>`;
    }
    // stop-loss finder
    const best = r.best || {};
    const isK = (s, b) => b && stopKey(s) === stopKey(b);
    const [sk, sd] = B.sort;
    const val = (f) => ({ avg: f.stats.avg, win: f.stats.win, pf: f.stats.pf, cagr: f.portfolio.cagr, maxdd: f.portfolio.maxdd, calmar: f.portfolio.calmar, vs: f.stats.vs_SPY, stopped: f.stats.stopped }[sk]);
    const rows = r.finder.slice().sort((a, b) => ((val(b) ?? -1e9) - (val(a) ?? -1e9)) * -sd);
    const th = (k, l, t) => `<th class="r sortable" data-k="${k}" ${t ? `title="${esc(t)}"` : ""}>${l}${sk === k ? (sd < 0 ? " ↓" : " ↑") : ""}</th>`;
    html += `<div class="card"><h3>Stop-loss finder <span class="muted small">the same ${fmt(r.alerts_total, 0)} alerts replayed with each stop · click a column to rank · click a row to use that stop</span></h3>
      <div class="sb-best">
        ${best.risk ? `<div><span class="gx-pill s3">Best risk-adjusted</span> <b>${esc(best.risk.label)}</b> <span class="muted small">highest yearly return ÷ worst drop</span></div>` : ""}
        ${best.cagr ? `<div><span class="gx-pill s1">Best portfolio growth</span> <b>${esc(best.cagr.label)}</b></div>` : ""}
        ${best.return ? `<div><span class="gx-pill s1">Best average trade</span> <b>${esc(best.return.label)}</b></div>` : ""}
      </div>
      <div class="table-wrap"><table class="res gx-tbl sb-tbl"><thead><tr><th>Stop</th><th class="r">Trades</th>${th("win", "Win %")}${th("avg", "Avg trade")}<th class="r">Avg loss</th>${th("pf", "Profit factor", "Total gains ÷ total losses")}${th("stopped", "Stopped out")}<th class="r">Avg days</th>${th("vs", "vs SPY")}${th("cagr", "Portfolio /yr")}${th("maxdd", "Worst drop")}${th("calmar", "Return ÷ drop")}</tr></thead>
      <tbody>${rows.map((f) => { const t = f.stats, q = f.portfolio, on = isK(f.stop, r.stop); return `<tr data-s="${esc(stopKey(f.stop))}" class="${on ? "best-row" : ""}">
        <td>${esc(f.stop.label)} ${isK(f.stop, best.risk) ? '<span class="gx-pill s3">★</span>' : ""}${on ? ' <span class="muted small">(shown above)</span>' : ""}</td><td class="r num">${fmt(t.n, 0)}</td>
        <td class="r num">${t.win == null ? "–" : fmt(t.win, 0) + "%"}</td><td class="r num">${pc(t.avg)}</td><td class="r num">${pc(t.avg_loss)}</td><td class="r num">${t.pf == null ? "–" : fmt(t.pf, 2)}</td>
        <td class="r num">${t.stopped == null ? "–" : fmt(t.stopped, 0) + "%"}</td><td class="r num">${fmt(t.days, 0)}</td><td class="r num">${pc(t.vs_SPY)}</td>
        <td class="r num">${pc(q.cagr)}</td><td class="r num">${pc(q.maxdd, false)}</td><td class="r num">${q.calmar == null ? "–" : fmt(q.calmar, 2)}</td></tr>`; }).join("")}</tbody></table></div>
      <p class="muted small">Stops: "% below entry" and ATR stops sell intraday at the stop (or at the open if it gaps below); EMA and trailing stops sell at the close that breaks them.
        With only ~4 years of alerts, the very best row partly fits this period's luck. Prefer a stop that ranks well on several columns over the single top number.</p></div>`;
    // take-profit finder
    if (r.tp_finder && r.tp_finder.length) {
      const tb = r.tp_best || {};
      html += `<div class="card"><h3>Take-profit finder <span class="muted small">the same alerts with ${esc(r.stop.label.toLowerCase())}, each target · click a row to use that take profit</span></h3>
        <div class="sb-best">${tb.risk ? `<div><span class="gx-pill s3">Best risk-adjusted</span> <b>${esc(tb.risk.label)}</b></div>` : ""}${tb.cagr ? `<div><span class="gx-pill s1">Best portfolio growth</span> <b>${esc(tb.cagr.label)}</b></div>` : ""}</div>
        <div class="table-wrap"><table class="res gx-tbl sb-tp"><thead><tr><th>Take profit</th><th class="r">Trades</th><th class="r">Hit target</th><th class="r">Win %</th><th class="r">Avg trade</th><th class="r">Avg days</th><th class="r">vs SPY</th><th class="r">Portfolio /yr</th><th class="r">Worst drop</th><th class="r">Return ÷ drop</th></tr></thead>
        <tbody>${r.tp_finder.map((f) => { const t = f.stats, q = f.portfolio, on = stopKey(f.tp) === stopKey(r.take_profit || { type: "none" }); return `<tr data-tp="${esc(stopKey(f.tp))}" class="${on ? "best-row" : ""}">
          <td>${esc(f.tp.label)} ${tb.risk && stopKey(tb.risk) === stopKey(f.tp) ? '<span class="gx-pill s3">★</span>' : ""}${on ? ' <span class="muted small">(in use)</span>' : ""}</td><td class="r num">${fmt(t.n, 0)}</td>
          <td class="r num">${t.targets == null ? "–" : fmt(t.targets, 0) + "%"}</td><td class="r num">${t.win == null ? "–" : fmt(t.win, 0) + "%"}</td><td class="r num">${pc(t.avg)}</td><td class="r num">${fmt(t.days, 0)}</td>
          <td class="r num">${pc(t.vs_SPY)}</td><td class="r num">${pc(q.cagr)}</td><td class="r num">${pc(q.maxdd, false)}</td><td class="r num">${q.calmar == null ? "–" : fmt(q.calmar, 2)}</td></tr>`; }).join("")}</tbody></table></div>
        <p class="muted small">Targets sell intraday when the high reaches them (or at the open if it gaps above). If the stop and the target are both hit the same day, the test assumes the stop hit first.</p></div>`;
    }
    // gamma levels: forward test (no option history to backtest)
    html += `<div class="card" id="sbGamma"><h3>Gamma take profit / stop loss <span class="muted small">live tracking, not a backtest</span></h3>
      <p class="muted small" style="max-width:110ch">Public only has <b>today's</b> option chains, so gamma levels can't be replayed over the last 5 years. Instead, every scan setup and EMA alert now gets a gamma plan
        (take profit just under the call wall or the first positive-gamma pin above; stop 1% under the put wall, a pin or the gamma flip below), and each plan is saved and checked against the prices that follow.</p>
      <div id="sbGammaBody"><button class="btn ghost" id="sbGammaLoad">${ic("refresh", 14)} Show how the gamma plans have done</button></div></div>`;
    // by year / by line
    const yrow = (l, t) => `<tr><td>${esc(l)}</td><td class="r num">${fmt(t.n, 0)}${t.open ? `<span class="muted small"> +${t.open} open</span>` : ""}</td><td class="r num">${t.win == null ? "–" : fmt(t.win, 0) + "%"}</td><td class="r num">${pc(t.avg)}</td><td class="r num">${pc(t.vs_SPY)}</td><td class="r num">${pc(t.vs_QQQ)}</td><td class="r num">${pc(t.vs_RSP)}</td></tr>`;
    const yhead = `<thead><tr><th></th><th class="r">Trades</th><th class="r">Win</th><th class="r">Avg</th><th class="r">vs SPY</th><th class="r">vs QQQ</th><th class="r">vs RSP</th></tr></thead>`;
    html += `<div class="two"><div class="card"><h3>By year of the alert <span class="muted small">with ${esc(r.stop.label.toLowerCase())}</span></h3><div class="table-wrap"><table class="res gx-tbl">${yhead}<tbody>${r.by_year.map((y) => yrow(y.year, y)).join("")}</tbody></table></div></div>
      <div class="card"><h3>Which line was touched</h3><div class="table-wrap"><table class="res gx-tbl">${yhead}<tbody>
        ${[["fast", `${r.params.ma_type} ${r.params.fast}`], ["slow", `${r.params.ma_type} ${r.params.slow}`], ["both", "Both at once"]].filter(([k]) => r.by_line[k] && (r.by_line[k].n || r.by_line[k].open)).map(([k, l]) => yrow(l, r.by_line[k])).join("")}</tbody></table></div></div></div>`;
    // alert history (+ date-range search)
    const SR = B.search || {}, srRes = SR.res;
    const srcDays = srRes ? srRes.days : r.alert_days;
    const daysShown = srcDays.slice(0, B.daysShown);
    const lo = r.info.first_day, hi = r.info.last_day;
    const sm = srRes && srRes.summary;
    html += `<div class="card" data-sec="every-alert-day"><h3>Every alert day <span class="muted small">newest first · ${fmt(r.alert_days_total, 0)} days · result uses ${esc(r.stop.label.toLowerCase())} · click a ticker for its chart</span></h3>
      <form class="sb-search" id="sbSearch">
        <span class="muted small">Find trades from</span><input type="date" name="frm" min="${esc(lo)}" max="${esc(hi)}" value="${esc(SR.frm || "")}" aria-label="From date">
        <span class="muted small">to</span><input type="date" name="to" min="${esc(lo)}" max="${esc(hi)}" value="${esc(SR.to || "")}" aria-label="To date">
        <input type="text" name="tk" placeholder="ANY TICKER" value="${esc(SR.ticker || "")}" aria-label="Ticker" style="width:130px;text-transform:uppercase">
        <button class="btn primary small-btn">${ic("search", 14)} Search</button>
        ${srRes ? `<button type="button" class="btn ghost small-btn" id="sbSearchClear">Clear</button>` : ""}
        <span class="sb-quick">${(r.info.years_available || []).map((y) => `<button type="button" class="chip-btn" data-yr="${y}">${y}</button>`).join("")}</span>
      </form>
      ${sm ? (sm.alerts ? `<div class="sb-search-sum"><b>${fmt(sm.alerts, 0)} trades</b> on ${fmt(sm.days, 0)} days${SR.ticker ? ` in ${esc(SR.ticker.toUpperCase())}` : ""} · ${esc(srRange(SR, lo, hi))}
          <span class="sep">|</span> win ${sm.win == null ? "–" : fmt(sm.win, 0) + "%"} <span class="muted small">(${fmt(sm.finished, 0)} finished${sm.open ? `, ${fmt(sm.open, 0)} open` : ""})</span>
          <span class="sep">|</span> avg trade ${pc(sm.avg)} <span class="sep">|</span> avg vs SPY ${pc(sm.vs_SPY)} <span class="sep">|</span> beat SPY ${sm.beat_spy == null ? "–" : fmt(sm.beat_spy, 0) + "%"}
          ${srRes.partial ? `<div class="muted small">Searching only the newest 400 alert days: run the test once on this version to search all of them.</div>` : ""}</div>`
        : `<div class="sb-search-sum muted">No trades ${SR.ticker ? "in " + esc(SR.ticker.toUpperCase()) + " " : ""}between ${esc(srRange(SR, lo, hi))}.</div>`) : ""}
      ${daysShown.length ? `<div class="table-wrap"><table class="res gx-tbl sb-days"><thead><tr><th>Date</th><th>Ticker</th><th>Line</th><th class="r" title="History support signals on the alert day">Support</th><th class="r" title="Macro score on the alert day">Macro</th><th class="r" title="Stock beta vs SPY on the alert day">Beta</th><th class="r" title="Trading days to the next earnings report (FMP)">Earn.</th><th>Sector</th><th class="r">Entry</th><th class="r">1 month</th><th class="r">3 months</th><th class="r">1 year</th><th class="r">Result</th><th class="r" title="The modeled call on the same trade">Call</th><th class="r">vs SPY</th><th>Exit</th></tr></thead><tbody>
      ${daysShown.map((dd) => dd.alerts.map((a, i) => `<tr><td class="num">${i === 0 ? esc(parseDay(dd.date).toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" })) + (dd.alerts.length > 1 ? ` <span class="muted small">${dd.alerts.length} alerts</span>` : "") : ""}</td>
        <td><button class="rot-chip" data-t="${esc(a.ticker)}">${esc(a.ticker)}</button></td><td class="muted small">${a.line === "both" ? "both" : a.line === "fast" ? r.params.fast : r.params.slow}</td>
        <td class="r num small">${a.sig ? Object.values(a.sig).filter(Boolean).length + "/" + Object.keys(a.sig).length : "–"}</td>
        <td class="r num small ${a.macro == null ? "muted" : a.macro >= 3 ? "pos" : a.macro < -2 ? "neg" : ""}">${a.macro == null ? "–" : (a.macro > 0 ? "+" : "") + fmt(a.macro, 1)}</td>
        <td class="r num small">${a.beta == null ? "–" : fmt(a.beta, 2)}</td>
        <td class="r num small ${a.earn_next != null && a.earn_next <= 10 ? "neg" : ""}" title="${a.earn_next == null ? "No earnings date known" : "Next report in " + a.earn_next + " trading days" + (a.earn_last != null ? ", last one " + a.earn_last + " days before" : "")}">${a.earn_next == null ? "–" : a.earn_next + "d"}</td>
        <td><span class="muted small">${esc(a.sector || "–")}</span>${a.sq ? ` <span class="q-tag q-${esc(a.sq.toLowerCase())}">${esc(a.sq)}</span>` : ""}${a.sv != null ? ` <span class="q-tag ${a.sv >= 3 ? "q-leading" : a.sv <= -3 ? "q-lagging" : "q-unknown"}" title="Sector valuation that day">${a.sv > 0 ? "+" : ""}${fmt(a.sv, 1)}</span>` : ""}</td>
        <td class="r num">$${fmt(a.entry)}</td><td class="r num">${pc(a.r21)}</td><td class="r num">${pc(a.r63)}</td><td class="r num">${pc(a.r252)}</td><td class="r num">${pc(a.ret)}</td><td class="r num">${pc(a.opt_ret)}</td><td class="r num">${pc(a.vs_SPY)}</td>
        <td class="muted small">${a.reason === "stop" ? "stopped " : a.reason === "target" ? "target hit " : a.reason === "open" ? "still open " : "held "}${esc(a.exit_date)}</td></tr>`).join("")).join("")}</tbody></table></div>` : ""}
      ${srcDays.length > B.daysShown ? `<button class="btn ghost more" id="sbMore">Show more days</button>` : ""}</div>`;
    html += `<div class="card sb-limits"><h3>Read this before trusting the numbers</h3><ul>
      <li><b>Survivorship bias:</b> the stock list is today's companies. Ones that went bust or were bought out since are missing, so results look somewhat better than they really were.</li>
      <li><b>No look-ahead on fundamentals:</b> each quarter only counts from the day after its SEC filing. Prices: Public's last 5 years of daily bars, so alerts start once the ${r.params.slow}-day average has settled.</li>
      <li><b>Small sample:</b> ~${fmt(years, 1)} years of alerts, mostly one market regime. 1-year results only exist for alerts at least a year old.</li>
      <li><b>Fills:</b> bought at the alert day's close; no fees, slippage, taxes or dividends.</li>
      ${(r.params.not_simulated || []).length ? `<li><b>Not simulated:</b> ${esc(r.params.not_simulated.join(", "))}.</li>` : ""}</ul></div>`;
    el.innerHTML = html;
    $$(".sb-tbl th.sortable", el).forEach((h) => (h.onclick = () => { const k = h.dataset.k; B.sort = [k, B.sort[0] === k ? -B.sort[1] : -1]; drawStrategyBt(); }));
    $$(".sb-tbl tbody tr", el).forEach((tr) => (tr.onclick = () => {
      const s = (B.data.stops || []).find((x) => stopKey(x) === tr.dataset.s);
      if (s && P.sbt.start) { toast(`Re-running with: ${s.label}`); P.sbt.start({ stop: s }); }
    }));
    $$(".rot-chip", el).forEach((b) => (b.onclick = () => { P.chart.ticker = b.dataset.t; P.chart.data = null; show("charts"); }));
    const more = $("#sbMore"); if (more) more.onclick = () => { B.daysShown += 50; drawStrategyBt(); };
    const sf = $("#sbSearch");
    if (sf) {
      const go = async (frm, to, tk) => {
        if (!frm && !to && !tk) { B.search = null; B.daysShown = 30; return drawStrategyBt(); }
        const res = await call("search_strategy_alerts", frm, to, tk);
        if (!res.ok) return toast(res.error, true);
        B.search = { frm, to, ticker: tk, res }; B.daysShown = 30; drawStrategyBt();
        const c = $('.card[data-sec="every-alert-day"]'); if (c) c.scrollIntoView({ block: "start", behavior: "smooth" });
      };
      sf.onsubmit = (e) => { e.preventDefault(); go(sf.frm.value, sf.to.value, sf.tk.value.trim().toUpperCase()); };
      $$("[data-yr]", sf).forEach((b) => (b.onclick = () => go(`${b.dataset.yr}-01-01`, `${b.dataset.yr}-12-31`, sf.tk.value.trim().toUpperCase())));
      const cl = $("#sbSearchClear"); if (cl) cl.onclick = () => go("", "", "");
    }
    $$(".yr-tab", el).forEach((b) => (b.onclick = () => { B.curveYear = b.dataset.cy || null; drawStrategyBt(); }));
    $$("[data-exyr]", el).forEach((b) => (b.onclick = () => {
      if (!P.sbt.start) return;
      const y = +b.dataset.exyr, cur = ((B.params && B.params.exclude_years) || r.info.exclude_years || []).map(Number);
      const next = cur.includes(y) ? cur.filter((x) => x !== y) : cur.concat(y).sort();
      B.params = Object.assign({}, B.params, { exclude_years: next });
      toast(next.length ? `Leaving out ${next.join(", ")} from every line` : "All years back in"); P.sbt.start({ exclude_years: next });
    }));
    $$(".sb-line", el).forEach((b) => (b.onclick = () => { const k = b.dataset.line; B.hidden[k] = !B.hidden[k]; try { localStorage.setItem("sbHidden", JSON.stringify(B.hidden)); } catch (e) {} drawStrategyBt(); }));
    $$(".sb-opt th.sortable", el).forEach((h) => (h.onclick = () => { const k = h.dataset.ok; B.osort = [k, (B.osort || [])[0] === k ? -(B.osort[1]) : -1]; drawStrategyBt(); }));
    $$(".sb-opt tbody tr[data-dte]", el).forEach((tr) => (tr.onclick = () => {
      if (!P.sbt.start) return;
      const o = Object.assign({}, (B.params || {}).options || {}, { dte: +tr.dataset.dte, delta: +tr.dataset.delta });
      toast(`Re-running with calls: ${tr.cells[0].textContent.split(" growth")[0]}`); P.sbt.start({ options: o });
    }));
    $$(".sb-tp tbody tr", el).forEach((tr) => (tr.onclick = () => {
      const t = (B.data.tps || []).find((x) => stopKey(x) === tr.dataset.tp);
      if (t && P.sbt.start) { toast(`Re-running with take profit: ${t.label}`); P.sbt.start({ take_profit: t }); }
    }));
    $$("[data-fr]", el).forEach((b) => (b.onclick = () => {
      if (!P.sbt.start) return;
      const k = b.dataset.fr, extra = {};
      if (k.startsWith("require:")) extra.require = Array.from(new Set([...(B.params.require || []), k.slice(8)]));
      else extra[k] = true;
      B.params = Object.assign({}, B.params, extra);
      toast("Turned it on: re-running"); P.sbt.start(extra);
    }));
    $$("[data-wm]", el).forEach((b) => (b.onclick = () => { B.wlMode = b.dataset.wm; drawStrategyBt(); }));
    const wo = $("#wlOpen"); if (wo) wo.onchange = () => { B.wlOpen = wo.checked; drawStrategyBt(); };
    const wmore = $("#wlMore"); if (wmore) wmore.onclick = () => { B.wlShown = (B.wlShown || 15) + 15; drawStrategyBt(); };
    const wsf = $("#wlSearch");
    if (wsf) {
      const go = async (tk, frm, to) => {
        if (!tk && !frm && !to) { B.wlSearch = null; B.wlShown = 15; return drawStrategyBt(); }
        const res = await call("search_winners_losers", tk, frm, to);
        if (!res.ok) return toast(res.error, true);
        B.wlSearch = { tk, frm, to, res: res.extremes, partial: res.partial }; B.wlShown = 15; drawStrategyBt();
      };
      wsf.onsubmit = (e) => { e.preventDefault(); go(wsf.tk.value.trim().toUpperCase(), wsf.frm.value, wsf.to.value); };
      $$("[data-wlyr]", wsf).forEach((b) => (b.onclick = () => go(wsf.tk.value.trim().toUpperCase(), `${b.dataset.wlyr}-01-01`, `${b.dataset.wlyr}-12-31`)));
      const wc = $("#wlClear"); if (wc) wc.onclick = () => go("", "", "");
    }
    sbCollapsify(el);
    drawAlertCal();
    $("#sbFoldAll").onclick = () => sbFoldAll(true);
    $("#sbUnfoldAll").onclick = () => sbFoldAll(false);
    const gl = $("#sbGammaLoad"); if (gl) gl.onclick = drawGammaJournal;
    const ll = $("#sbLiveLoad"); if (ll) ll.onclick = drawSupportJournal;
    if (B.sj) drawSupportJournal();
    if (B.gj) drawGammaJournal();
  }

  /* ---- alert calendar: years (dropdown) · months · days · the clicked day's alerts ---- */
  const MON = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  P.dayCal = {};
  const CAL_CFG = {
    sbt: () => { const r = P.sbt.data && P.sbt.data.result; return r && { body: "#sbCalBody", api: "strategy_calendar", run: r.finished, holder: P.sbt, live: false }; },
    daily: () => ({ body: "#dayCalBody", api: "alerts_calendar", run: "daily:" + ((S.state && S.state.last_scan && S.state.last_scan.run_at) || ""), holder: P.dayCal, live: true }),
  };
  async function drawAlertCal(year, which = "sbt") {
    const cfg = CAL_CFG[which](), el0 = cfg && $(cfg.body);
    if (!el0) return;
    const B = cfg.holder;
    const C = B.cal = B.cal && B.cal.run === cfg.run ? B.cal : { run: cfg.run, mode: "avg", per: 1000 };
    if (year !== undefined || !C.data) {
      const res = await call(cfg.api, year === undefined ? (C.year || null) : year);
      if (!res.ok) { el0.innerHTML = `<p class="muted">${esc(res.error)}</p>`; return; }
      C.data = res;
      if (C.year !== res.year) { C.year = res.year; C.month = null; C.day = null; }
    }
    const el = $(cfg.body);
    if (!el) return;
    const D = C.data, Y = D.year;
    if (!Y) { el.innerHTML = `<p class="muted">No alerts in this run.</p>`; return; }
    if (C.month == null) {                                       // newest month with alerts
      const ms = D.months.filter((m) => m.n).map((m) => m.m);
      C.month = ms.length ? ms[ms.length - 1] : 1;
    }
    const pc = (v, d = 1) => (v == null ? "–" : `${v > 0 ? "+" : ""}${fmt(v, d)}%`);
    const cl = (v) => (v == null ? "" : v > 0 ? "pos" : v < 0 ? "neg" : "");
    const usd = (v) => `${v >= 0 ? "+" : "−"}$${fmt(Math.abs(v), 0)}`;
    const dayVal = (x) => (C.mode === "usd" ? usd((x.sum || 0) / 100 * C.per) : C.mode === "count" ? `${x.n}` : pc(x.avg));
    const lineLab = (l) => (l === "both" ? "both" : l === "fast" ? D.params.fast : l === "slow" ? D.params.slow : String(l || "").replace(/EMA |SMA /g, ""));
    const yrs = Object.keys(D.years);
    // year dropdown
    const ylist = yrs.map((y) => { const v = D.years[y].avg; return `<div class="yi ${y === Y ? "on" : ""}" data-cy="${y}"><span class="ck">${y === Y ? "✓" : ""}</span><b>${y}</b><span class="yv ${y === Y ? "" : cl(v)}">${pc(v)}</span></div>`; }).join("");
    // months
    const months = D.months.map((m) => `<div class="mo ${m.m === C.month ? "on" : ""} ${m.n ? "" : "none"}" data-cm="${m.m}"><b>${MON[m.m - 1]}</b>
        <small class="${m.m === C.month ? "" : cl(m.avg)}">${m.n ? (C.mode === "usd" ? usd(m.sum / 100 * C.per) : pc(m.avg)) : "–"}</small><small class="muted mo-n">${m.n} alert${m.n === 1 ? "" : "s"}</small>
        ${m.avg != null ? `<i style="width:${Math.min(100, Math.abs(m.avg) * 6)}%;background:${m.avg > 0 ? "var(--pass)" : "var(--fail)"}"></i>` : ""}</div>`).join("");
    // days of the month
    const first = new Date(+Y, C.month - 1, 1).getDay(), nd = new Date(+Y, C.month, 0).getDate();
    let cells = "";
    for (let i = 0; i < first; i++) cells += `<div class="cd blank"></div>`;
    const mrows = [];
    for (let d = 1; d <= nd; d++) {
      const key = `${Y}-${String(C.month).padStart(2, "0")}-${String(d).padStart(2, "0")}`, x = D.days[key], dow = (first + d - 1) % 7;
      if (!x) { cells += `<div class="cd ${dow === 0 || dow === 6 ? "wk" : ""}"><span class="n">${d}</span></div>`; continue; }
      mrows.push(...x.alerts);
      const allOpen = x.open === x.n && x.n > 0, c_ = allOpen ? "f" : x.avg > 0.3 ? "w" : x.avg < -0.3 ? "l" : "f";
      cells += `<div class="cd ${c_} ${C.day === key ? "sel" : ""}" data-cd="${key}" tabindex="0">
        <div class="hd"><span class="c">${x.n} alert${x.n === 1 ? "" : "s"}</span><span class="n">${d}</span></div>
        <div class="tks">${x.alerts.map((a) => `<span class="${a.reason === "open" ? "o" : a.ret > 0 ? "w" : "l"}">${esc(a.ticker)}</span>`).join("")}</div>
        <div class="ft"><span class="c">${allOpen ? "open" : ""}</span><span class="v">${dayVal(x)}</span></div></div>`;
    }
    const ms = D.months[C.month - 1], won = mrows.filter((a) => a.reason !== "open" && a.ret > 0).length, lost = mrows.filter((a) => a.reason !== "open" && a.ret <= 0).length;
    const msum = mrows.reduce((t, a) => t + (a.ret || 0), 0);
    // side panel
    const sel = C.day && D.days[C.day];
    let side = `<div class="muted" style="padding:20px 4px">Click a day to see its alerts.</div>`;
    if (sel) {
      const sw = sel.alerts.filter((a) => a.reason !== "open" && a.ret > 0).length, sl = sel.alerts.filter((a) => a.reason !== "open" && a.ret <= 0).length;
      side = `<h4>${esc(parseDay(C.day).toLocaleDateString(undefined, { weekday: "long", month: "long", day: "numeric", year: "numeric" }))}</h4>
        <div class="muted small">${sel.n} alert${sel.n === 1 ? "" : "s"} · ${cfg.live ? "P/L from that day's close to the latest price" : "bought at that day's close"} · hover a row for more</div>
        <div class="cal-sum">Avg <b class="${cl(sel.avg)}">${pc(sel.avg)}</b> <span>$ on $${fmt(C.per, 0)} each <b class="${cl(sel.sum)}">${usd((sel.sum || 0) / 100 * C.per)}</b></span> <span>${sw} won · ${sl} lost${sel.open ? ` · ${sel.open} open` : ""}</span></div>
        <div class="cal-list"><table class="cmp"><thead><tr><th>Ticker</th><th>Line</th><th class="r">${cfg.live ? "Alert → now" : "Entry → exit"}</th><th class="r">P/L</th><th class="r">$${C.per >= 1000 ? fmt(C.per / 1000, C.per % 1000 ? 1 : 0) + "k" : fmt(C.per, 0)}</th><th class="r">vs SPY</th><th>Exit</th></tr></thead><tbody>
        ${sel.alerts.map((a) => `<tr title="${esc([a.sector, a.beta != null ? "beta " + fmt(a.beta, 2) : "", a.macro != null ? "macro " + (a.macro > 0 ? "+" : "") + fmt(a.macro, 1) : "", a.sig ? "support " + Object.values(a.sig).filter(Boolean).length + "/" + Object.keys(a.sig).length : "", a.opt_ret != null ? "call " + pc(a.opt_ret) : "", "exit " + (a.exit_date || "")].filter(Boolean).join(" · "))}">
          <td><button class="rot-chip" data-t="${esc(a.ticker)}">${esc(a.ticker)}</button>${cfg.live && a.profile ? `<div class="ln" style="max-width:200px;overflow:hidden;text-overflow:ellipsis">${esc(a.profile)}</div>` : ""}</td><td class="ln">${esc(String(lineLab(a.line)))}</td>
          <td class="r num">${fmt(a.entry)} → ${a.exit == null ? "–" : fmt(a.exit)}</td><td class="r num"><b class="${cl(a.ret)}">${pc(a.ret)}</b></td>
          <td class="r num ${cl(a.ret)}">${a.ret == null ? "–" : usd(a.ret / 100 * C.per)}</td><td class="r num ${cl(a.vs_SPY)}">${a.vs_SPY == null ? "–" : (a.vs_SPY > 0 ? "+" : "") + fmt(a.vs_SPY, 1)}</td>
          <td class="ln">${a.reason === "stop" ? "stop" : a.reason === "target" ? "target" : a.reason === "open" ? "open" : a.reason === "now" ? "held" : "time"} ${a.days != null ? a.days + "d" : ""}</td></tr>`).join("")}</tbody></table></div>`;
    }
    el.innerHTML = `<div class="cal-top">
        <div class="ysel"><button class="ybtn" id="calY" aria-haspopup="listbox">${Y} <span>▾</span></button><div class="ylist" id="calYList" role="listbox" hidden>${ylist}</div></div>
        <div class="cal-legend"><span><i class="w"></i>winning day</span><span><i class="l"></i>losing day</span><span><i class="f"></i>flat / still open</span></div>
        <label class="muted small cal-per">$ per trade <input type="number" id="calPer" min="100" step="100" value="${C.per}"></label>
        <span class="seg"><button class="${C.mode === "avg" ? "on" : ""}" data-cmode="avg">Avg %</button><button class="${C.mode === "usd" ? "on" : ""}" data-cmode="usd">$</button><button class="${C.mode === "count" ? "on" : ""}" data-cmode="count">Count</button></span></div>
      <div class="cal-months">${months}</div>
      <div class="cal-wrap"><div>
          <div class="cal-dow">${["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((x) => `<div>${x}</div>`).join("")}</div>
          <div class="cal-grid">${cells}</div>
          <div class="cal-totals"><span><b>${MON[C.month - 1]} ${Y}:</b> ${ms.n} alerts on ${Object.keys(D.days).filter((k) => +k.slice(5, 7) === C.month).length} days</span>
            <span>avg trade <b class="${cl(ms.avg)}">${pc(ms.avg)}</b></span><span>${won} won · ${lost} lost${ms.open ? ` · ${ms.open} open` : ""}</span>
            <span>$ on $${fmt(C.per, 0)} each: <b class="${cl(msum)}">${usd(msum / 100 * C.per)}</b></span>
            <span class="muted">${Y}: ${pc(D.years[Y].avg)} avg over ${D.years[Y].n} alerts</span></div></div>
        <div class="cal-side">${side}</div></div>
      <p class="muted small" style="margin:10px 0 0">${cfg.live
        ? `Every setup your daily scan and scheduled profile scans alerted, with its P/L from the alert day's close to the latest price${D.priced ? ` (priced ${esc(D.priced.replace("T", " "))})` : ""}. Tickers are green if up since, red if down; as many as fit are shown, then "+N".`
        : `Tickers are green if that trade won, red if it lost, grey if still open; as many as fit are shown, then "+N". A trade counts on the day it was alerted (bought at that close), with its final result even if it closed weeks later.${D.partial ? " Showing the newest 400 alert days only: run the test once on this version for all of them." : ""}`}</p>`;
    // fit tickers into each day: hide what doesn't fit, show "+N"
    $$(".cd .tks", el).forEach((box) => {
      const H = box.clientHeight; let hidden = 0;
      const items = [...box.children];
      for (let i = items.length - 1; i >= 0 && box.scrollHeight > H + 1; i--) { items[i].remove(); hidden++; }
      if (hidden) {
        const m = document.createElement("span"); m.className = "more"; m.textContent = "+" + hidden; box.appendChild(m);
        while (box.scrollHeight > H + 1 && box.children.length > 1) { box.removeChild(box.children[box.children.length - 2]); hidden++; m.textContent = "+" + hidden; }
      }
    });
    const yb = $("#calY", el), yl = $("#calYList", el);
    yb.onclick = (e) => { e.stopPropagation(); yl.hidden = !yl.hidden; if (!yl.hidden) { const on = $(".yi.on", yl); if (on) yl.scrollTop = on.offsetTop - 120; } };
    document.addEventListener("click", function close_(e) { if (!el.isConnected) return document.removeEventListener("click", close_); if (!e.target.closest(".ysel")) yl.hidden = true; });
    $$(".yi", yl).forEach((x) => (x.onclick = () => { yl.hidden = true; drawAlertCal(x.dataset.cy, which); }));
    $$("[data-cm]", el).forEach((x) => (x.onclick = () => { C.month = +x.dataset.cm; C.day = null; drawAlertCal(undefined, which); }));
    $$("[data-cd]", el).forEach((x) => { x.onclick = () => { C.day = x.dataset.cd; drawAlertCal(undefined, which); }; x.onkeydown = (e) => { if (e.key === "Enter") x.onclick(); }; });
    $$("[data-cmode]", el).forEach((x) => (x.onclick = () => { C.mode = x.dataset.cmode; drawAlertCal(undefined, which); }));
    $("#calPer", el).onchange = (e) => { C.per = Math.max(1, +e.target.value || 1000); drawAlertCal(undefined, which); };
    $$(".rot-chip", el).forEach((b) => (b.onclick = () => { P.chart.ticker = b.dataset.t; P.chart.data = null; show("charts"); }));
  }

  /* Hide / show for every Strategy Test section. The state is remembered per section. */
  function betaWord(b) {
    if (b == null) return "";
    return b < 0 ? "moves against the market" : b < 0.5 ? "barely tied to the market" : b < 0.8 ? "defensive" : b < 1.2 ? "moves with the market" : b < 1.6 ? "aggressive" : "high beta";
  }
  function srRange(SR, lo, hi) {
    const f = (d_) => parseDay(d_).toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" });
    return `${f(SR.frm || lo)} – ${f(SR.to || hi)}`;
  }
  function sbFolded() {
    const B = P.sbt;
    if (!B.folded) { try { B.folded = JSON.parse(localStorage.getItem("sbFolded") || "{}") || {}; } catch (e) { B.folded = {}; } }
    return B.folded;
  }
  function sbSaveFolded() { try { localStorage.setItem("sbFolded", JSON.stringify(P.sbt.folded || {})); } catch (e) {} }
  function sbSecKey(card) {
    if (card.dataset.sec) return card.dataset.sec;
    const h = card.querySelector(":scope > h3, :scope > summary");
    const t = h ? (h.firstChild && h.firstChild.nodeType === 3 ? h.firstChild.textContent : h.textContent) : "";
    return t.trim().toLowerCase().replace(/[^a-z0-9]+/g, "-").slice(0, 40) || "sec";
  }
  function sbCollapsify(scope) {
    const F = sbFolded();
    $$(".card", scope).forEach((card) => {
      if (card.tagName === "DETAILS" || card.classList.contains("fold-ok")) return;
      const h = card.querySelector(":scope > h3");
      if (!h) return;
      const key = sbSecKey(card);
      card.classList.add("foldable", "fold-ok");
      card.dataset.sec = key;
      const b = document.createElement("button");
      b.type = "button"; b.className = "fold-btn"; b.setAttribute("aria-label", "Hide or show this section");
      h.prepend(b);
      const set = (folded) => { card.classList.toggle("folded", folded); b.textContent = folded ? "▸" : "▾"; b.title = folded ? "Show" : "Hide"; };
      set(!!F[key]);
      h.onclick = (e) => {
        if (e.target.closest("button:not(.fold-btn), a, input, select")) return;
        F[key] = !card.classList.contains("folded"); set(F[key]); sbSaveFolded();
      };
    });
  }
  function sbFoldAll(folded) {
    const F = sbFolded();
    $$("#strategybtBody .foldable").forEach((c) => { F[c.dataset.sec] = folded; c.classList.toggle("folded", folded); const b = $(".fold-btn", c); if (b) b.textContent = folded ? "▸" : "▾"; });
    if (folded) $$("#strategybtBody details.card").forEach((d) => (d.open = false));
    sbSaveFolded();
  }

  async function drawSupportJournal() {
    const el = $("#sbLiveBody");
    if (!el) return;
    el.innerHTML = `<div class="loading">${ic("refresh", 16)} Grading saved support checks…</div>`;
    const r = await call("support_journal_results");
    P.sbt.sj = true;
    if (!$("#sbLiveBody")) return;
    if (!r.ok) { el.innerHTML = `<p class="neg">${esc(r.error)}</p>`; return; }
    const s = r.summary || {};
    if (!s.checks) { el.innerHTML = `<p class="muted">Nothing saved yet. Each daily scan saves the support check of every setup (Settings → support check on alerts), then grades it once 10 trading days have passed.</p>`; return; }
    const hr = (x) => (x.held_rate == null ? "–" : fmt(x.held_rate, 0) + "%");
    el.innerHTML = `<p class="muted small">${fmt(s.checks, 0)} checks saved · ${fmt(s.finished, 0)} graded${s.held_rate != null ? ` · the line held ${fmt(s.held_rate, 0)}% of the time overall` : ""}</p>
      <div class="table-wrap"><table class="res gx-tbl"><thead><tr><th>Signal</th><th class="r">Held when ON</th><th class="r">Held when OFF</th><th class="r">Difference</th></tr></thead><tbody>
      ${r.signals.map((x) => `<tr><td>${esc(x.label)}</td><td class="r num">${hr(x.with)} <span class="muted small">${x.with.held_n}</span></td><td class="r num">${hr(x.without)} <span class="muted small">${x.without.held_n}</span></td><td class="r num">${x.edge == null ? "–" : (x.edge > 0 ? "+" : "") + fmt(x.edge, 0) + " pts"}</td></tr>`).join("")}</tbody></table></div>
      <p class="muted small">Needs a few months of alerts before the differences mean much.</p>`;
  }

  async function drawGammaJournal() {
    const el = $("#sbGammaBody");
    if (!el) return;
    el.innerHTML = `<div class="loading">${ic("refresh", 16)} Checking every saved plan against prices since…</div>`;
    const r = await call("gamma_plan_results");
    P.sbt.gj = true;
    if (!$("#sbGammaBody")) return;
    if (!r.ok) { el.innerHTML = `<p class="neg">${esc(r.error)}</p>`; return; }
    const s = r.summary || {};
    if (!s.plans) { el.innerHTML = `<p class="muted">No gamma plans saved yet. They're added each time the daily scan finds a setup or an EMA alert fires (Settings → Gamma take profit / stop loss).</p>`; return; }
    const pc = (v) => (v == null ? "–" : `<span class="${cls(v)}">${v > 0 ? "+" : ""}${fmt(v, 1)}%</span>`);
    el.innerHTML = `<div class="gx-cards">
        <div class="gx-card"><span>Plans saved</span><b class="num">${fmt(s.plans, 0)}</b><small>${fmt(s.closed, 0)} finished · ${fmt(s.open, 0)} still open</small></div>
        <div class="gx-card"><span>Take profit hit first</span><b class="num">${s.target_pct == null ? "–" : fmt(s.target_pct, 0) + "%"}</b><small>of finished plans</small></div>
        <div class="gx-card"><span>Avg finished result</span><b class="num">${pc(s.avg_ret)}</b><small>${s.avg_days == null ? "" : "after ~" + fmt(s.avg_days, 0) + " trading days"}</small></div>
        <div class="gx-card"><span>Avg planned reward/risk</span><b class="num">${s.avg_rr == null ? "–" : fmt(s.avg_rr, 1)}</b><small>target distance ÷ stop distance</small></div></div>
      <div class="table-wrap"><table class="res gx-tbl"><thead><tr><th>Date</th><th>Ticker</th><th>From</th><th class="r">Entry</th><th class="r">Take profit</th><th class="r">Stop</th><th class="r">R/R</th><th>Result</th><th class="r">Return</th></tr></thead><tbody>
      ${r.rows.slice(0, 60).map((x) => `<tr><td class="num">${esc(x.date)}</td><td><button class="rot-chip" data-t="${esc(x.ticker)}">${esc(x.ticker)}</button></td><td class="muted small">${x.source === "scan" ? "scan" : "EMA alert"}</td>
        <td class="r num">$${fmt(x.entry)}</td><td class="r num">${x.tp ? "$" + fmt(x.tp) + ` <span class="muted small">${esc(x.tp_why || "")}</span>` : "–"}</td><td class="r num">${x.sl ? "$" + fmt(x.sl) + ` <span class="muted small">${esc(x.sl_why || "")}</span>` : "–"}</td>
        <td class="r num">${x.rr == null ? "–" : fmt(x.rr, 1)}</td><td>${x.result === "target" ? '<span class="pos">🎯 target</span>' : x.result === "stop" ? '<span class="neg">stopped</span>' : x.result === "open" ? '<span class="muted">open</span>' : esc(x.result)}${x.exit_date ? ` <span class="muted small">${esc(x.exit_date)}</span>` : ""}</td>
        <td class="r num">${pc(x.ret)}</td></tr>`).join("")}</tbody></table></div>
      <p class="muted small">Give it a few months before trusting it: each plan only counts once its target or stop is hit.</p>`;
    $$(".rot-chip", el).forEach((b) => (b.onclick = () => { P.chart.ticker = b.dataset.t; P.chart.data = null; show("charts"); }));
  }

  function sbCurve(cv, hidden) {
    if (!cv || !cv.t || !cv.t.length) return "";
    const W = 1100, H = 280, padT = 12, padB = 24, padR = 120;
    const series = SB_LINES.filter(([k]) => cv[k] && !(hidden || {})[k]).map(([k, col]) => ({ k, col, v: cv[k] }));
    if (!series.length) return `<p class="muted">All lines hidden.</p>`;
    const all = series.flatMap((s) => s.v.filter((x) => x != null));
    let mx = Math.max(...all), mn = Math.min(...all);
    const pad = (mx - mn) * 0.05; mx += pad; mn -= pad;
    const n = cv.t.length, x = (i) => 4 + (i / Math.max(1, n - 1)) * (W - padR - 8), y = (v) => padT + ((mx - v) / (mx - mn)) * (H - padT - padB);
    let out = "";
    const step = niceStep((mx - mn) / 5);
    for (let v = Math.ceil(mn / step) * step; v <= mx; v += step) out += `<line x1="0" x2="${W - padR}" y1="${y(v)}" y2="${y(v)}" stroke="var(--line-soft)"/><text x="${W - padR + 6}" y="${y(v) + 4}" class="ax">$${fmt(v / 1000, 0)}k</text>`;
    out += `<line x1="0" x2="${W - padR}" y1="${y(10000)}" y2="${y(10000)}" stroke="var(--muted)" stroke-dasharray="3 3"/>`;
    let ly = "";
    const MON = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    if (cv.month) cv.t.forEach((t, i) => {
      const m = t.slice(0, 7);
      if (m !== ly) out += `${i ? `<line x1="${x(i)}" x2="${x(i)}" y1="${padT}" y2="${H - padB}" stroke="var(--line-soft)"/>` : ""}<text x="${x(i) + 2}" y="${H - 6}" class="ax">${MON[+t.slice(5, 7) - 1]}</text>`;
      ly = m;
    });
    else cv.t.forEach((t, i) => {
      if (t.slice(0, 4) !== ly && i > 0) {
        const miss = (cv.gaps || []).filter((g) => g > +ly && g < +t.slice(0, 4));
        if (miss.length) out += `<line x1="${x(i) - 3}" x2="${x(i) - 3}" y1="${padT}" y2="${H - padB}" stroke="var(--muted)" stroke-dasharray="2 4"/><text x="${x(i) - 6}" y="${padT + 10}" class="ax" text-anchor="end">${miss.join(", ")} left out</text>`;
        out += `<text x="${x(i)}" y="${H - 6}" class="ax" text-anchor="middle">${t.slice(0, 4)}</text>`;
      }
      ly = t.slice(0, 4);
    });
    const ends = [];
    series.forEach((s) => {
      out += `<path d="${s.v.map((v, i) => (v == null ? "" : (i && s.v[i - 1] != null ? "L" : "M") + x(i).toFixed(1) + " " + y(v).toFixed(1))).join("")}" fill="none" stroke="${s.col}" stroke-width="${s.k === "Strategy" ? 2.4 : 1.6}" ${s.k === "Strategy" ? "" : 'opacity=".9"'}/>`;
      const last = [...s.v].reverse().find((v) => v != null);
      if (last != null) ends.push({ y: y(last), k: s.k, col: s.col, v: last });
    });
    ends.sort((a, b) => a.y - b.y);
    ends.forEach((e, i) => { if (i && e.y - ends[i - 1].y < 13) e.y = ends[i - 1].y + 13; out += `<text x="${W - padR + 52}" y="${e.y + 4}" class="ax" fill="var(--text)" style="font-weight:600"><tspan fill="${e.col}">●</tspan> ${e.k}</text>`; });
    return `<svg viewBox="0 0 ${W} ${H}" class="qchart" role="img" aria-label="Portfolio value vs benchmarks">${out}</svg>`;
  }

  /* =====================================================================
     BACKTEST: every pullback to the 150/200 EMA and what happened next
     ===================================================================== */
  const HZ = [["5", "1 week"], ["20", "1 month"], ["60", "3 months"], ["120", "6 months"], ["252", "1 year"]];
  P.bt = { ticker: "", data: null, params: null, group: "all", loading: false };

  function btDefaults() {
    const inv = (S.state.profiles || []).find((x) => x.id === "investing") || {};
    const rp = ((inv.rules || {}).ma_touch || {}).params || {};
    return { mode: "touch", kind: inv.ma_type || "EMA", fast: inv.fast || 150, slow: inv.slow || 200,
             tolerance: rp.tolerance ?? 0.5, above_days: rp.above_days ?? 15, hold: rp.hold ?? true, cooldown: 10,
             side: { "From below (rally into resistance)": "below", "Both": "both" }[rp.side] || "above" };
  }

  function renderBacktest() {
    const root = $("#backtestBody"), B = P.bt;
    if (!B.params) B.params = btDefaults();
    if (!B.ticker) B.ticker = P.chart.ticker || (S.state.watchlist || [])[0] || "AAPL";
    const p = B.params, c = caps();
    root.innerHTML = `
      <div class="pg-head"><h1>Backtest</h1>${tickerForm("btForm", B.ticker, "Ticker", "Run")}
        <span class="muted small">Every time it came back to the ${esc(p.kind)} ${p.fast}/${p.slow}, and what happened next</span></div>
      ${c.bars ? "" : needBox("Backtests", capSrc("bars"))}
      <form class="card bt-set" id="btSet">
        <label>Find<select name="mode"><option value="touch" ${p.mode === "touch" ? "selected" : ""}>Pullbacks that touch a line (uptrend)</option>
          <option value="zone" ${p.mode === "zone" ? "selected" : ""}>Closes between the two lines (any trend)</option></select></label>
        <label>Average<select name="kind"><option ${p.kind === "EMA" ? "selected" : ""}>EMA</option><option ${p.kind === "SMA" ? "selected" : ""}>SMA</option></select></label>
        <label>Fast<input type="number" name="fast" min="2" max="400" value="${p.fast}"></label>
        <label>Slow<input type="number" name="slow" min="2" max="400" value="${p.slow}"></label>
        <label class="touch-only">Touch from<select name="side">${[["above", "Above: pullback to support"], ["below", "Below: rally into resistance"], ["both", "Both"]].map(([k, l]) => `<option value="${k}" ${(p.side || "above") === k ? "selected" : ""}>${l}</option>`).join("")}</select></label>
        <label class="touch-only">Touch within<span class="unit-in"><input type="number" name="tolerance" step="0.1" min="0" max="5" value="${p.tolerance}">%</span></label>
        <label class="touch-only" title="Support tests: closed above both lines. Resistance tests: closed below the line.">Trend before<span class="unit-in"><input type="number" name="above_days" min="0" max="20" value="${p.above_days}">of 20 days</span></label>
        <label class="touch-only chk"><input type="checkbox" name="hold" ${p.hold ? "checked" : ""}> Close held the line</label>
        <label>New event after<span class="unit-in"><input type="number" name="cooldown" min="1" max="60" value="${p.cooldown}">days</span></label>
        <div class="sb-sup touch-only" style="width:100%"><span class="muted small">Only count touches with:</span>
          ${SUP_SIGNALS.filter(([k]) => k !== "no_repeat").map(([k, l]) => `<label class="chk"><input type="checkbox" name="req_${k}" ${(p.require || []).includes(k) ? "checked" : ""}> ${l}</label>`).join("")}</div>
        <div class="bt-btns"><button type="button" class="btn ghost" id="btReset">Use Investing strategy settings</button><button class="btn primary">Run</button></div>
      </form>
      <div id="btInner"></div>`;
    bindGo(root);
    const set = $("#btSet");
    const sync = () => $$(".touch-only", set).forEach((x) => (x.hidden = set.mode.value !== "touch"));
    set.mode.onchange = sync; sync();
    const read = () => ({ mode: set.mode.value, kind: set.kind.value, fast: +set.fast.value, slow: +set.slow.value,
      tolerance: +set.tolerance.value, above_days: +set.above_days.value, hold: set.hold.checked, cooldown: +set.cooldown.value, side: set.side.value,
      require: SUP_SIGNALS.map(([k]) => k).filter((k) => set["req_" + k] && set["req_" + k].checked) });
    set.onsubmit = (e) => { e.preventDefault(); B.params = read(); loadBacktest(B.ticker); };
    $("#btReset").onclick = () => { B.params = btDefaults(); renderBacktest(); };
    $("#btForm").onsubmit = (e) => { e.preventDefault(); B.params = read(); loadBacktest(cleanT(e.target.t.value)); };
    if (B.data && B.data.ticker === B.ticker) drawBacktest();
    else if (c.bars) loadBacktest(B.ticker);
  }

  async function loadBacktest(t) {
    if (!t) return;
    const B = P.bt;
    B.ticker = t;
    const f = $("#btForm"); if (f) f.t.value = t;
    const el = $("#btInner");
    if (el) el.innerHTML = `<div class="loading">${ic("refresh", 18)} Going through ${esc(t)}'s daily history…</div>`;
    const r = await call("run_backtest", t, B.params);
    B.data = r && r.ok ? r : { ticker: t, error: (r && r.error) || "Backtest failed" };
    if (S.page === "backtest" && B.ticker === t) drawBacktest();
  }

  function drawBacktest() {
    const B = P.bt, d = B.data, el = $("#btInner");
    if (!el) return;
    if (d.error) { el.innerHTML = `<div class="err">${esc(d.error)}</div>`; return; }
    const groups = Object.keys(d.summary);
    if (!groups.includes(B.group)) B.group = groups[0] || "all";
    const sm = d.summary[B.group];
    const F_ = `${d.params.kind} ${d.params.fast}`, S_ = `${d.params.kind} ${d.params.slow}`;
    const label = (k) => ({ all: "All", fast: F_, slow: S_, zone: "Between the lines", support: "Support tests", resistance: "Resistance tests",
      fast_support: F_ + " support", slow_support: S_ + " support", fast_resistance: F_ + " resistance", slow_resistance: S_ + " resistance" }[k] || k);
    const side = d.params.side || "above";
    const what = side === "below" ? "rallies into the line" : side === "both" ? "tests" : "pullbacks";
    const per = `${parseDay(d.period.start).toLocaleDateString(undefined, { month: "short", year: "numeric" })} – ${parseDay(d.period.end).toLocaleDateString(undefined, { month: "short", year: "numeric" })}`;
    const pc = (v, colour = true) => (v == null ? `<span class="muted">–</span>` : `<span class="${colour ? cls(v) : ""}">${v > 0 ? "+" : ""}${fmt(v, 1)}%</span>`);
    let html = "";
    if (!d.events.length) {
      html = `<div class="empty"><p><b>No ${d.params.mode === "zone" ? "visits to the zone" : what} found for ${esc(d.ticker)} in ${per}.</b></p>
        <p class="muted">It either never came back to the lines while trending up, or it spent the period below them. Try a wider touch % or fewer required days above the lines.</p></div>`;
    } else {
      const counts = d.params.mode === "zone" ? `${d.events.length} visits` :
        `${d.events.length} ${what} · ${(d.summary.fast || {}).count || 0} at the ${d.params.fast} · ${(d.summary.slow || {}).count || 0} at the ${d.params.slow}`;
      html += `<div class="bt-head"><div><div class="bt-big num">${counts}</div><div class="muted small">${per} · daily prices from Public (5 years; the first ${d.params.slow} days warm up the averages)</div></div>
        ${groups.length > 1 ? `<div class="seg" id="btGroup">${groups.map((g) => `<button data-g="${g}" class="${g === B.group ? "on" : ""}">${esc(label(g))}</button>`).join("")}</div>` : ""}</div>
        <div class="bt-cards">${HZ.map(([h, l]) => {
          const x = sm.horizons[h], b = d.baseline[h];
          return `<div class="bt-card"><div class="muted small">After ${l}</div>
            <div class="bt-win num">${x.win == null ? "–" : fmt(x.win, 0) + "%"}<span class="muted small"> up</span></div>
            <div class="small">avg ${pc(x.avg)} · median ${pc(x.median)}</div>
            <div class="small muted">best ${pc(x.best, false)} · worst ${pc(x.worst, false)} · ${x.n} trades</div>
            <div class="small bt-base">any day: ${b.win == null ? "–" : fmt(b.win, 0) + "% up"}, avg ${pc(b.avg, false)}</div></div>`;
        }).join("")}</div>
        <div class="bt-risk muted small">Next 60 days on average: deepest drop ${pc(sm.avg_max_drop_60)}, highest gain ${pc(sm.avg_max_gain_60)}.
          ${side === "above" && sm.broke_rate != null ? `Closed more than 3% below the ${d.params.slow} line within a month: <b>${fmt(sm.broke_rate, 0)}%</b> of the time.` : ""}</div>`;
      if ((d.require || []).length) html += `<div class="sb-note card"><b>Filtered:</b> <span class="muted">${d.events.length} of ${d.events_before_filter} touches had ${d.require.map((k) => esc((SUP_SIGNALS.find((x) => x[0] === k) || [k, k])[1].toLowerCase())).join(" + ")}.</span></div>`;
      if (d.signal_table) {
        const hr_ = (x) => (x.held_rate == null ? "–" : fmt(x.held_rate, 0) + "%");
        html += `<div class="card"><h3>Which signals came before a hold? <span class="muted small">every touch of ${esc(d.ticker)} (before filters) · held = no close more than ${d.params.held_pct}% through the line in ${d.params.held_days} days</span></h3>
          <div class="table-wrap"><table class="res gx-tbl"><thead><tr><th>On the touch day</th><th class="r">Held when ON</th><th class="r">Held when OFF</th><th class="r">Difference</th><th class="r">1 month ON</th><th class="r">1 month OFF</th></tr></thead><tbody>
          ${d.signal_table.map((x) => `<tr><td>${esc(x.label)}</td><td class="r num">${hr_(x.with)} <span class="muted small">${x.with.held_n}</span></td><td class="r num">${hr_(x.without)} <span class="muted small">${x.without.held_n}</span></td>
            <td class="r num ${x.edge >= 10 ? "pos" : x.edge <= -10 ? "neg" : "muted"}">${x.edge == null ? "–" : (x.edge > 0 ? "+" : "") + fmt(x.edge, 0) + " pts"}</td><td class="r num">${pc(x.with.avg)}</td><td class="r num">${pc(x.without.avg)}</td></tr>`).join("")}</tbody></table></div>
          <p class="muted small">One stock has only a handful of touches, so treat this as a hint. The Strategy Test runs the same table across every stock.</p></div>`;
      }
      if (d.params.mode !== "zone") {
        const hr = (g) => d.summary[g] && d.summary[g].held_rate != null ? d.summary[g] : null;
        const rows_ = side === "both" ? ["fast_support", "slow_support", "fast_resistance", "slow_resistance"] : ["fast", "slow"];
        const verdict = (r) => (r >= 70 ? `<span class="pos">strong</span>` : r >= 45 ? `<span class="warn-t">mixed</span>` : `<span class="neg">weak</span>`);
        html += `<div class="card bt-held"><h3>Does the line actually hold? <span class="muted small">${side === "below" ? "resistance" : side === "both" ? "support and resistance" : "support"}: held = no close more than ${d.params.held_pct}% through the line within ${d.params.held_days} trading days</span></h3>
          <div class="bt-held-grid">${rows_.filter(hr).map((g) => { const x = d.summary[g]; const res = side === "below" || g.endsWith("resistance");
            return `<div class="bt-held-row"><b>${esc(label(g.replace("_support", "").replace("_resistance", "")))}</b> as ${res ? "resistance" : "support"}: ${verdict(x.held_rate)}
              <div class="bt-big num">${fmt(x.held_rate, 0)}%</div><div class="muted small">${res ? "turned price back" : "held"} ${Math.round(x.held_rate * x.held_n / 100)} of ${x.held_n} times · avg 1 month after ${pc(x.horizons["20"].avg)}</div></div>`; }).join("") || `<p class="muted">Not enough finished tests yet.</p>`}</div></div>`;
      }
      html += `<div class="chart-card bt-chart">${btChart(d)}<div class="seg-legend"><span class="key"><i style="background:var(--text)"></i>Price</span>
        <span class="key"><i style="background:var(--fast)"></i>${esc(d.params.kind)} ${d.params.fast}</span><span class="key"><i style="background:var(--slow)"></i>${esc(d.params.kind)} ${d.params.slow}</span>
        ${side !== "below" ? `<span class="key"><i class="dot-k" style="background:var(--pass)"></i>Pullback (green = up after 3 months, red = down)</span>` : ""}
        ${side !== "above" ? `<span class="key"><i class="dot-k" style="background:var(--fail);border-radius:0"></i>▼ Test from below (red = rejected, green = broke through)</span>` : ""}</div></div>`;
      const evs = d.events.slice().reverse();
      html += `<div class="card"><h3>Every ${d.params.mode === "zone" ? "visit" : side === "above" ? "pullback" : "test"} <span class="muted small">newest first · click to open the chart</span></h3>
        <div class="table-wrap"><table class="res bt-tbl"><thead><tr><th>Date</th><th>Line</th><th class="r">Price</th>${HZ.map(([, l]) => `<th class="r">${l}</th>`).join("")}
          <th class="r">Worst drop 60d</th><th class="r">Best gain 60d</th><th>Support signals</th></tr></thead>
        <tbody>${evs.map((e) => `<tr data-d="${e.date}"><td class="num">${esc(parseDay(e.date).toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" }))}</td>
          <td><span class="line-pill ${e.line}">${esc(label(e.line))}</span>${e.side === "below" ? ` <span class="tag res" style="margin-left:4px">from below</span>` : ""}${e.held === true ? ` <span class="pos small">${e.side === "below" ? "rejected" : "held"}</span>` : e.held === false ? ` <span class="neg small">${e.side === "below" ? "broke through" : "broke"}</span>` : ""}</td>
          <td class="r num">$${fmt(e.price)}</td>${HZ.map(([h]) => `<td class="r num">${pc(e.returns[h])}</td>`).join("")}
          <td class="r num">${pc(e.max_drop_60)}</td><td class="r num">${pc(e.max_gain_60)}</td>
          <td class="small">${e.signals ? SUP_SIGNALS.filter(([k]) => k in e.signals).map(([k, l]) => `<span class="sig ${e.signals[k] ? "on" : ""}" title="${esc(l)}">${{ light_pullback: "LV", strong_close: "SC", absorption: "AB", accumulation: "AC", respected: "HB" }[k]}</span>`).join("") : ""}</td></tr>`).join("")}</tbody></table></div>
        <p class="muted small">Signals: LV light-volume pullback · SC closed strong · AB heavy volume but held · AC accumulation · HB line held before. Lit = on that day.</p>
        <p class="muted small">Returns are close-to-close from the day of the pullback, before fees and without stops or dividends. Blank = not enough time has passed yet. Past behaviour doesn't guarantee the next one.</p></div>`;
    }
    el.innerHTML = html;
    $$("#btGroup button", el).forEach((b) => (b.onclick = () => { B.group = b.dataset.g; drawBacktest(); }));
    $$(".bt-tbl tbody tr", el).forEach((tr) => (tr.onclick = () => { P.chart.ticker = d.ticker; P.chart.data = null; P.chart.focus = tr.dataset.d; show("charts"); }));
  }

  function btChart(d) {
    const ch = d.chart, W = 1100, H = 300, padT = 10, padB = 22, padR = 60;
    const all = ch.c.concat(ch.f, ch.s).filter((v) => v != null);
    let max = Math.max(...all), min = Math.min(...all);
    const pad = (max - min) * 0.05; max += pad; min -= pad;
    const n = ch.t.length;
    const x = (i) => 4 + (i / Math.max(1, n - 1)) * (W - padR - 8);
    const y = (v) => padT + ((max - v) / (max - min)) * (H - padT - padB);
    const path = (arr) => arr.map((v, i) => (v == null ? "" : (i && arr[i - 1] != null ? "L" : "M") + x(i).toFixed(1) + " " + y(v).toFixed(1))).join("");
    let out = "";
    const step = niceStep((max - min) / 5);
    for (let v = Math.ceil(min / step) * step; v <= max; v += step) out += `<line x1="0" x2="${W - padR}" y1="${y(v)}" y2="${y(v)}" stroke="var(--line-soft)"/><text x="${W - padR + 6}" y="${y(v) + 4}" class="ax">${fmt(v, v >= 100 ? 0 : 2)}</text>`;
    let ly = "";
    ch.t.forEach((t, i) => { if (t.slice(0, 4) !== ly && i > 0) out += `<text x="${x(i)}" y="${H - 5}" class="ax" text-anchor="middle">${t.slice(0, 4)}</text>`; ly = t.slice(0, 4); });
    out += `<path d="${path(ch.s)}" fill="none" stroke="var(--slow)" stroke-width="1.6"/><path d="${path(ch.f)}" fill="none" stroke="var(--fast)" stroke-width="1.6"/>
      <path d="${path(ch.c)}" fill="none" stroke="var(--text)" stroke-width="1.2" opacity=".85"/>`;
    const pos = (date) => { let lo = 0, hi = n - 1; while (lo < hi) { const m = (lo + hi) >> 1; if (ch.t[m] < date) lo = m + 1; else hi = m; } return lo; };
    d.events.forEach((e) => {
      const r = e.returns["60"], col = r == null ? "var(--muted)" : r >= 0 ? "var(--pass)" : "var(--fail)";
      out += e.side === "below" ? `<path d="M${x(pos(e.date)) - 5} ${y(e.price) - 4} L${x(pos(e.date)) + 5} ${y(e.price) - 4} L${x(pos(e.date))} ${y(e.price) + 5} Z" fill="${e.held === false ? "var(--pass)" : e.held ? "var(--fail)" : "var(--muted)"}" stroke="var(--panel)" stroke-width="1.2"><title>${e.date} · tested the ${e.line === "fast" ? d.params.fast : d.params.slow} from below · ${e.held ? "rejected" : e.held === false ? "broke through" : "too recent"}</title></path>` :
        `<circle cx="${x(pos(e.date))}" cy="${y(e.price)}" r="5" fill="${col}" stroke="var(--panel)" stroke-width="1.5"><title>${e.date} · ${e.line === "fast" ? d.params.fast : e.line === "slow" ? d.params.slow : "zone"} · $${fmt(e.price)} · 3 months later ${r == null ? "n/a" : (r > 0 ? "+" : "") + fmt(r, 1) + "%"}</title></circle>`;
    });
    return `<svg viewBox="0 0 ${W} ${H}" class="qchart" role="img" aria-label="Price with pullbacks marked">${out}</svg>`;
  }

  /* =====================================================================
     RESEARCH: 14 data points, every quarter for up to 10 years
     ===================================================================== */
  const QR = [["2Y", 8], ["5Y", 20], ["10Y", 40]];
  const METRICS = [
    { id: "price", name: "Stock price", src: "valuation", val: (h, v) => v && v.price, f: (x) => "$" + fmt(x), kind: "line", color: "--text" },
    { id: "revenue", name: "Revenue", val: (h) => h.metrics.revenue, f: big },
    { id: "segments", name: "Revenue by segment", special: "segments" },
    { id: "ebitda", name: "EBITDA", val: (h) => h.metrics.ebitda, f: big, note: "Operating income + depreciation & amortization" },
    { id: "gross_profit", name: "Gross profit", val: (h) => h.metrics.gross_profit, f: big },
    { id: "gross_margin", name: "Gross profit margin", val: (h) => h.metrics.gross_margin, f: (x) => fmt(x, 1) + "%", kind: "line", color: "--pass", noYoY: true },
    { id: "net_income", name: "Net income", val: (h) => h.metrics.net_income, f: big },
    { id: "ocf", name: "Cash from operations", val: (h) => h.metrics.ocf, f: big },
    { id: "fcf", name: "Free cash flow", val: (h) => h.metrics.fcf, f: big, note: "Cash from operations − capital expenditure" },
    { id: "eps", name: "Earnings per share (diluted)", val: (h) => h.metrics.eps, f: (x) => "$" + fmt(x) },
    { id: "capex", name: "Capital expenditure", val: (h) => h.metrics.capex, f: big, color: "--fast" },
    { id: "cashdebt", name: "Cash and debt", special: "cashdebt" },
    { id: "pe", name: "Price to earnings (P/E)", src: "valuation", val: (h, v) => v && v.pe, f: (x) => fmt(x, 1) + "×", kind: "line", color: "--fast", noYoY: true, note: "Quarter-end price ÷ trailing 4-quarter EPS. Blank when earnings were negative." },
    { id: "ps", name: "Price to sales (P/S)", src: "valuation", val: (h, v) => v && v.ps, f: (x) => fmt(x, 1) + "×", kind: "line", color: "--slow", noYoY: true, note: "Market cap ÷ trailing 4-quarter revenue" },
  ];

  function qKey(end) {
    const d = parseDay(end); d.setDate(d.getDate() - 15);
    return `${d.getFullYear()}-Q${Math.floor(d.getMonth() / 3) + 1}`;
  }
  function qShort(end) {
    const d = parseDay(end);
    return isNaN(d) ? end : d.toLocaleDateString(undefined, { month: "short" }) + " '" + String(d.getFullYear()).slice(2);
  }

  /* Bar/line chart over quarters. series: [{name, values, color, kind}] */
  function qChart(labels, series, f, opts = {}) {
    const W = 560, H = 190, padT = 14, padB = 24, padL = 4, padR = 58;
    const n = labels.length;
    if (!n) return `<div class="muted small nodata">No data</div>`;
    const all = [];
    series.forEach((s) => s.values.forEach((v) => v != null && isFinite(v) && all.push(v)));
    if (opts.stacked) labels.forEach((_, i) => all.push(series.reduce((a, s) => a + (s.values[i] > 0 ? s.values[i] : 0), 0)));
    if (!all.length) return `<div class="muted small nodata">No data reported for these quarters</div>`;
    const anyBar = series.some((s) => s.kind !== "line");
    let max = Math.max(...all), min = Math.min(...all);
    if (anyBar) { max = Math.max(0, max); min = Math.min(0, min); }
    const pad = (max - min) * 0.08 || Math.abs(max) * 0.1 || 1;
    if (!anyBar || min < 0) min -= pad;
    max += pad;
    const y = (v) => padT + ((max - v) / (max - min)) * (H - padT - padB);
    const slot = (W - padL - padR) / n, cx = (i) => padL + slot * i + slot / 2;
    const bars = series.filter((s) => s.kind !== "line"), lines = series.filter((s) => s.kind === "line");
    let out = "";
    const step = niceStep((max - min) / 4);
    for (let v = Math.ceil(min / step) * step; v <= max; v += step) {
      out += `<line x1="${padL}" x2="${W - padR}" y1="${y(v)}" y2="${y(v)}" stroke="var(--line-soft)"/>
        <text x="${W - padR + 6}" y="${y(v) + 4}" class="ax">${esc(f(v))}</text>`;
    }
    if (anyBar && min < 0) out += `<line x1="${padL}" x2="${W - padR}" y1="${y(0)}" y2="${y(0)}" stroke="var(--muted)" stroke-width=".8"/>`;
    const every = Math.ceil(n / 8);
    labels.forEach((l, i) => {
      if ((n - 1 - i) % every === 0) out += `<text x="${cx(i)}" y="${H - 6}" text-anchor="middle" class="ax">${esc(qShort(l))}</text>`;
    });
    if (opts.stacked) {
      labels.forEach((l, i) => {
        let acc = 0;
        const w = slot * 0.66;
        bars.forEach((s) => {
          const v = s.values[i];
          if (v == null || v <= 0) return;
          const top = y(acc + v), h = y(acc) - top;
          out += `<rect x="${cx(i) - w / 2}" y="${top}" width="${w}" height="${Math.max(0.5, h)}" fill="${s.color}"><title>${esc(qShort(l))} · ${esc(s.name)}: ${esc(f(v))}</title></rect>`;
          acc += v;
        });
      });
    } else if (bars.length) {
      const groupW = slot * 0.72, w = groupW / bars.length;
      bars.forEach((s, k) => {
        s.values.forEach((v, i) => {
          if (v == null || !isFinite(v)) return;
          const top = Math.min(y(v), y(0)), h = Math.max(1, Math.abs(y(v) - y(0)));
          const fill = s.colorNeg && v < 0 ? s.colorNeg : s.color;
          out += `<rect x="${cx(i) - groupW / 2 + k * w + 0.5}" y="${top}" width="${Math.max(1, w - 1)}" height="${h}" rx="1.5" fill="${fill}" opacity="${(opts.derived || [])[i] ? 0.6 : 0.95}"><title>${esc(qShort(labels[i]))}${bars.length > 1 ? " · " + esc(s.name) : ""}: ${esc(f(v))}${(opts.derived || [])[i] ? " (Q4 worked out from the annual report)" : ""}</title></rect>`;
        });
      });
    }
    lines.forEach((s) => {
      let d = "", started = false;
      s.values.forEach((v, i) => {
        if (v == null || !isFinite(v)) { started = false; return; }
        d += (started ? "L" : "M") + cx(i).toFixed(1) + " " + y(v).toFixed(1);
        started = true;
      });
      out += `<path d="${d}" fill="none" stroke="${s.color}" stroke-width="2" stroke-linejoin="round"/>`;
      s.values.forEach((v, i) => {
        if (v == null || !isFinite(v)) return;
        out += `<circle cx="${cx(i)}" cy="${y(v)}" r="${n > 24 ? 2 : 3}" fill="${s.color}"><title>${esc(qShort(labels[i]))}${series.length > 1 ? " · " + esc(s.name) : ""}: ${esc(f(v))}</title></circle>`;
      });
    });
    return `<svg viewBox="0 0 ${W} ${H}" class="qchart" role="img" aria-label="${esc(opts.label || "Quarterly chart")}">${out}</svg>`;
  }

  function lastVal(arr) { for (let i = arr.length - 1; i >= 0; i--) if (arr[i] != null) return [arr[i], i]; return [null, -1]; }

  function renderResearch() {
    const root = $("#researchBody");
    const R = P.research;
    if (!R.ticker) R.ticker = (S.state.watchlist || [])[0] || "AAPL";
    const c = caps();
    root.innerHTML = `
      <div class="pg-head">
        <h1>Research</h1>
        ${tickerForm("resForm", R.ticker, "Ticker")}
        <div class="seg" id="resRange">${QR.map(([l, n]) => `<button data-n="${n}" class="${R.range === n ? "on" : ""}">${l}</button>`).join("")}</div>
        <button class="btn ghost" id="resChart">${ic("charts")} Chart</button>
        <button class="btn ghost" id="resCompare">${ic("compare")} Compare</button>
      </div>
      ${c.history ? "" : needBox("Research", capSrc("history"))}
      <div id="resInner"></div>`;
    bindGo(root);
    $("#resForm").onsubmit = (e) => { e.preventDefault(); loadResearch(cleanT(e.target.t.value)); };
    $$("#resRange button").forEach((b) => (b.onclick = () => { R.range = +b.dataset.n; renderResearch(); }));
    $("#resChart").onclick = () => { P.chart.ticker = R.ticker; P.chart.data = null; show("charts"); };
    $("#resCompare").onclick = () => { P.compare.tickers = [R.ticker, "", "", ""]; P.compare.data = null; show("compare"); };
    if (R.data && R.data.ticker === R.ticker) drawResearch();
    else if (c.history || c.valuation_history) loadResearch(R.ticker);
  }

  async function loadResearch(t) {
    if (!t) return;
    const R = P.research;
    R.ticker = t;
    const inner = $("#resInner");
    if (inner) inner.innerHTML = `<div class="loading">${ic("refresh", 18)} Loading ten years of filings for ${esc(t)}…</div>`;
    const r = await call("get_research", t, true);
    R.data = r && r.ok ? r : { ticker: t, error: (r && r.error) || "Couldn't load", history: null, unavailable: {}, errors: {} };
    if (P.research.ticker === t && S.page === "research") drawResearch();
  }

  function drawResearch() {
    const R = P.research, d = R.data, inner = $("#resInner");
    if (!inner) return;
    if (d.error) { inner.innerHTML = `<div class="err">${esc(d.error)}</div>`; return; }
    const h = d.history, v = d.valuation;
    const errs = Object.entries(d.errors || {}).map(([k, m]) => `<div class="err"><b>${esc(k)}:</b> ${esc(m)}</div>`).join("");
    if (!h) { inner.innerHTML = errs || `<div class="empty"><p>No quarterly filings found for ${esc(d.ticker)}.</p></div>`; return; }
    const n = Math.min(R.range, h.quarters.length), s = h.quarters.length - n;
    const labels = h.quarters.slice(s);
    const derived = h.quarters.slice(s).map((q) => (h.derived_q4 || []).includes(q));
    const q = d.quote || {};
    const m = h.metrics;
    const ttm = (arr) => { const xs = arr.slice(-4); return xs.length === 4 && xs.every((x) => x != null) ? xs.reduce((a, b) => a + b, 0) : null; };
    const [mcShares] = lastVal(m.shares || []);
    const price = q.last || (v && lastVal(v.price || [])[0]);
    const mcap = price && mcShares ? price * mcShares : null;
    const revT = ttm(m.revenue), epsT = ttm(m.eps), fcfT = ttm(m.fcf);
    const dayChg = q.last && q.prev_close ? (q.last / q.prev_close - 1) * 100 : null;
    let html = researchHeader(d, { price, mcap, revT, shares: mcShares, dayChg }) + errs +
      researchStats(d) + `<h2 class="sec-h">Quarterly financials</h2><div class="metric-grid">`;
    const colorOf = (name) => `var(${name})`;
    for (const M of METRICS) {
      let body = "", head = "";
      if (M.special === "segments") {
        if (d.unavailable && d.unavailable.segments) { html += unavailableCard(M.name, d.unavailable.segments); continue; }
        const segs = (d.segments || []).slice().reverse();
        if (!segs.length) { html += `<div class="mcard"><div class="mc-h"><h3>${M.name}</h3></div><div class="muted small nodata">${d.errors && d.errors.segments ? esc(d.errors.segments) : "No segment breakdown reported"}</div></div>`; continue; }
        const use = segs.slice(-n);
        const names = [];
        use.forEach((r) => r.segments.forEach((x) => !names.includes(x.label) && names.push(x.label)));
        const palette = ["#9A8CFF", "#F2A93B", "#2BD47D", "#4FC3F7", "#FF7AB6", "#F5C451", "#8A8A8E", "#FF5A5F"];
        const series = names.slice(0, 8).map((nm, i) => ({ name: nm, color: palette[i], values: use.map((r) => { const f = r.segments.find((x) => x.label === nm); return f ? f.value : null; }) }));
        body = qChart(use.map((r) => r.end), series, big, { stacked: true, label: M.name }) +
          `<div class="seg-legend">${series.map((s) => `<span class="key"><i style="background:${s.color}"></i>${esc(s.name)}</span>`).join("")}</div>`;
        head = `<span class="muted small">by ${esc(use[use.length - 1].breakdown || "segment")}</span>`;
      } else if (M.special === "cashdebt") {
        const cash = m.cash.slice(s), debt = m.debt.slice(s);
        body = qChart(labels, [{ name: "Cash", values: cash, color: colorOf("--pass") }, { name: "Debt", values: debt, color: colorOf("--fail") }], big, { label: M.name }) +
          `<div class="seg-legend"><span class="key"><i style="background:var(--pass)"></i>Cash</span><span class="key"><i style="background:var(--fail)"></i>Debt</span></div>`;
        const [c1] = lastVal(cash), [d1] = lastVal(debt);
        head = `<span class="num mc-v">${big(c1)} / ${big(d1)}</span>`;
      } else {
        if (M.src === "valuation" && !v) {
          if (d.unavailable && d.unavailable.valuation) { html += unavailableCard(M.name, d.unavailable.valuation); continue; }
        }
        const vals = (M.val(h, v) || []).slice(s);
        const [lv, li] = lastVal(vals);
        let yoy = null;
        if (!M.noYoY && li >= 4 && vals[li - 4] != null && vals[li - 4] !== 0) yoy = (lv - vals[li - 4]) / Math.abs(vals[li - 4]) * 100;
        head = `<span class="num mc-v">${lv == null ? "–" : esc(M.f(lv))}</span>${yoy != null ? `<span class="small ${cls(yoy)}">${pct(yoy)} YoY</span>` : ""}`;
        body = qChart(labels, [{ name: M.name, values: vals, color: colorOf(M.color || "--slow"), colorNeg: "var(--fail)", kind: M.kind }], M.f, { derived, label: M.name });
      }
      html += `<div class="mcard"><div class="mc-h"><h3>${esc(M.name)}</h3>${head}</div>${body}${M.note ? `<div class="muted small">${esc(M.note)}</div>` : ""}</div>`;
    }
    html += `</div><p class="muted small">Quarterly figures from SEC filings${d.segments ? ", segments from Financial Datasets" : ""}. Faded bars are fourth quarters worked out from the annual report minus the first three quarters.</p>`;
    inner.innerHTML = html;
    bindGo(inner);
    $$("[data-url]", inner).forEach((a) => (a.onclick = (e) => { e.preventDefault(); call("open_url", a.dataset.url); }));
  }

  /* Company header and Statistics (TTM), like a fundamentals site's summary page */
  function researchHeader(d, fb) {
    const st = d.stats || {}, p = st.profile || {}, c = caps();
    const price = p.price ?? fb.price, chg = p.change_pct ?? fb.dayChg;
    const row = (k, v) => `<div class="kv"><span>${esc(k)}</span><b class="num">${v}</b></div>`;
    const need = (src) => `<span class="muted small">Needs ${esc(src)}</span>`;
    const site = p.website ? `<a href="#" data-url="${esc(/^https?:/.test(p.website) ? p.website : "https://" + p.website)}">${esc(p.website.replace(/^https?:\/\//, ""))} ${ic("external", 12)}</a>` : "–";
    const nextE = p.next_earnings_date ? esc(parseDay(p.next_earnings_date).toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" }))
      : c.next_earnings_date ? "–" : need(capSrc("next_earnings_date"));
    const chgAbs = p.change != null ? `${p.change >= 0 ? "+" : "-"}$${fmt(Math.abs(p.change))} ` : "";
    return `<div class="co-card">
      <div class="co-top">
        <div><div class="co-name">${esc(p.name || d.ticker)}</div>
          <div class="co-sub"><span class="tk-pill">${esc(d.ticker)}</span>${p.exchange ? `<span class="muted">${esc(p.exchange)}</span>` : ""}
            ${p.sector ? `<span class="sector-pill">${esc(p.sector)}</span>` : ""}${p.industry ? `<span class="muted">${esc(p.industry)}</span>` : ""}</div></div>
        <div class="co-price"><div class="num">${price ? "$" + fmt(price) : "–"}</div><div class="${cls(chg)} num">${chgAbs}${chg != null ? "(" + pct(chg, 2) + ")" : ""} <span class="muted small">today</span></div></div>
      </div>
      <div class="kv-cols"><div>
        ${row("Market cap", big(p.market_cap ?? fb.mcap))}${row("Sector", esc(p.sector || "–"))}${row("Industry", esc(p.industry || "–"))}
        ${row("Website", site)}${row("Revenue (TTM)", big(p.revenue_ttm ?? fb.revT))}${row("Shares outstanding", p.shares || fb.shares ? fmt((p.shares || fb.shares) / 1e9, 2) + "B" : "–")}
      </div><div>
        ${row("Current share price", price ? "$" + fmt(price) : "–")}
        ${row("Today's change", `<span class="chg-pill ${cls(chg)}">${chgAbs || "–"}</span>`)}
        ${row("After-hours price", p.after_hours != null ? "$" + fmt(p.after_hours) + ` <span class="${cls(p.after_hours - price)} small">${pct((p.after_hours / price - 1) * 100, 2)}</span>` : `<span class="muted small">None right now</span>`)}
        ${row("52-week range", p.low_52w != null ? "$" + fmt(p.low_52w) + " – $" + fmt(p.high_52w) : "–")}
        ${row("Next earnings date", nextE)}
        ${row("Last earnings report", p.last_earnings_date ? esc(parseDay(p.last_earnings_date).toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" })) : "–")}
      </div></div></div>`;
  }
  function statVal(r) {
    if (r.needs && !caps()[r.needs]) return `<span class="muted small">Needs ${esc(capSrc(r.needs))}</span>`;
    const v = r.value;
    if (v == null || (typeof v === "number" && !isFinite(v))) return "–";
    switch (r.fmt) {
      case "x": return fmt(v, 2) + "×";
      case "%": return `<span class="${r.label.startsWith("Revenue") || r.label.startsWith("EPS") ? cls(v) : ""}">${fmt(v, 2)}%</span>`;
      case "$": return "$" + fmt(v, 2);
      case "big": return big(v);
      default: return esc(v);
    }
  }
  function cagrCard(rows) {
    rows = (rows || []).filter((r) => Object.values(r.values).some((v) => v != null));
    if (!rows.length) return "";
    const yrs = ["1", "3", "5", "10"];
    const cell = (v) => (v == null ? `<td class="r muted">–</td>` : `<td class="r num"><span class="${cls(v)}">${v > 0 ? "+" : ""}${fmt(v, 1)}%</span></td>`);
    return `<div class="stat-card cagr-card"><h3>Growth (CAGR)</h3>
      <table class="cagr"><thead><tr><th></th>${yrs.map((y) => `<th class="r">${y} yr</th>`).join("")}</tr></thead>
      <tbody>${rows.map((r) => `<tr><td>${esc(r.label)}</td>${yrs.map((y) => cell(r.values[y])).join("")}</tr>`).join("")}</tbody></table>
      <div class="muted small">Compound annual growth of the trailing-4-quarter total (price, shares, equity and cash use the value on that date).
        “–” means not enough history, or a loss at the start or end (CAGR isn't meaningful then). Shares going down = buybacks.</div></div>`;
  }
  function researchStats(d) {
    const st = d.stats;
    if (!st || !st.groups) return "";
    return `<h2 class="sec-h">Statistics (TTM)</h2><div class="stat-grid">${st.groups.map((g) => `<div class="stat-card"><h3>${esc(g.title)}</h3>
      ${g.rows.map((r) => `<div class="kv"><span>${esc(r.label)}</span><b class="num">${statVal(r)}</b></div>`).join("")}</div>`).join("")}</div>
      ${cagrCard(st.cagr)}
      <p class="muted small">Worked out from the last four quarterly filings and today's price. ROIC uses the company's own tax rate (21% if it isn't reported). PEG = P/E ÷ EPS growth over the last year.</p>`;
  }
  function unavailableCard(name, src) {
    return `<div class="mcard off"><div class="mc-h"><h3>${esc(name)}</h3></div>
      <div class="nodata"><span class="muted">${ic("plug", 16)} Needs ${esc(src)}</span> <button class="btn ghost" data-go="sources">Connect</button></div></div>`;
  }

  /* =====================================================================
     COMPARE: up to four tickers side by side
     ===================================================================== */
  const CMP_COLORS = ["--slow", "--fast", "--pass", "#4FC3F7"];
  const cmpColor = (i) => (CMP_COLORS[i].startsWith("--") ? `var(${CMP_COLORS[i]})` : CMP_COLORS[i]);

  function renderCompare() {
    const root = $("#compareBody"), C = P.compare;
    const c = caps();
    if (!C.tickers.some(Boolean)) C.tickers = ((S.state.watchlist || []).slice(0, 2).concat(["", "", "", ""])).slice(0, 4);
    root.innerHTML = `
      <div class="pg-head"><h1>Compare</h1>
        <div class="seg" id="cmpRange">${QR.map(([l, n]) => `<button data-n="${n}" class="${C.range === n ? "on" : ""}">${l}</button>`).join("")}</div></div>
      ${c.history ? "" : needBox("Compare", capSrc("history"))}
      <form id="cmpForm" class="cmp-form" autocomplete="off">
        ${C.tickers.map((t, i) => `<label class="cmp-in"><i style="background:${cmpColor(i)}"></i><input name="t${i}" value="${esc(t)}" placeholder="Ticker ${i + 1}" maxlength="10" aria-label="Ticker ${i + 1}"></label>`).join("")}
        <button class="btn primary" type="submit">Compare</button>
      </form>
      <div id="cmpInner"></div>`;
    bindGo(root);
    $("#cmpForm").onsubmit = (e) => { e.preventDefault(); C.tickers = [0, 1, 2, 3].map((i) => cleanT(e.target["t" + i].value)); loadCompare(); };
    $$("#cmpRange button").forEach((b) => (b.onclick = () => { C.range = +b.dataset.n; renderCompare(); }));
    if (C.data) drawCompare();
    else if (c.history && C.tickers.filter(Boolean).length) loadCompare();
  }

  async function loadCompare() {
    const C = P.compare, list = C.tickers.filter(Boolean);
    const inner = $("#cmpInner");
    if (!list.length) { if (inner) inner.innerHTML = ""; return; }
    if (inner) inner.innerHTML = `<div class="loading">${ic("refresh", 18)} Loading ${esc(list.join(", "))}…</div>`;
    const r = await call("get_compare", list);
    C.data = r && r.ok ? r.items : [];
    if (S.page === "compare") drawCompare();
  }

  function cagrOf(it) {
    const rows = (it.stats && it.stats.cagr) || [], get = (k, y) => { const r = rows.find((x) => x.key === k); return r ? r.values[y] : null; };
    return { revC3: get("revenue", "3"), revC5: get("revenue", "5"), revC10: get("revenue", "10"), epsC5: get("eps", "5"),
             fcfC5: get("fcf", "5"), pxC5: get("price", "5"), pxC10: get("price", "10") };
  }
  function drawCompare() {
    const C = P.compare, items = C.data || [], inner = $("#cmpInner");
    if (!inner) return;
    if (!items.length) { inner.innerHTML = ""; return; }
    const ttm = (arr) => { const xs = (arr || []).filter((x) => x != null).slice(-4); return xs.length === 4 ? xs.reduce((a, b) => a + b, 0) : null; };
    const ttmPrev = (arr) => { const xs = (arr || []).filter((x) => x != null); return xs.length >= 8 ? xs.slice(-8, -4).reduce((a, b) => a + b, 0) : null; };
    const rows = items.map((it) => {
      const h = it.history, m = h ? h.metrics : {};
      const price = it.quote && it.quote.last ? it.quote.last : it.valuation ? lastVal(it.valuation.price || [])[0] : null;
      const sh = lastVal(m.shares || [])[0];
      const mcap = price && sh ? price * sh : null;
      const rev = ttm(m.revenue), revP = ttmPrev(m.revenue), eps = ttm(m.eps), epsP = ttmPrev(m.eps);
      const gm = rev && ttm(m.gross_profit) != null ? ttm(m.gross_profit) / rev * 100 : null;
      const ni = ttm(m.net_income);
      const p = it.prices, perf = p && p.c.length > 52 ? (p.c[p.c.length - 1] / p.c[p.c.length - 53] - 1) * 100 : null;
      return {
        t: it.ticker, err: it.error || (!h && Object.values(it.errors || {})[0]),
        price, mcap, rev, revG: rev && revP ? (rev / revP - 1) * 100 : null, gm, nm: rev && ni != null ? ni / rev * 100 : null,
        ni, eps, epsG: eps != null && epsP ? (eps - epsP) / Math.abs(epsP) * 100 : null,
        ocf: ttm(m.ocf), fcf: ttm(m.fcf), cash: lastVal(m.cash || [])[0], debt: lastVal(m.debt || [])[0],
        pe: price && eps > 0 ? price / eps : null, ps: mcap && rev ? mcap / rev : null, perf,
        ...cagrOf(it),
      };
    });
    const lines = [
      ["Price", "price", (x) => "$" + fmt(x), 0], ["Market cap", "mcap", big, 1], ["Revenue (TTM)", "rev", big, 1],
      ["Revenue growth (YoY)", "revG", (x) => pct(x), 1], ["Gross margin", "gm", (x) => fmt(x, 1) + "%", 1],
      ["Net margin", "nm", (x) => fmt(x, 1) + "%", 1], ["Net income (TTM)", "ni", big, 1], ["EPS (TTM)", "eps", (x) => "$" + fmt(x), 1],
      ["EPS growth (YoY)", "epsG", (x) => pct(x), 1], ["Cash from operations (TTM)", "ocf", big, 1], ["Free cash flow (TTM)", "fcf", big, 1],
      ["Cash", "cash", big, 1], ["Debt", "debt", big, -1], ["P/E", "pe", (x) => fmt(x, 1) + "×", -1], ["P/S", "ps", (x) => fmt(x, 1) + "×", -1],
      ["Price change (1Y)", "perf", (x) => pct(x), 1],
      ["Revenue CAGR 3y", "revC3", (x) => pct(x), 1], ["Revenue CAGR 5y", "revC5", (x) => pct(x), 1],
      ["Revenue CAGR 10y", "revC10", (x) => pct(x), 1], ["EPS CAGR 5y", "epsC5", (x) => pct(x), 1],
      ["FCF CAGR 5y", "fcfC5", (x) => pct(x), 1], ["Share price CAGR 5y", "pxC5", (x) => pct(x), 1],
      ["Share price CAGR 10y", "pxC10", (x) => pct(x), 1],
    ];
    let html = `<div class="card cmp-table"><table class="res"><thead><tr><th></th>${rows.map((r, i) => `<th class="r"><span class="cmp-dot" style="background:${cmpColor(C.tickers.indexOf(r.t) >= 0 ? C.tickers.indexOf(r.t) : i)}"></span>${esc(r.t)}</th>`).join("")}</tr></thead><tbody>`;
    for (const [label, k, f, better] of lines) {
      const vals = rows.map((r) => r[k]).filter((x) => x != null && isFinite(x));
      const best = better && vals.length > 1 ? (better > 0 ? Math.max(...vals) : Math.min(...vals.filter((x) => k === "debt" || x > 0))) : null;
      html += `<tr><td class="muted">${label}</td>${rows.map((r) => `<td class="r num ${r[k] != null && r[k] === best ? "best" : ""}">${r[k] == null || !isFinite(r[k]) ? "–" : esc(f(r[k]))}</td>`).join("")}</tr>`;
    }
    html += `</tbody></table>${rows.filter((r) => r.err).map((r) => `<div class="muted small">${esc(r.t)}: ${esc(r.err)}</div>`).join("")}
      <div class="muted small">Highlighted = best of the group. TTM = last four quarters.</div></div>`;

    // price performance (weekly closes, indexed to 100)
    const weeks = Math.round(C.range * 13);
    const priced = items.filter((it) => it.prices && it.prices.c.length);
    if (priced.length) {
      html += `<div class="mcard wide"><div class="mc-h"><h3>Price performance</h3><span class="muted small">indexed to 100</span></div>${perfChart(priced, weeks)}</div>`;
    } else if (!caps().bars_10y) html += unavailableCard("Price performance", capSrc("bars_10y"));

    // quarterly metrics aligned by calendar quarter
    const keys = new Set();
    items.forEach((it) => it.history && it.history.quarters.forEach((q) => keys.add(qKey(q))));
    const allKeys = [...keys].sort().slice(-C.range);
    const keyEnd = {};
    items.forEach((it) => it.history && it.history.quarters.forEach((q) => (keyEnd[qKey(q)] = keyEnd[qKey(q)] || q)));
    const labels = allKeys.map((k) => keyEnd[k]);
    const pick = (it, getter) => {
      if (!it.history) return allKeys.map(() => null);
      const map = {};
      const arr = getter(it) || [];
      it.history.quarters.forEach((q, i) => (map[qKey(q)] = arr[i]));
      return allKeys.map((k) => (map[k] == null ? null : map[k]));
    };
    html += `<div class="metric-grid">`;
    const cm = METRICS.filter((M) => !M.special && M.id !== "price");
    for (const M of cm) {
      const series = items.map((it, i) => ({ name: it.ticker, color: cmpColor(C.tickers.indexOf(it.ticker) >= 0 ? C.tickers.indexOf(it.ticker) : i), kind: "line", values: pick(it, (x) => M.val(x.history, x.valuation)) }));
      html += `<div class="mcard"><div class="mc-h"><h3>${esc(M.name)}</h3></div>${qChart(labels, series, M.f, { label: M.name })}</div>`;
    }
    const fcfM = { f: big };
    html += `<div class="mcard"><div class="mc-h"><h3>Cash</h3></div>${qChart(labels, items.map((it, i) => ({ name: it.ticker, color: cmpColor(i), kind: "line", values: pick(it, (x) => x.history.metrics.cash) })), fcfM.f)}</div>`;
    html += `<div class="mcard"><div class="mc-h"><h3>Debt</h3></div>${qChart(labels, items.map((it, i) => ({ name: it.ticker, color: cmpColor(i), kind: "line", values: pick(it, (x) => x.history.metrics.debt) })), fcfM.f)}</div>`;
    html += `</div><div class="seg-legend">${items.map((it, i) => `<span class="key"><i style="background:${cmpColor(i)}"></i>${esc(it.ticker)}</span>`).join("")}</div>`;
    inner.innerHTML = html;
    bindGo(inner);
  }

  function perfChart(items, weeks) {
    const W = 1100, H = 240, padT = 12, padB = 24, padR = 56;
    const ser = items.map((it, i) => {
      const p = it.prices, s = Math.max(0, p.c.length - weeks);
      const base = p.c[s];
      return { t: it.ticker, i, dates: p.t.slice(s), vals: p.c.slice(s).map((x) => (x / base) * 100) };
    });
    const allDates = [...new Set(ser.flatMap((s) => s.dates))].sort();
    const xi = {}; allDates.forEach((d, i) => (xi[d] = i));
    const all = ser.flatMap((s) => s.vals);
    let max = Math.max(...all), min = Math.min(...all);
    const pad = (max - min) * 0.06 || 1; max += pad; min -= pad;
    const x = (d) => 4 + (xi[d] / Math.max(1, allDates.length - 1)) * (W - padR - 8);
    const y = (v) => padT + ((max - v) / (max - min)) * (H - padT - padB);
    let out = "";
    const step = niceStep((max - min) / 5);
    for (let v = Math.ceil(min / step) * step; v <= max; v += step) out += `<line x1="0" x2="${W - padR}" y1="${y(v)}" y2="${y(v)}" stroke="var(--line-soft)"/><text x="${W - padR + 6}" y="${y(v) + 4}" class="ax">${fmt(v, 0)}</text>`;
    let lastY = "";
    allDates.forEach((d, i) => { if (d.slice(0, 4) !== lastY && i > 0) { out += `<text x="${x(d)}" y="${H - 6}" class="ax" text-anchor="middle">${d.slice(0, 4)}</text>`; } lastY = d.slice(0, 4); });
    ser.forEach((s) => {
      const col = cmpColor(P.compare.tickers.indexOf(s.t) >= 0 ? P.compare.tickers.indexOf(s.t) : s.i);
      out += `<path d="${s.vals.map((v, i) => (i ? "L" : "M") + x(s.dates[i]).toFixed(1) + " " + y(v).toFixed(1)).join("")}" fill="none" stroke="${col}" stroke-width="2"/>`;
      const lv = s.vals[s.vals.length - 1];
      out += `<text x="${x(s.dates[s.dates.length - 1]) - 4}" y="${y(lv) - 6}" text-anchor="end" class="ax" fill="${col}">${esc(s.t)} ${pct(lv - 100, 0)}</text>`;
    });
    return `<svg viewBox="0 0 ${W} ${H}" class="qchart" role="img" aria-label="Price performance">${out}</svg>`;
  }

  /* =====================================================================
     SCREENER: TradingView-style filters on the local database
     ===================================================================== */
  const PERF_KEYS = [["perf_1w", "1W"], ["perf_1m", "1M"], ["perf_3m", "3M"], ["perf_6m", "6M"], ["perf_ytd", "YTD"], ["perf_1y", "1Y"]];
  const RATING_OPTS = [["4.5", "Strong buy"], ["3.5", "Buy or better"], ["2.5", "Hold or better"]];
  const FILTERS = [
    { id: "country", label: "Country", type: "fixed", text: "United States" },
    { id: "watchlist", label: "Watchlist", type: "watch" },
    { id: "index", label: "Index", type: "na", need: "an index-membership data source (S&P 500 / Nasdaq-100 lists)" },
    { id: "price", label: "Price", type: "range", field: "price", unit: "$" },
    { id: "chg", label: "Chg %", type: "range", field: "chg_pct", unit: "%" },
    { id: "mcap", label: "Market cap", type: "range", field: "market_cap", unit: "$B", scale: 1e9 },
    { id: "pe", label: "P/E", type: "range", field: "pe" },
    { id: "fpe", label: "Forward P/E", type: "range", field: "forward_pe", enrich: "forward_pe", cap: "forward_pe" },
    { id: "epsg", label: "EPS dil growth TTM YoY", type: "range", field: "eps_ttm_yoy", unit: "%" },
    { id: "div", label: "Div yield %", type: "range", field: "div_yield", unit: "%" },
    { id: "sector", label: "Sector", type: "multi", field: "sector" },
    { id: "rotation", label: "Sector rotation", type: "multi", field: "sector_quadrant", word: "quadrants",
      options: ["Leading", "Improving", "Weakening", "Lagging", "Unknown"],
      tip: "The stock's sector ETF vs SPY today (same reading as the Rotation page). Leading = beating SPY and still improving." },
    { id: "secval", label: "Sector valuation", type: "multi", field: "sector_value_label", word: "levels",
      options: ["Undervalued", "Fair value", "Overvalued", "Unknown"],
      tip: "The sector's valuation score today, −10 to +10 (Rotation → Valuation). Undervalued = +3 or more, Overvalued = −3 or less." },
    { id: "rating", label: "Analyst rating", type: "rating", field: "analyst_score", enrich: "analyst_score", cap: "analyst_score" },
    { id: "perf", label: "Perf %", type: "perf", unit: "%" },
    { id: "revg", label: "Revenue growth", type: "range", field: "rev_yoy", unit: "%" },
    { id: "peg", label: "PEG", type: "range", field: "peg" },
    { id: "roe", label: "ROE", type: "range", field: "roe", unit: "%" },
    { id: "beta", label: "Beta", type: "range", field: "beta" },
    { id: "recent", label: "Recent earnings date", type: "days", field: "last_earnings_date", dir: -1 },
    { id: "upcoming", label: "Upcoming earnings date", type: "days", field: "next_earnings_date", dir: 1, enrich: "next_earnings_date", cap: "earnings_calendar" },
    { id: "evfcf", label: "EV/FCF", type: "range", field: "ev_fcf" },
    { id: "fcf", label: "FCF FY", type: "range", field: "fcf_fy", unit: "$B", scale: 1e9 },
    { id: "ema150", label: "EMA 150 vs price", type: "ma", fixed: "ema_150" },
    { id: "ema200", label: "EMA 200 vs price", type: "ma", fixed: "ema_200" },
    { id: "sma", label: "SMA vs price", type: "ma", choices: [20, 50, 100, 150, 200], prefix: "sma_" },
    { id: "ema", label: "EMA vs price", type: "ma", choices: [9, 10, 20, 21, 50, 100, 150, 200], prefix: "ema_" },
  ];
  const PRESETS = [
    { name: "Investing setup", filters: { mcap: { min: 5 }, ema150: { pos: "above" }, ema200: { pos: "above" }, revg: { min: 0 }, epsg: { min: 0 }, fcf: { min: 0 } }, builtin: true },
    { name: "Investing, leading sectors", filters: { mcap: { min: 5 }, ema150: { pos: "above" }, ema200: { pos: "above" }, revg: { min: 0 }, epsg: { min: 0 }, fcf: { min: 0 }, rotation: { in: ["Leading"] } }, builtin: true },
    { name: "Investing, undervalued sectors", filters: { mcap: { min: 5 }, ema150: { pos: "above" }, ema200: { pos: "above" }, revg: { min: 0 }, epsg: { min: 0 }, fcf: { min: 0 }, secval: { in: ["Undervalued"] } }, builtin: true },
    { name: "Near 150/200 EMA", filters: { mcap: { min: 5 }, ema200: { pos: "within", pct: 3 }, revg: { min: 0 } }, builtin: true },
    { name: "Momentum leaders", filters: { mcap: { min: 10 }, perf: { key: "perf_3m", min: 20 }, ema: { pos: "above", len: 50 } }, builtin: true },
  ];

  function fAvailable(F) {
    if (F.type === "na") return [false, F.need];
    if (F.cap && !caps()[F.cap]) return [false, F.cap === "earnings_calendar" ? capSrc("earnings_calendar") : capSrc(F.cap)];
    return [true, ""];
  }
  function maField(F, v) { return F.fixed || (F.prefix + ((v && v.len) || F.choices[F.choices.length - 1])); }

  function summary(F, v) {
    if (!v) return "";
    const u = F.unit || "", sc = (x) => (u === "$" ? "$" + x : u === "$B" ? "$" + x + "B" : x + (u === "%" ? "%" : ""));
    switch (F.type) {
      case "range": case "perf": {
        const pre = F.type === "perf" ? (PERF_KEYS.find((p) => p[0] === v.key) || [0, "1M"])[1] + " " : "";
        if (v.min != null && v.max != null) return pre + sc(v.min) + " to " + sc(v.max);
        if (v.min != null) return pre + "above " + sc(v.min);
        if (v.max != null) return pre + "below " + sc(v.max);
        return "";
      }
      case "multi": return v.in && v.in.length ? (v.in.length > 2 ? v.in.length + " " + (F.word || "sectors") : v.in.join(", ")) : "";
      case "watch": return v.mode === "in" ? "In watchlist" : v.mode === "out" ? "Not in watchlist" : "";
      case "rating": return (RATING_OPTS.find((r) => r[0] === v.min) || [0, ""])[1];
      case "days": return F.dir < 0 ? `Past ${v.days} days` : `Next ${v.days} days`;
      case "ma": {
        const nm = F.fixed ? "" : (F.prefix === "sma_" ? "SMA " : "EMA ") + (v.len || F.choices[F.choices.length - 1]) + ": ";
        return nm + (v.pos === "above" ? "Price above" : v.pos === "below" ? "Price below" : `Within ${v.pct}%`);
      }
    }
    return "";
  }

  function passes(row, F, v, enriched) {
    const get = (f) => (F.enrich ? (enriched[row.ticker] || {})[f] : row[f]);
    switch (F.type) {
      case "range": case "perf": {
        const raw = F.type === "perf" ? row[v.key || "perf_1m"] : get(F.field);
        if (raw == null || !isFinite(raw)) return false;
        const x = F.scale ? raw / F.scale : raw;
        return (v.min == null || x >= v.min) && (v.max == null || x <= v.max);
      }
      case "multi": return !v.in || !v.in.length || v.in.includes(row[F.field] || "Unknown");
      case "watch": return v.mode === "in" ? row.in_watchlist : v.mode === "out" ? !row.in_watchlist : true;
      case "rating": { const sc = get("analyst_score"); return sc != null && sc >= +v.min; }
      case "days": {
        const dt = get(F.field);
        if (!dt) return false;
        const diff = (parseDay(dt) - parseDay(isoDay(new Date()))) / 864e5;
        return F.dir < 0 ? diff <= 0 && diff >= -v.days : diff >= 0 && diff <= v.days;
      }
      case "ma": {
        const ma = row[maField(F, v)], p = row.price;
        if (ma == null || p == null) return false;
        if (v.pos === "above") return p > ma;
        if (v.pos === "below") return p < ma;
        return Math.abs(p / ma - 1) * 100 <= (v.pct || 2);
      }
    }
    return true;
  }

  function activeFilters() {
    const out = [];
    for (const F of FILTERS) {
      const v = P.screener.filters[F.id];
      if (v && summary(F, v) && fAvailable(F)[0]) out.push([F, v]);
    }
    return out;
  }

  function filteredRows() {
    const db = P.screener.db;
    if (!db) return { rows: [], pendingEnrich: [] };
    const act = activeFilters();
    const local = act.filter(([F]) => !F.enrich), remote = act.filter(([F]) => F.enrich);
    let rows = db.rows.filter((r) => local.every(([F, v]) => passes(r, F, v, P.screener.enriched)));
    const pendingEnrich = remote.map(([F]) => F);
    if (remote.length && rows.length <= 150) {
      const key = rows.map((r) => r.ticker).join(",") + "|" + remote.map(([F]) => F.enrich).join(",");
      if (key === P.screener.enrichKey) rows = rows.filter((r) => remote.every(([F, v]) => passes(r, F, v, P.screener.enriched)));
    }
    return { rows, pendingEnrich, local: rows.length };
  }

  // sector rotation + valuation for every row, fetched in the background (cached for the day / hour)
  function applySectorOverlay() {
    const db = P.screener.db, ov = P.screener.overlay;
    if (!db) return;
    if (ov) {
      if (db.overlaid === ov) return;
      db.rows.forEach((r) => { const o = ov[r.sector] || {}; r.sector_quadrant = o.quadrant || "Unknown"; r.sector_value_label = o.value || "Unknown"; r.sector_value = o.score; });
      db.overlaid = ov;
      return;
    }
    if (P.screener.overlayLoading) return;
    P.screener.overlayLoading = true;
    call("sector_overlay").then((r) => {
      P.screener.overlayLoading = false;
      if (!r || !r.ok) return;
      P.screener.overlay = r.sectors;
      applySectorOverlay();
      if (S.page === "screener") renderScreener();
    });
  }

  async function renderScreener() {
    const root = $("#screenerBody");
    const c = caps();
    if (!P.screener.db) {
      const r = await call("get_screener_db");
      P.screener.db = r && r.db ? r.db : null;
    }
    applySectorOverlay();
    const st = await call("screener_status");
    const canBuild = c.fundamentals_all && c.quotes;
    const db = P.screener.db;
    const screens = PRESETS.concat(S.state.screens || []);
    const minCap = (S.state.settings || {}).screener_min_cap_b || 2;
    root.innerHTML = `
      <div class="pg-head"><h1>Screener</h1>
        <div class="db-status" id="dbStatus"></div>
        ${(() => { const u = +minCap >= 1000 ? 1000 : +minCap < 1 ? 0.001 : 1; return `<label class="cap-box" title="Smallest company to include">
          <span class="muted small">Over $</span>
          <input id="dbCapNum" type="number" min="0" step="any" value="${+(minCap / u).toFixed(3)}" aria-label="Minimum market cap">
          <select id="dbCapUnit" aria-label="Unit">${[[0.001, "Million"], [1, "Billion"], [1000, "Trillion"]].map(([v, l]) => `<option value="${v}" ${v === u ? "selected" : ""}>${l}</option>`).join("")}</select></label>`; })()}
        <button class="btn ghost" id="dbBuild" ${canBuild ? "" : "disabled"}>${ic("refresh")} Update data</button>
      </div>
      ${canBuild ? "" : needBox("The screener", !c.fundamentals_all ? "SEC EDGAR" : "Public.com", "It builds a local table of every US stock over your size floor.")}
      <div class="screens" id="screens">${screens.map((sc, i) => `<button class="tab ${P.screener.activeScreen === sc.name ? "on" : ""}" data-sc="${i}">${esc(sc.name)}${sc.builtin ? "" : ` <span class="x" data-del="${i}" title="Delete screen">×</span>`}</button>`).join("")}
        <form id="saveScreen" class="save-screen"><input name="n" placeholder="Name this screen" maxlength="40" aria-label="Screen name"><button class="btn ghost" type="submit">${ic("plus")} Save</button></form></div>
      <div class="fbar" id="fbar"></div>
      <div id="fpop" class="fpop" hidden></div>
      <div id="scrResults"></div>`;
    $("#dbBuild").onclick = async () => {
      const capB = (parseFloat($("#dbCapNum").value) || 0) * +$("#dbCapUnit").value;
      if (!(capB > 0)) return toast("Enter a market cap above 0", true);
      if (capB < 0.05) return toast("Use at least $50 Million (smaller companies have unreliable SEC data)", true);
      S.state.settings.screener_min_cap_b = capB;
      const r = await call("build_screener", capB);
      if (r.ok) { toast("Updating screener data…"); pollScreener(); } else toast(r.error, true);
    };
    $("#saveScreen").onsubmit = async (e) => {
      e.preventDefault();
      const name = e.target.n.value.trim();
      if (!name) return toast("Give the screen a name", true);
      const list = (S.state.screens || []).filter((x) => x.name !== name);
      list.push({ name, filters: JSON.parse(JSON.stringify(P.screener.filters)) });
      const r = await call("save_screens", list);
      if (r.ok) { S.state.screens = list; P.screener.activeScreen = name; toast(`Saved "${name}"`); renderScreener(); }
    };
    $$("#screens [data-sc]").forEach((b) => (b.onclick = async (e) => {
      const sc = screens[+b.dataset.sc];
      if (e.target.dataset.del) {
        const list = (S.state.screens || []).filter((x) => x.name !== sc.name);
        await call("save_screens", list); S.state.screens = list;
        if (P.screener.activeScreen === sc.name) P.screener.activeScreen = null;
        return renderScreener();
      }
      P.screener.filters = JSON.parse(JSON.stringify(sc.filters));
      P.screener.activeScreen = sc.name;
      P.screener.enrichKey = "";
      renderScreener();
    }));
    drawDbStatus(st);
    drawFilterBar();
    drawResults();
    if (st && st.running) pollScreener();
  }

  function capLabel(b) {
    b = +b;
    return b >= 1000 ? `$${+(b / 1000).toFixed(3)} Trillion` : b >= 1 ? `$${+b.toFixed(3)} Billion` : `$${+(b * 1000).toFixed(1)} Million`;
  }
  function drawDbStatus(st) {
    const el = $("#dbStatus"), db = P.screener.db;
    if (!el) return;
    if (st && st.running) {
      const p = st.total ? Math.round((st.done / st.total) * 100) : 0;
      el.innerHTML = `<span class="spin">${ic("refresh", 14)}</span> ${esc(st.stage || "Working")} ${st.total ? `${st.done}/${st.total} (${p}%)` : ""} <button class="btn ghost small-btn" id="dbStop">Stop</button>`;
      $("#dbStop").onclick = () => call("stop_screener");
      const b = $("#dbBuild"); if (b) b.disabled = true;
    } else if (db) {
      const when = new Date(db.built);
      el.innerHTML = `${fmt(db.count, 0)} stocks over ${capLabel(db.min_cap_b)} · updated ${when.toLocaleDateString(undefined, { month: "short", day: "numeric" })} ${when.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })}${db.complete === false ? " · partial" : ""}${st && st.error ? ` · <span class="neg">${esc(st.error)}</span>` : ""}`;
    } else el.innerHTML = st && st.error ? `<span class="neg">${esc(st.error)}</span>` : "No screener data yet";
  }

  function pollScreener() {
    clearInterval(P.screener.poll);
    P.screener.poll = setInterval(async () => {
      const st = await call("screener_status");
      if (S.page === "screener") drawDbStatus(st);
      if (!st || !st.running) {
        clearInterval(P.screener.poll);
        const r = await call("get_screener_db");
        P.screener.db = r && r.db ? r.db : null;
        applySectorOverlay();
        if (S.page === "screener") renderScreener();
        if (st && st.error) toast(st.error, true); else toast("Screener data updated");
      }
    }, 1500);
  }

  function drawFilterBar() {
    const bar = $("#fbar");
    if (!bar) return;
    bar.innerHTML = FILTERS.map((F) => {
      const [ok, need] = fAvailable(F);
      const v = P.screener.filters[F.id], sm = F.type === "fixed" ? F.text : summary(F, v);
      const on = F.type !== "fixed" && sm;
      return `<button class="fchip ${on ? "on" : ""} ${ok ? "" : "na"}" data-f="${F.id}" ${ok ? "" : `title="Needs ${esc(need)}"`}>
        <span>${esc(F.label)}${sm && F.type !== "fixed" ? ": " : F.type === "fixed" ? " " : ""}<b>${esc(sm)}</b></span>${on ? `<span class="x" data-clear="${F.id}" aria-label="Clear">×</span>` : ok ? `<span class="caret">▾</span>` : `<span class="caret">${ic("plug", 12)}</span>`}</button>`;
    }).join("") + `<button class="fchip reset" id="fReset">Reset all</button>`;
    $$(".fchip[data-f]", bar).forEach((b) => (b.onclick = (e) => {
      const F = FILTERS.find((x) => x.id === b.dataset.f);
      if (e.target.dataset.clear) { delete P.screener.filters[F.id]; P.screener.activeScreen = null; closePop(); drawFilterBar(); drawResults(); return; }
      const [ok, need] = fAvailable(F);
      if (!ok) return toast(`${F.label} needs ${need}`, true);
      if (F.type === "fixed") return toast("US stocks only (SEC filers)");
      openPop(F, b);
    }));
    $("#fReset").onclick = () => { P.screener.filters = {}; P.screener.activeScreen = null; closePop(); drawFilterBar(); drawResults(); };
  }

  function closePop() { const p = $("#fpop"); if (p) p.hidden = true; P.screener.open = null; }
  function openPop(F, anchor) {
    const pop = $("#fpop"), host = $("#screenerBody");
    if (P.screener.open === F.id && !pop.hidden) return closePop();
    P.screener.open = F.id;
    const v = P.screener.filters[F.id] || {};
    const num = (name, val, ph) => `<input type="number" step="any" name="${name}" value="${val == null ? "" : val}" placeholder="${ph}">`;
    let body = "";
    if (F.type === "range" || F.type === "perf") {
      body = (F.type === "perf" ? `<div class="seg">${PERF_KEYS.map(([k, l]) => `<button type="button" data-pk="${k}" class="${(v.key || "perf_1m") === k ? "on" : ""}">${l}</button>`).join("")}</div>` : "") +
        `<div class="pop-row">${num("min", v.min, "Min")}<span class="muted">to</span>${num("max", v.max, "Max")}<span class="muted">${esc(F.unit || "")}</span></div>` +
        `<div class="quick">${quickPicks(F).map(([l, a, b]) => `<button type="button" class="tab" data-min="${a ?? ""}" data-max="${b ?? ""}">${esc(l)}</button>`).join("")}</div>`;
    } else if (F.type === "multi") {
      const sectors = F.options || [...new Set((P.screener.db ? P.screener.db.rows : []).map((r) => r[F.field] || "Unknown"))].sort();
      body = (F.tip ? `<p class="muted small" style="max-width:34ch;margin:0 0 6px">${esc(F.tip)}</p>` : "") + `<div class="pop-list">${sectors.map((s) => `<label><input type="checkbox" name="in" value="${esc(s)}" ${(v.in || []).includes(s) ? "checked" : ""}> ${esc(s)}</label>`).join("") || `<span class="muted">Update the screener data first</span>`}</div>`;
    } else if (F.type === "watch") {
      body = `<div class="pop-list">${[["in", "In my watchlist"], ["out", "Not in my watchlist"]].map(([k, l]) => `<label><input type="radio" name="mode" value="${k}" ${v.mode === k ? "checked" : ""}> ${l}</label>`).join("")}</div>`;
    } else if (F.type === "rating") {
      body = `<div class="pop-list">${RATING_OPTS.map(([k, l]) => `<label><input type="radio" name="min" value="${k}" ${v.min === k ? "checked" : ""}> ${l}</label>`).join("")}</div>`;
    } else if (F.type === "days") {
      body = `<div class="quick">${[7, 14, 30, 60, 90].map((d) => `<button type="button" class="tab ${v.days === d ? "on" : ""}" data-days="${d}">${F.dir < 0 ? "Past" : "Next"} ${d} days</button>`).join("")}</div>`;
    } else if (F.type === "ma") {
      body = (F.choices ? `<div class="seg">${F.choices.map((n) => `<button type="button" data-len="${n}" class="${(v.len || F.choices[F.choices.length - 1]) === n ? "on" : ""}">${n}</button>`).join("")}</div>` : "") +
        `<div class="pop-list">${[["above", "Price above"], ["below", "Price below"], ["within", "Price within"]].map(([k, l]) => `<label><input type="radio" name="pos" value="${k}" ${v.pos === k ? "checked" : ""}> ${l}${k === "within" ? ` <input type="number" name="pct" step="0.5" min="0.5" value="${v.pct || 2}" class="mini"> %` : ""}</label>`).join("")}</div>`;
    }
    pop.innerHTML = `<form id="popForm"><div class="pop-h"><b>${esc(F.label)}</b>${F.enrich ? `<span class="muted small">checked live for up to 150 stocks</span>` : ""}</div>${body}
      <div class="pop-foot"><button type="button" class="btn ghost" id="popClear">Clear</button><button class="btn primary" type="submit">Apply</button></div></form>`;
    pop.hidden = false;
    const hr = host.getBoundingClientRect(), ar = anchor.getBoundingClientRect();
    pop.style.left = Math.min(ar.left - hr.left, hr.width - 330) + "px";
    pop.style.top = ar.bottom - hr.top + 6 + "px";
    const form = $("#popForm");
    const st = { key: v.key, len: v.len };
    $$("[data-pk]", form).forEach((b) => (b.onclick = () => { st.key = b.dataset.pk; $$("[data-pk]", form).forEach((x) => x.classList.toggle("on", x === b)); }));
    $$("[data-len]", form).forEach((b) => (b.onclick = () => { st.len = +b.dataset.len; $$("[data-len]", form).forEach((x) => x.classList.toggle("on", x === b)); }));
    $$("[data-min]", form).forEach((b) => (b.onclick = () => { form.min.value = b.dataset.min; form.max.value = b.dataset.max; }));
    $$("[data-days]", form).forEach((b) => (b.onclick = () => { apply({ days: +b.dataset.days }); }));
    $("#popClear").onclick = () => { delete P.screener.filters[F.id]; done(); };
    function apply(val) { P.screener.filters[F.id] = val; P.screener.activeScreen = null; done(); }
    function done() { closePop(); drawFilterBar(); drawResults(); }
    form.onsubmit = (e) => {
      e.preventDefault();
      const n = (x) => (x === "" || x == null ? null : +x);
      if (F.type === "range" || F.type === "perf") {
        const val = { min: n(form.min.value), max: n(form.max.value) };
        if (F.type === "perf") val.key = st.key || "perf_1m";
        if (val.min == null && val.max == null) { delete P.screener.filters[F.id]; return done(); }
        apply(val);
      } else if (F.type === "multi") apply({ in: $$("input[name=in]:checked", form).map((x) => x.value) });
      else if (F.type === "watch") { const c = $("input[name=mode]:checked", form); c ? apply({ mode: c.value }) : done(); }
      else if (F.type === "rating") { const c = $("input[name=min]:checked", form); c ? apply({ min: c.value }) : done(); }
      else if (F.type === "days") done();
      else if (F.type === "ma") {
        const c = $("input[name=pos]:checked", form);
        if (!c) return done();
        const val = { pos: c.value, pct: n(form.pct.value) || 2 };
        if (F.choices) val.len = st.len || F.choices[F.choices.length - 1];
        apply(val);
      }
    };
  }
  function quickPicks(F) {
    const m = {
      price: [["Under $20", null, 20], ["$20–100", 20, 100], ["Over $100", 100, null]],
      chg_pct: [["Up today", 0, null], ["Down today", null, 0], ["Up 3%+", 3, null], ["Down 3%+", null, -3]],
      market_cap: [["Over $5B", 5, null], ["$10B–200B", 10, 200], ["Over $200B", 200, null]],
      pe: [["Under 15", 0, 15], ["15–25", 15, 25], ["Under 40", 0, 40]],
      forward_pe: [["Under 15", 0, 15], ["Under 25", 0, 25]],
      eps_ttm_yoy: [["Positive", 0, null], ["Over 15%", 15, null], ["Over 30%", 30, null]],
      div_yield: [["Pays a dividend", 0.01, null], ["Over 2%", 2, null], ["Over 4%", 4, null]],
      rev_yoy: [["Positive", 0, null], ["Over 10%", 10, null], ["Over 25%", 25, null]],
      peg: [["Under 1", 0, 1], ["Under 2", 0, 2]],
      roe: [["Over 10%", 10, null], ["Over 20%", 20, null]],
      beta: [["Under 1", null, 1], ["1–2", 1, 2], ["Over 2", 2, null]],
      ev_fcf: [["Under 15", 0, 15], ["Under 30", 0, 30]],
      fcf_fy: [["Positive", 0, null], ["Over $1B", 1, null]],
    };
    if (F.type === "perf") return [["Up", 0, null], ["Over 10%", 10, null], ["Over 25%", 25, null], ["Down", null, 0]];
    return m[F.field] || [];
  }

  async function maybeEnrich(rows, pending) {
    if (!pending.length || P.screener.enriching) return;
    if (rows.length > 150) return;
    const fields = [...new Set(pending.map((F) => F.enrich))];
    const key = rows.map((r) => r.ticker).join(",") + "|" + pending.map((F) => F.enrich).join(",");
    if (key === P.screener.enrichKey) return;
    P.screener.enriching = true;
    drawResults(true);
    const need = rows.filter((r) => fields.some((f) => !(P.screener.enriched[r.ticker] || {}).hasOwnProperty(f))).map((r) => r.ticker);
    if (need.length) {
      const r = await call("screener_enrich", need, fields);
      if (r && r.ok) Object.entries(r.values).forEach(([t, vals]) => (P.screener.enriched[t] = Object.assign(P.screener.enriched[t] || {}, vals)));
      if (r && r.errors && r.errors.length) toast(r.errors[0], true);
    }
    P.screener.enriching = false;
    P.screener.enrichKey = key;
    if (S.page === "screener") drawResults();
  }

  function drawResults(busy = false) {
    const el = $("#scrResults"), SC = P.screener;
    if (!el) return;
    if (!SC.db) {
      el.innerHTML = `<div class="empty"><p><b>No screener data yet.</b></p><p class="muted">Press <b>Update data</b> to build a table of every US stock over your size floor (fundamentals from SEC, prices from Public). The first build takes a while; after that it refreshes automatically after each market close.</p></div>`;
      return;
    }
    const { rows, pendingEnrich } = filteredRows();
    const enrichOn = pendingEnrich.length > 0;
    const perf = (SC.filters.perf && SC.filters.perf.key) || SC.perfKey;
    const showF = enrichOn || Object.keys(SC.enriched).length;
    const cols = [
      ["ticker", "Ticker"], ["price", "Price", (r) => "$" + fmt(r.price)], ["chg_pct", "Chg %", (r) => pctCell(r.chg_pct)],
      ["market_cap", "Mkt cap", (r) => big(r.market_cap)], ["pe", "P/E", (r) => (r.pe ? fmt(r.pe, 1) : "–")],
      ...(showF && caps().forward_pe ? [["forward_pe", "Fwd P/E", (r) => { const x = (SC.enriched[r.ticker] || {}).forward_pe; return x ? fmt(x, 1) : "–"; }, true]] : []),
      ["eps_ttm_yoy", "EPS gr", (r) => pctCell(r.eps_ttm_yoy)], ["rev_yoy", "Rev gr", (r) => pctCell(r.rev_yoy)],
      ["div_yield", "Div %", (r) => (r.div_yield ? fmt(r.div_yield, 2) + "%" : "–")],
      [perf, "Perf " + (PERF_KEYS.find((p) => p[0] === perf) || [0, ""])[1], (r) => pctCell(r[perf])],
      ["d150", "vs EMA150", (r) => pctCell(r.ema_150 ? (r.price / r.ema_150 - 1) * 100 : null)],
      ["d200", "vs EMA200", (r) => pctCell(r.ema_200 ? (r.price / r.ema_200 - 1) * 100 : null)],
      ["sector", "Sector", (r) => `<span class="muted">${esc(r.sector || "–")}</span><span class="sec-tags">${r.sector_quadrant && r.sector_quadrant !== "Unknown" ? ` <span class="q-tag q-${esc(r.sector_quadrant.toLowerCase())}">${esc(r.sector_quadrant)}</span>` : ""}${r.sector_value != null ? ` <span class="q-tag ${r.sector_value >= 3 ? "q-leading" : r.sector_value <= -3 ? "q-lagging" : "q-unknown"}" title="Sector valuation (−10 expensive … +10 cheap)">${r.sector_value > 0 ? "+" : ""}${fmt(r.sector_value, 1)}</span>` : ""}</span>`],
    ];
    const sk = SC.sort.key, dir = SC.sort.dir;
    const val = (r, k) => (k === "d150" ? (r.ema_150 ? r.price / r.ema_150 : null) : k === "d200" ? (r.ema_200 ? r.price / r.ema_200 : null)
      : k === "forward_pe" ? (SC.enriched[r.ticker] || {}).forward_pe : r[k]);
    const sorted = rows.slice().sort((a, b) => {
      const x = val(a, sk), y = val(b, sk);
      if (x == null && y == null) return 0; if (x == null) return 1; if (y == null) return -1;
      return (typeof x === "string" ? x.localeCompare(y) : x - y) * dir;
    });
    let note = "";
    if (enrichOn) {
      if (rows.length > 150 && SC.enrichKey !== "") note = "";
      if (rows.length > 150) note = `<div class="note">${ic("alerts", 16)} ${esc(pendingEnrich.map((F) => F.label).join(", "))} is checked live (it uses API calls), so narrow the list to 150 stocks or fewer with the other filters first. ${fmt(rows.length, 0)} match so far.</div>`;
      else if (busy || SC.enriching) note = `<div class="note"><span class="spin">${ic("refresh", 14)}</span> Checking ${esc(pendingEnrich.map((F) => F.label).join(", "))} for ${rows.length} stocks…</div>`;
    }
    const shown = sorted.slice(0, SC.limit);
    el.innerHTML = `${note}<div class="res-bar"><b class="num">${fmt(rows.length, 0)}</b> <span class="muted">matches</span>
        <span class="muted small">of ${fmt(SC.db.count, 0)}</span>
        <button class="btn ghost" id="addAllWl" ${rows.length && rows.length <= 100 ? "" : "disabled"} title="${rows.length > 100 ? "Narrow to 100 or fewer first" : ""}">${ic("plus")} Add to watchlist</button></div>
      <div class="table-wrap"><table class="res scr"><thead><tr>${cols.map(([k, l]) => `<th data-k="${k}" class="${k === "ticker" || k === "sector" ? "" : "r"} ${sk === k ? "sorted" : ""}">${esc(l)}${sk === k ? (dir > 0 ? " ↑" : " ↓") : ""}</th>`).join("")}</tr></thead>
      <tbody>${shown.map((r) => `<tr data-t="${esc(r.ticker)}">${cols.map(([k, , f]) => k === "ticker"
        ? `<td><div class="tk">${esc(r.ticker)}${r.in_watchlist ? ` <span class="wl-dot" title="In watchlist"></span>` : ""}</div><div class="muted small nm">${esc(r.name || "")}</div></td>`
        : `<td class="${k === "sector" ? "" : "r num"}">${f(r)}</td>`).join("")}</tr>`).join("")}</tbody></table></div>
      ${rows.length > SC.limit ? `<button class="btn ghost more" id="more">Show more (${fmt(rows.length - SC.limit, 0)} left)</button>` : ""}`;
    $$("th[data-k]", el).forEach((th) => (th.onclick = () => {
      const k = th.dataset.k;
      SC.sort = { key: k, dir: SC.sort.key === k ? -SC.sort.dir : k === "ticker" || k === "sector" ? 1 : -1 };
      drawResults();
    }));
    $$("tbody tr", el).forEach((tr) => (tr.onclick = () => { P.research.ticker = tr.dataset.t; P.research.data = null; show("research"); }));
    const more = $("#more"); if (more) more.onclick = () => { SC.limit += 300; drawResults(); };
    $("#addAllWl").onclick = async () => {
      const merged = [...new Set((S.state.watchlist || []).concat(rows.map((r) => r.ticker)))];
      const r = await call("save_watchlist", merged);
      if (r.ok) { S.state.watchlist = r.watchlist; SC.db.rows.forEach((x) => (x.in_watchlist = r.watchlist.includes(x.ticker))); toast(`Watchlist now has ${r.watchlist.length} tickers`); drawResults(); }
    };
    if (enrichOn && !busy) maybeEnrich(rows, pendingEnrich);
  }

  /* =====================================================================
     CALENDAR: earnings for major US companies and your watchlist
     ===================================================================== */
  function calRange() {
    const C = P.calendar;
    if (!C.anchor) C.anchor = new Date();
    const a = new Date(C.anchor);
    if (C.mode === "week") {
      const mon = addDays(a, -((a.getDay() + 6) % 7));
      return [mon, addDays(mon, 4)];
    }
    const first = new Date(a.getFullYear(), a.getMonth(), 1);
    const start = addDays(first, -((first.getDay() + 6) % 7));
    const last = new Date(a.getFullYear(), a.getMonth() + 1, 0);
    const end = addDays(last, (7 - last.getDay()) % 7);
    return [start, end];
  }

  async function renderCalendar() {
    const root = $("#calendarBody"), C = P.calendar;
    const [start, end] = calRange();
    const title = C.mode === "week"
      ? `${start.toLocaleDateString(undefined, { month: "short", day: "numeric" })} – ${end.toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" })}`
      : C.anchor.toLocaleDateString(undefined, { month: "long", year: "numeric" });
    root.innerHTML = `
      <div class="pg-head"><h1>Earnings calendar</h1>
        <div class="seg" id="calMode"><button data-m="week" class="${C.mode === "week" ? "on" : ""}">Week</button><button data-m="month" class="${C.mode === "month" ? "on" : ""}">Month</button></div>
        <div class="cal-nav"><button class="icon-btn" id="calPrev" aria-label="Previous">‹</button><b id="calTitle">${esc(title)}</b><button class="icon-btn" id="calNext" aria-label="Next">›</button><button class="btn ghost" id="calToday">Today</button></div>
        <select id="calFilter" aria-label="Which companies">
          <option value="both" ${C.filter === "both" ? "selected" : ""}>Watchlist + major (over $10B)</option>
          <option value="watch" ${C.filter === "watch" ? "selected" : ""}>Watchlist only</option>
          <option value="all" ${C.filter === "all" ? "selected" : ""}>All reporting companies</option></select>
      </div>
      <div id="calInner"><div class="loading">${ic("refresh", 18)} Loading…</div></div>`;
    bindGo(root);
    $$("#calMode button").forEach((b) => (b.onclick = () => { C.mode = b.dataset.m; C.data = null; renderCalendar(); }));
    $("#calPrev").onclick = () => { C.anchor = C.mode === "week" ? addDays(C.anchor, -7) : new Date(C.anchor.getFullYear(), C.anchor.getMonth() - 1, 1); C.data = null; renderCalendar(); };
    $("#calNext").onclick = () => { C.anchor = C.mode === "week" ? addDays(C.anchor, 7) : new Date(C.anchor.getFullYear(), C.anchor.getMonth() + 1, 1); C.data = null; renderCalendar(); };
    $("#calToday").onclick = () => { C.anchor = new Date(); C.data = null; renderCalendar(); };
    $("#calFilter").onchange = (e) => { C.filter = e.target.value; drawCalendar(start, end); };
    const key = isoDay(start) + isoDay(end);
    if (!C.data || C.data.key !== key) {
      const r = await call("get_calendar", isoDay(start), isoDay(end));
      C.data = Object.assign({ key }, r || {});
    }
    if (S.page === "calendar") drawCalendar(start, end);
  }

  function drawCalendar(start, end) {
    const C = P.calendar, d = C.data, el = $("#calInner");
    if (!el) return;
    if (!d.available) {
      const past = Object.entries(d.past || {}).filter(([, v]) => v).sort((a, b) => b[1].localeCompare(a[1]));
      el.innerHTML = needBox("The earnings calendar", d.needs || capSrc("earnings_calendar"), "Both have free keys.") +
        (past.length ? `<div class="card"><h3>Last reported (from SEC filings)</h3><div class="past-list">${past.map(([t, v]) => `<div><b>${esc(t)}</b><span class="muted num">${esc(v)}</span></div>`).join("")}</div></div>` : "");
      bindGo(el);
      return;
    }
    if (d.ok === false) { el.innerHTML = `<div class="err">${esc(d.error)}</div>`; return; }
    const evs = (d.events || []).filter((e) => C.filter === "all" || e.watch || (C.filter === "both" && e.major));
    const byDay = {};
    evs.forEach((e) => (byDay[e.date] = byDay[e.date] || []).push(e));
    Object.values(byDay).forEach((l) => l.sort((a, b) => (b.watch - a.watch) || ((b.market_cap || 0) - (a.market_cap || 0))));
    const today = isoDay(new Date());
    const days = [];
    for (let x = new Date(start); x <= end; x = addDays(x, 1)) if (C.mode === "month" || (x.getDay() > 0 && x.getDay() < 6)) days.push(new Date(x));
    const pill = (e) => {
      const beat = e.eps_act != null && e.eps_est != null ? (e.eps_act >= e.eps_est ? "beat" : "miss") : "";
      const tm = { bmo: "Before open", amc: "After close", dmh: "During market" }[String(e.time || "").toLowerCase()] || "";
      return `<button class="ev ${e.watch ? "watch" : ""} ${beat}" data-t="${esc(e.symbol)}" title="${esc(e.symbol)}${tm ? " · " + tm : ""}${e.eps_est != null ? " · EPS est $" + fmt(e.eps_est) : ""}${e.eps_act != null ? " · actual $" + fmt(e.eps_act) : ""}${e.market_cap ? " · " + big(e.market_cap) : ""}">
        <b>${esc(e.symbol)}</b>${tm ? `<span class="tm">${tm === "Before open" ? ic("sun", 12) : tm === "After close" ? ic("moon", 12) : ""}</span>` : ""}
        ${C.mode === "week" ? `<span class="muted small">${e.eps_est != null ? "est $" + fmt(e.eps_est) : ""}${beat ? ` · <span class="${beat === "beat" ? "pos" : "neg"}">${beat}</span>` : ""}</span>` : ""}</button>`;
    };
    const cap = C.mode === "week" ? 40 : 6;
    el.innerHTML = `<div class="cal ${C.mode}">
      ${(C.mode === "month" ? ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"] : []).map((w) => `<div class="cal-wd muted small">${w}</div>`).join("")}
      ${days.map((x) => {
        const k = isoDay(x), list = byDay[k] || [];
        const out = C.mode === "month" && x.getMonth() !== C.anchor.getMonth();
        return `<div class="cal-day ${k === today ? "today" : ""} ${out ? "out" : ""}">
          <div class="cd-h">${C.mode === "week" ? x.toLocaleDateString(undefined, { weekday: "short" }) + " " : ""}<span class="num">${x.getDate()}</span>${list.length ? `<span class="muted small">${list.length}</span>` : ""}</div>
          <div class="cd-list">${list.slice(0, cap).map(pill).join("")}${list.length > cap ? `<button class="ev more" data-day="${k}">+${list.length - cap} more</button>` : ""}</div></div>`;
      }).join("")}</div>
      <div class="cal-foot muted small"><span class="key"><i class="wl-dot"></i>Watchlist</span> <span class="key">${ic("sun", 12)} Before open</span> <span class="key">${ic("moon", 12)} After close</span>
        · from ${esc(d.source || "")}${!d.has_caps && C.filter === "both" ? " · build the screener data to know which companies are over $10B" : ""}</div>`;
    $$(".ev[data-t]", el).forEach((b) => (b.onclick = () => { P.research.ticker = b.dataset.t; P.research.data = null; show("research"); }));
    $$(".ev[data-day]", el).forEach((b) => (b.onclick = () => { C.mode = "week"; C.anchor = parseDay(b.dataset.day); C.data = null; renderCalendar(); }));
  }

  /* =====================================================================
     ALERTS: Telegram message when a moving average or price is hit
     ===================================================================== */
  async function renderAlerts() {
    const root = $("#alertsBody"), A = P.alerts;
    const r = await call("list_alerts");
    A.data = r && r.ok ? r : { alerts: [], history: [] };
    const tg = (S.state.telegram || {}).is_set;
    const d0 = Object.assign({ ticker: P.chart.ticker || "", kind: "ma_touch", ma_type: "EMA", length: 200, direction: "above", near_pct: 1, repeat: "once" }, A.draft || {});
    A.draft = null;
    const d = A.data;
    root.innerHTML = `
      <div class="pg-head"><h1>Alerts</h1>
        <span class="market-pill ${d.market_open ? "open" : ""}">${d.market_open ? "Market open · checking every minute" : "Market closed · alerts check during market hours"}</span>
        <button class="btn ghost" id="alCheck">${ic("refresh")} Check now</button></div>
      ${tg ? "" : `<div class="needs">${ic("send", 18)}<div><b>Telegram isn't set up.</b> <span class="muted">Alerts still show here, but they can't message you until you add your bot in Settings.</span></div><button class="btn ghost" data-go="settings">Settings</button></div>`}
      ${d.quotes === false ? needBox("Alerts", capSrc("bars")) : ""}
      ${d.last_error ? `<div class="err">Last check failed: ${esc(d.last_error)}</div>` : ""}
      <div class="al-grid">
        <div>
          <form class="card al-form" id="alForm" autocomplete="off">
            <h3>New alert</h3>
            <div class="al-fields">
              <label>Ticker<input name="ticker" value="${esc(d0.ticker)}" maxlength="10" required></label>
              <label>When<select name="kind">
                ${[["ma_touch", "Touches a moving average"], ["ma_near", "Gets within % of a moving average"], ["price_above", "Price goes above"], ["price_below", "Price goes below"], ["price_cross", "Price crosses"]].map(([k, l]) => `<option value="${k}" ${d0.kind === k ? "selected" : ""}>${l}</option>`).join("")}</select></label>
              <label class="ma-only">Type<select name="ma_type"><option ${d0.ma_type === "EMA" ? "selected" : ""}>EMA</option><option ${d0.ma_type === "SMA" ? "selected" : ""}>SMA</option></select></label>
              <label class="ma-only">Length<span class="len-pair"><input type="number" name="length" min="2" max="400" value="${d0.length}"><input type="range" name="lenSlide" min="2" max="400" value="${d0.length}" aria-label="Length slider"></span></label>
              <label class="touch-only">Direction<select name="direction">${[["above", "Pulls back from above"], ["below", "Rallies up from below"], ["either", "Either way"]].map(([k, l]) => `<option value="${k}" ${d0.direction === k ? "selected" : ""}>${l}</option>`).join("")}</select></label>
              <label class="near-only">Within %<input type="number" name="near_pct" step="0.1" min="0.1" value="${d0.near_pct}"></label>
              <label class="price-only">Price $<input type="number" name="price" step="0.01" value="${d0.price || ""}"></label>
              <label>And price<span class="len-pair"><select name="and_cond"><option value="">Any</option><option value="below">is below</option><option value="above">is above</option></select><input type="number" name="and_price" step="0.01" placeholder="$"></span></label>
              <label>Repeat<select name="repeat"><option value="once">Once, then switch off</option><option value="daily">At most once a day</option></select></label>
              <label>Expires<input type="date" name="expires"></label>
            </div>
            <label class="note-l">Note in the Telegram message<input name="note" maxlength="140" placeholder="e.g. Add 1/3 position here"></label>
            <div class="al-foot"><span class="muted small" id="alDesc"></span><button class="btn primary" type="submit">${ic("plus")} Create alert</button></div>
          </form>
          <div class="card"><h3>Active alerts <span class="muted small">${d.alerts.length}</span></h3>
            ${d.alerts.length ? `<div class="al-list">${d.alerts.map((a) => `
              <div class="al-row ${a.enabled ? "" : "off"}" data-id="${esc(a.id)}">
                <label class="switch"><input type="checkbox" data-act="toggle" ${a.enabled ? "checked" : ""} aria-label="Alert on"><span></span></label>
                <b class="tk">${esc(a.ticker)}</b>${a.sector ? ` <span class="sector-pill">${esc(a.sector)}</span>` : ""}
                <div class="al-desc">${esc(a.description)}${a.note ? `<div class="muted small">“${esc(a.note)}”</div>` : ""}</div>
                <span class="muted small">${a.last_fired ? "Fired " + new Date(a.last_fired).toLocaleString([], { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" }) : a.repeat === "daily" ? "Daily" : "Once"}${a.expires ? " · until " + esc(a.expires) : ""}</span>
                <button class="icon-btn" data-act="chart" title="Open chart">${ic("charts", 16)}</button>
                <button class="icon-btn" data-act="del" title="Delete">${ic("x", 16)}</button>
              </div>`).join("")}</div>` : `<p class="muted">No alerts yet. Create one above, or use “Add alert” on the Charts page.</p>`}
          </div>
        </div>
        <div>
          <div class="card" id="secAlerts"><h3>Sector &amp; asset alerts <span class="muted small">checked after each close</span></h3><div id="secAlertsBody" class="muted small">Loading…</div></div>
          <div class="card"><h3>Recently fired</h3>
            ${d.history.length ? d.history.slice(0, 20).map((h) => `<div class="tg-msg"><b>${esc(h.ticker)}</b>${h.sector ? ` <span class="muted small">${esc(h.sector)}</span>` : ""} · ${esc(h.rule)}<div>Price $${fmt(h.price)}</div>${h.note ? `<div>${esc(h.note)}</div>` : ""}<div class="muted small">${new Date(h.at).toLocaleString([], { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })}</div></div>`).join("")
              : `<p class="muted">Nothing yet. When an alert fires you get a Telegram message and it shows here.</p>`}
            <p class="muted small">${d.last_check ? "Last checked " + new Date(d.last_check).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" }) + ". " : ""}Checked every minute during market hours while the app is open. The moving average uses today's live price, so a touch is caught as it happens.</p>
          </div>
        </div>
      </div>`;
    bindGo(root);
    const f = $("#alForm");
    const sync = () => {
      const k = f.kind.value;
      $$(".ma-only", f).forEach((x) => (x.hidden = !k.startsWith("ma")));
      $$(".touch-only", f).forEach((x) => (x.hidden = k !== "ma_touch"));
      $$(".near-only", f).forEach((x) => (x.hidden = k !== "ma_near"));
      $$(".price-only", f).forEach((x) => (x.hidden = !k.startsWith("price")));
      try { $("#alDesc").textContent = describe(formAlert()); } catch (e) { $("#alDesc").textContent = ""; }
    };
    const formAlert = () => {
      const a = { ticker: cleanT(f.ticker.value), kind: f.kind.value, repeat: f.repeat.value, note: f.note.value.trim() };
      if (a.kind.startsWith("ma")) { a.ma_type = f.ma_type.value; a.length = +f.length.value; }
      if (a.kind === "ma_touch") a.direction = f.direction.value;
      if (a.kind === "ma_near") a.near_pct = +f.near_pct.value || 1;
      if (a.kind.startsWith("price")) a.price = +f.price.value || null;
      if (f.and_cond.value && f.and_price.value) { a.and_cond = f.and_cond.value; a.and_price = +f.and_price.value; }
      if (f.expires.value) a.expires = f.expires.value;
      return a;
    };
    f.length.oninput = () => { f.lenSlide.value = f.length.value; sync(); };
    f.lenSlide.oninput = () => { f.length.value = f.lenSlide.value; sync(); };
    f.oninput = sync;
    sync();
    f.onsubmit = async (e) => {
      e.preventDefault();
      const r = await call("save_alert", formAlert());
      if (r.ok) { toast(`Alert set: ${r.alert.ticker}`); renderAlerts(); } else toast(r.error, true);
    };
    drawSectorAlerts();
    $("#alCheck").onclick = async () => {
      const r = await call("check_alerts_now");
      if (r.ok) toast(r.fired ? `${r.fired} alert${r.fired > 1 ? "s" : ""} fired` : "Checked — nothing triggered"); else toast(r.error, true);
      renderAlerts();
    };
    $$(".al-row").forEach((row) => (row.onclick = async (e) => {
      const act = e.target.closest("[data-act]");
      if (!act) return;
      const id = row.dataset.id, a = d.alerts.find((x) => x.id === id);
      if (act.dataset.act === "toggle") { await call("save_alert", { id, ticker: a.ticker, kind: a.kind, price: a.price, length: a.length, enabled: act.checked, state: {} }); row.classList.toggle("off", !act.checked); }
      if (act.dataset.act === "del") { await call("delete_alert", id); renderAlerts(); }
      if (act.dataset.act === "chart") { P.chart.ticker = a.ticker; P.chart.data = null; show("charts"); }
    }));
  }

  async function drawSectorAlerts() {
    const el = $("#secAlertsBody");
    if (!el) return;
    const r = await call("list_sector_alerts");
    const list = (r && r.alerts) || [];
    el.innerHTML = `<form id="saForm" class="sa-form">
        <input name="t" placeholder="XLE, gold, oil, bonds…" aria-label="Sector or asset">
        <select name="k"><option value="above">score rises to</option><option value="below">score falls to</option><option value="quadrant">rotates into</option><option value="turns">changes quadrant</option></select>
        <input name="v" placeholder="+6" aria-label="Value"><button class="btn primary">Add</button></form>
      ${list.length ? `<div class="al-list">${list.map((a, i) => `<div class="sa-row"><span>${esc(a.description)}</span><button class="icon-btn" data-del="${i + 1}" title="Delete">${ic("x", 14)}</button></div>`).join("")}</div>`
        : `<p class="muted small">None yet. Scores run −10 (very expensive) to +10 (very cheap). Quadrants: Leading, Improving, Weakening, Lagging. Telegram: /valert XLE above 6</p>`}`;
    const f = $("#saForm");
    const sync = () => { f.v.hidden = f.k.value === "turns"; f.v.placeholder = f.k.value === "quadrant" ? "Leading" : "+6"; };
    f.k.onchange = sync; sync();
    f.onsubmit = async (e) => {
      e.preventDefault();
      const res = await call("add_sector_alert", f.t.value, f.k.value, f.k.value === "turns" ? null : f.v.value);
      if (res.ok) { toast("Sector alert set"); drawSectorAlerts(); } else toast(res.error, true);
    };
    $$("[data-del]", el).forEach((b) => (b.onclick = async () => { await call("delete_sector_alert", +b.dataset.del); drawSectorAlerts(); }));
  }

  function describe(a) {
    const ma = `${a.ma_type || "EMA"} ${a.length}`;
    let s = a.kind === "ma_touch" ? `Touches ${ma} ${({ above: "from above", below: "from below" })[a.direction] || "either way"}`
      : a.kind === "ma_near" ? `Within ${a.near_pct}% of ${ma}`
      : a.kind === "price_above" ? `Price above $${fmt(a.price)}` : a.kind === "price_below" ? `Price below $${fmt(a.price)}` : `Price crosses $${fmt(a.price)}`;
    if (a.and_cond) s += ` and ${a.and_cond} $${fmt(a.and_price)}`;
    return (a.ticker || "…") + ": " + s;
  }

  /* =====================================================================
     BOTTOM WATCHLIST BAR
     ===================================================================== */
  const BAR_COLS = [["day", "Day"], ["week", "Week"], ["month", "Month"], ["m2", "2 Mo"], ["m3", "3 Mo"]];
  async function loadBar(force) {
    const el = $("#wbar");
    if (!force && el && el.contains(document.activeElement) && document.activeElement.tagName === "INPUT") return;
    if (!force && P.bar.collapsed && P.bar.rows.length) return;
    const r = await call("get_bar");
    if (!force && el && el.contains(document.activeElement) && document.activeElement.tagName === "INPUT") return;
    if (r && r.rows) { P.bar.rows = r.rows; P.bar.needs = r.needs || null; }
    drawBar();
  }
  function drawBar() {
    const el = $("#wbar"), B = P.bar;
    if (!el) return;
    let rows = B.rows.slice();
    if (B.sort) rows.sort((a, b) => ((b[B.sort] ?? -1e9) - (a[B.sort] ?? -1e9)));
    el.classList.toggle("collapsed", B.collapsed);
    el.innerHTML = `<div class="wb-head">
        <button class="wb-toggle" id="wbToggle" aria-expanded="${!B.collapsed}">${ic("watchlist", 15)} Watchlist <span class="caret">${B.collapsed ? "▴" : "▾"}</span></button>
        ${B.needs ? `<span class="muted small">Prices need ${esc(B.needs)}</span>` : ""}
        <span class="muted small wb-hint">Click a ticker to change it</span>
        <button class="icon-btn sm" id="wbRefresh" title="Refresh">${ic("refresh", 14)}</button></div>
      ${B.collapsed ? "" : `<div class="wb-table"><table><thead><tr><th>Ticker</th><th class="r">Price</th>${BAR_COLS.map(([k, l]) => `<th class="r sortable ${B.sort === k ? "sorted" : ""}" data-s="${k}">${l}${B.sort === k ? " ↓" : ""}</th>`).join("")}<th></th></tr></thead>
        <tbody>${rows.map((r) => `<tr data-t="${esc(r.ticker)}"><td><input class="wb-t" value="${esc(r.ticker)}" maxlength="10" aria-label="Ticker ${esc(r.ticker)}"></td>
          <td class="r num">${r.price != null ? "$" + fmt(r.price) : "–"}</td>${BAR_COLS.map(([k]) => `<td class="r num">${pctCell(r[k])}</td>`).join("")}
          <td class="r"><button class="wb-x" data-x="${esc(r.ticker)}" aria-label="Remove ${esc(r.ticker)}">×</button></td></tr>`).join("")}
          <tr class="wb-add"><td><input class="wb-t" id="wbNew" placeholder="+ Add" maxlength="10" aria-label="Add ticker"></td><td colspan="7"></td></tr></tbody></table></div>`}`;
    $("#wbToggle").onclick = () => { B.collapsed = !B.collapsed; drawBar(); if (!B.collapsed) loadBar(true); };
    $("#wbRefresh").onclick = () => loadBar(true);
    if (B.collapsed) return;
    $$("th[data-s]", el).forEach((th) => (th.onclick = () => { B.sort = B.sort === th.dataset.s ? null : th.dataset.s; drawBar(); }));
    const commit = async (list) => {
      const r = await call("save_bar", list);
      if (r.ok) { B.rows = r.tickers.map((t) => B.rows.find((x) => x.ticker === t) || { ticker: t }); drawBar(); loadBar(true); }
    };
    $$(".wb-t", el).forEach((inp) => {
      inp.onkeydown = (e) => {
        if (e.key === "Escape") { inp.value = inp.defaultValue; inp.blur(); }
        if (e.key !== "Enter") return;
        e.preventDefault();
        const t = cleanT(inp.value), tickers = B.rows.map((x) => x.ticker);
        if (inp.id === "wbNew") { if (t && !tickers.includes(t)) commit(tickers.concat(t)); return; }
        const old = inp.closest("tr").dataset.t;
        if (!t) return commit(tickers.filter((x) => x !== old));
        if (t !== old) commit(tickers.map((x) => (x === old ? t : x)));
      };
      inp.onblur = () => { if (inp.id !== "wbNew") inp.value = inp.defaultValue; };
    });
    $$("[data-x]", el).forEach((b) => (b.onclick = () => commit(B.rows.map((x) => x.ticker).filter((x) => x !== b.dataset.x))));
    $$("tbody tr[data-t] td.num", el).forEach((td) => (td.onclick = () => { P.chart.ticker = td.parentElement.dataset.t; P.chart.data = null; show("charts"); }));
  }

  /* =====================================================================
     wiring
     ===================================================================== */
  window.PAGES = {
    drawAlertCal,
    charts: renderCharts,
    backtest: renderBacktest,
    strategybt: renderStrategyBt,
    finder: renderFinder,
    gamma: renderGamma,
    rotation: renderRotation,
    valStrip, macroStrip,
    openValuation() { P.rot.group = "Valuation"; show("rotation"); },
    research: renderResearch,
    compare: renderCompare,
    screener: renderScreener,
    calendar: renderCalendar,
    alerts: renderAlerts,
    search(t) {
      t = cleanT(t);
      if (!t) return false;
      if (S.page === "charts") { loadChart(t); return true; }
      if (S.page === "backtest") { loadBacktest(t); return true; }
      if (S.page === "finder") { loadFinder(t); return true; }
      if (S.page === "gamma") { P.gx.dates = null; loadGamma(t); return true; }
      if (S.page === "research") { P.research.ticker = t; renderResearch(); return true; }
      if (S.page === "compare") {
        const i = P.compare.tickers.findIndex((x) => !x);
        if (i >= 0) P.compare.tickers[i] = t; else P.compare.tickers[3] = t;
        P.compare.data = null; renderCompare(); return true;
      }
      if (S.page === "alerts") { P.alerts.draft = { ticker: t }; renderAlerts(); return true; }
      P.research.ticker = t; P.research.data = null; show("research");
      return true;
    },
    boot() {
      loadBar();
      clearInterval(P.bar.timer);
      P.bar.timer = setInterval(() => { if (!document.hidden) loadBar(); }, 60000);
      window.addEventListener("resize", () => { if (S.page === "charts") drawCanvas(); });
      document.addEventListener("click", (e) => {
        const pop = $("#fpop");
        if (pop && !pop.hidden && !pop.contains(e.target) && !e.target.closest(".fchip")) closePop();
      });
      new MutationObserver(() => {
        if (S.page === "charts") drawCanvas();
      }).observe(document.documentElement, { attributes: true, attributeFilter: ["data-theme"] });
    },
  };
})();
